stones = {}


minetest.register_node("stones:plot", {
	description = "Plot",
	drawtype = "nodebox",
	paramtype = "light",
	paramtype2 = "facedir",
	tiles ={"plot.png", "rock.png",
		{name = "rock.png^potdot.png",
		tileable_vertical = true}},
	groups = {vcol=0.508, crumbly=1, soil=1},
	drop = 'stones:plot',
	light_source = 0,
	node_box = {type = "fixed", fixed = {-0.5, -0.5, -0.5, 0.5, 0.5, 0.5}}
})

minetest.register_node("stones:prob", {
	description = "Plot Rubble",
	drawtype = "nodebox",
	paramtype = "light",
	paramtype2 = "facedir",
	tiles ={"prub.png", "rubble.png",
		{name = "rubble.png^potdot.png",
		tileable_vertical = true}},
	groups = {vcol=0.508, crumbly=3, soil=1, not_in_creative_inventory=1},
	drop = 'stones:prob',
	light_source = 0,
	node_box = {type = "fixed", fixed = {-0.5, -0.5, -0.5, 0.5, 0.5, 0.5}}
})

minetest.register_node("stones:shrub", {
	description = "Dry Shrub",
	drop = "stones:srawb",
	drawtype = "mesh",
	waving = 1,
	walkable = false,
	tiles = {"bush_01.png"},
	inventory_image = "twig_01.png",
	wield_image = "twig_01.png",
	paramtype = "light",
	paramtype2 = "facedir",
	place_param2 = math.random(0,3),
	sunlight_propagates = true,
	walkable = false,
	buildable_to = true,
	groups={snappy=3,flammable=2,leaves=1,dig_immediate = 3,attached_node=1, not_in_creative_inventory=1},
	damage_per_second = 1,
	selection_box={type="fixed",fixed = 
{-1/16,-0.6,-1/16, 1/16,-3/16,1/16}},
	collision_box = {type="fixed",fixed={
{-1/16,-0.6,-1/16, 1/16,-3/16,1/16}}},
	mesh = "shrub.obj",
	node_dig_prediction = "stones:shub",
	after_dig_node = function(pos, oldnode, oldmetadata, digger)
		minetest.set_node(pos, {name = "stones:shub",  param2 = math.floor((oldnode.param2)/4)*4+(oldnode.param2)%4})
		minetest.get_node_timer(pos):start(math.random(300, 1500))
	end,
})

minetest.register_craftitem("stones:srawb", {
    description = "Lum Nininikus +4HP",
	use_texture_alpha = "clip",
    inventory_image = "barred.png",
    on_use = minetest.item_eat(7),  -- Heals 4 HP (2 hearts)
    groups={not_in_creative_inventory=1}
})

minetest.register_craftitem("stones:flor", {
    description = "Lum Nininikus Flor +1HP",
	use_texture_alpha = "clip",
    inventory_image = "barblue.png",
    on_use = minetest.item_eat(1),  -- Heals 1 HP (1/2 heart)
    on_place = function(itemstack, placer, pointed_thing)
        	if pointed_thing.type == "node" then
    		local pos = pointed_thing.above
    		local oldnode = minetest.get_node(pos)
	    	local stackname = itemstack:get_name()
    		while oldnode.name == "air" and not itemstack:is_empty() do
    			local newnode = {name = "stones:blus", param1 = 0}
    			minetest.set_node(pos, newnode)
	    		itemstack:take_item()
	    		pos.y = pos.y - 1
    			oldnode = minetest.get_node(pos)
          		end
         	end
	    return itemstack
    end,
    groups={not_in_creative_inventory=1}
})

minetest.register_craftitem("stones:flwr", {
    description = "Lum Nininikus Flwr -2HP",
	use_texture_alpha = "clip",
    inventory_image = "bargreen.png",
    on_use = minetest.item_eat(-1),  -- Poisons 2 HP (1 heart)
    on_place = function(itemstack, placer, pointed_thing)
        	if pointed_thing.type == "node" then
    		local pos = pointed_thing.above
    		local oldnode = minetest.get_node(pos)
	    	local stackname = itemstack:get_name()
    		while oldnode.name == "air" and not itemstack:is_empty() do
    			local newnode = {name = "stones:blom", param1 = 0}
    			minetest.set_node(pos, newnode)
	    		itemstack:take_item()
	    		pos.y = pos.y - 1
    			oldnode = minetest.get_node(pos)
          		end
         	end
	    return itemstack
    end,
    groups={not_in_creative_inventory=1}
})

minetest.register_craftitem("stones:bulb", {
    description = "Lum Nininikus Bulb -6HP",
	use_texture_alpha = "clip",
    inventory_image = "barbulb.png",
    on_use = minetest.item_eat(-6),  -- Poisons 6 HP (3 heart)
    on_place = function(itemstack, placer, pointed_thing)
        	if pointed_thing.type == "node" then
    		local pos = pointed_thing.above
    		local oldnode = minetest.get_node(pos)
	    	local stackname = itemstack:get_name()
    		while oldnode.name == "air" and not itemstack:is_empty() do
    			local newnode = {name = "stones:su", param1 = 0}
    			minetest.set_node(pos, newnode)
	    		itemstack:take_item()
	    		pos.y = pos.y - 1
    			oldnode = minetest.get_node(pos)
          		end
         	end
	    return itemstack
    end,
    groups={not_in_creative_inventory=1}
})

minetest.register_node("stones:shub", {
	description = "Dry Shrub Sans Lum",
	drop = "stones:flor 2",
	drawtype = "mesh",
	waving = 1,
	walkable = false,
	tiles = {"bush_02.png"},
	inventory_image = "twig_02.png",
	wield_image = "twig_02.png",
	paramtype = "light",
	paramtype2 = "facedir",
	place_param2 = math.random(0,3),
	sunlight_propagates = true,
	walkable = false,
	buildable_to = true,
	groups={snappy=3,flammable=2,leaves=1,dig_immediate = 3,not_in_creative_inventory=1},
	damage_per_second = 2,
	selection_box={type="fixed",fixed = 
{-1/16,-0.6,-1/16, 1/16,-3/16,1/16}},
	collision_box = {type="fixed",fixed={
{-1/16,-0.6,-1/16, 1/16,-3/16,1/16}}},
	mesh = "shrub.obj",
	after_place_node = after_place_leaves,
	node_dig_prediction = "stones:sub",
	after_dig_node = function(pos, oldnode, oldmetadata, digger)
		minetest.set_node(pos, {name = "stones:sub",  param2 = math.floor((oldnode.param2)/4)*4+(oldnode.param2)%4})
		minetest.get_node_timer(pos):start(math.random(300, 1500))
	end,
})

minetest.register_abm({
    nodenames = {"stones:shub"},
    interval = 5,
    chance = 25,
    action = function(pos, node)
		s = minetest.env:get_node(pos)
		p2 = s.param2
        minetest.env:remove_node(pos)
        minetest.set_node(pos, {name = "stones:shrub", param2 = math.floor((p2)/4)*4+(p2)%4})
    end
})

stones.after_place_leaves = function(pos, placer, itemstack, pointed_thing)
	if placer and placer:is_player() then
		local node = minetest.get_node(pos)
		node.param2 = math.floor((node.p2)/4)*4+(node.p2)%4
		minetest.set_node(pos, node)
	end
end

minetest.register_node("stones:sub", {
	description = "Dry Bush Sans Flors",
	drop = "stones:sub",
	drawtype = "mesh",
	waving = 1,
	walkable = false,
	tiles = {"bush_03.png"},
	inventory_image = "twig_03.png",
	wield_image = "twig_03.png",
	paramtype = "light",
	paramtype2 = "facedir",
	place_param2 = math.random(0,3),
	sunlight_propagates = true,
	walkable = false,
	buildable_to = true,
	groups={snappy=3,flammable=2,leaves=1,dig_immediate = 3,not_in_creative_inventory=1},
	damage_per_second = 3,
	selection_box={type="fixed",fixed = 
{-1/16,-0.6,-1/16, 1/16,-3/16,1/16}},
	collision_box = {type="fixed",fixed={
{-1/16,-0.6,-1/16, 1/16,-3/16,1/16}}},
	mesh = "shrub.obj",
	after_place_node = after_place_leaves
})

minetest.register_abm({
    nodenames = {"stones:sub"},
    interval = 4,
    chance = 15,
    action = function(pos, node)
		s = minetest.env:get_node(pos)
		p2 = s.param2
        minetest.env:remove_node(pos)
        minetest.set_node(pos, {name = "stones:shurb", param2 = math.floor((p2)/4)*4+(p2)%4})
    end
})

minetest.register_node("stones:shurb", {
	description = "Dry Shrub Just Flors",
	drop = "stones:flor 3",
	drawtype = "mesh",
	waving = 1,
	walkable = false,
	tiles = {"bush_05.png"},
	inventory_image = "twig_04.png",
	wield_image = "twig_04.png",
	paramtype = "light",
	paramtype2 = "facedir",
	place_param2 = math.random(0,3),
	sunlight_propagates = true,
	walkable = false,
	buildable_to = true,
	groups={snappy=3,flammable=2,leaves=1,dig_immediate = 3,not_in_creative_inventory=1},
	damage_per_second = 1,
	selection_box={type="fixed",fixed = 
{-1/16,-0.6,-1/16, 1/16,-3/16,1/16}},
	collision_box = {type="fixed",fixed={
{-1/16,-0.6,-1/16, 1/16,-3/16,1/16}}},
	mesh = "shrub.obj",
	after_place_node = after_place_leaves,
	node_dig_prediction = "stones:sub",
	after_dig_node = function(pos, oldnode, oldmetadata, digger)
		minetest.set_node(pos, {name = "stones:sub",  param2 = math.floor((oldnode.param2)/4)*4+(oldnode.param2)%4})
		minetest.get_node_timer(pos):start(math.random(300, 1500))
	end,
})

minetest.register_node("stones:blus", {
	description = "Dry Bush Sans Flor Sans Flwrs",
	drop = "stones:blus",
	drawtype = "mesh",
	waving = 1,
	walkable = false,
	tiles = {"bush_03.png"},
	inventory_image = "twig_03.png",
	wield_image = "twig_03.png",
	paramtype = "light",
	paramtype2 = "facedir",
	place_param2 = math.random(0,3),
	sunlight_propagates = true,
	walkable = false,
	buildable_to = true,
	groups={snappy=3,flammable=2,leaves=1,dig_immediate = 3,attached_node=1,not_in_creative_inventory=1},
	damage_per_second = 1,
	selection_box={type="fixed",fixed = 
{-1/16,-0.6,-1/16, 1/16,-3/16,1/16}},
	collision_box = {type="fixed",fixed={
{-1/16,-0.6,-1/16, 1/16,-3/16,1/16}}},
	mesh = "shrub.obj"
})

minetest.register_abm({
    nodenames = {"stones:blus"},
    interval = 5,
    chance = 20,
    action = function(pos, node)
		s = minetest.env:get_node(pos)
		p2 = s.param2
        minetest.env:remove_node(pos)
        minetest.set_node(pos, {name = "stones:blis", param2 = math.floor((p2)/4)*4+(p2)%4})
    end
})

minetest.register_node("stones:blis", {
	description = "Dry Bush Sans Flor With Flwrs",
	drop = "stones:flwr 2",
	drawtype = "mesh",
	waving = 1,
	walkable = false,
	tiles = {"bush_07.png"},
	inventory_image = "twig_06.png",
	wield_image = "twig_06.png",
	paramtype = "light",
	paramtype2 = "facedir",
	place_param2 = math.random(0,3),
	sunlight_propagates = true,
	walkable = false,
	buildable_to = true,
	groups={snappy=3,flammable=2,leaves=1,dig_immediate = 3,attached_node=1,not_in_creative_inventory=1},
	damage_per_second = 0,
	selection_box={type="fixed",fixed = 
{-1/16,-0.6,-1/16, 1/16,-3/16,1/16}},
	collision_box = {type="fixed",fixed={
{-1/16,-0.6,-1/16, 1/16,-3/16,1/16}}},
	mesh = "shrub.obj",
	node_dig_prediction = "stones:blus",
	after_dig_node = function(pos, oldnode, oldmetadata, digger)
		minetest.set_node(pos, {name = "stones:blus",  param2 = math.floor((oldnode.param2)/4)*4+(oldnode.param2)%4})
		minetest.get_node_timer(pos):start(math.random(300, 1500))
	end,
})

minetest.register_abm({
    nodenames = {"stones:blis"},
    interval = 3,
    chance = 10,
    action = function(pos, node)
		s = minetest.env:get_node(pos)
		p2 = s.param2
        minetest.env:remove_node(pos)
        minetest.set_node(pos, {name = "stones:bush", param2 = math.floor((p2)/4)*4+(p2)%4})
    end
})

minetest.register_node("stones:bush", {
	description = "Dry Bush",
	drop = "stones:flor",
	drawtype = "mesh",
	waving = 1,
	walkable = false,
	tiles = {"bush_04.png"},
	inventory_image = "twig_07.png",
	wield_image = "twig_07.png",
	paramtype = "light",
	paramtype2 = "facedir",
	place_param2 = math.random(0,3),
	sunlight_propagates = true,
	walkable = false,
	buildable_to = true,
	groups={snappy=3,flammable=2,leaves=1,dig_immediate = 3,attached_node=1,not_in_creative_inventory=1},
	damage_per_second = 0,
	selection_box={type="fixed",fixed = 
{-1/16,-0.6,-1/16, 1/16,-3/16,1/16}},
	collision_box = {type="fixed",fixed={
{-1/16,-0.6,-1/16, 1/16,-3/16,1/16}}},
	mesh = "shrub.obj",
	after_place_node = after_place_leaves,
	node_dig_prediction = "stones:blis",
	after_dig_node = function(pos, oldnode, oldmetadata, digger)
		minetest.set_node(pos, {name = "stones:blis",  param2 = math.floor((oldnode.param2)/4)*4+(oldnode.param2)%4})
		minetest.get_node_timer(pos):start(math.random(300, 1500))
	end,
})

minetest.register_node("stones:blom", {
	description = "Dry Bloom Sans Flwrs",
	drop = "stones:blom",
	drawtype = "mesh",
	waving = 1,
	walkable = false,
	tiles = {"bush_03.png"},
	inventory_image = "twig_03.png",
	wield_image = "twig_03.png",
	paramtype = "light",
	paramtype2 = "facedir",
	place_param2 = math.random(0,3),
	sunlight_propagates = true,
	walkable = false,
	buildable_to = true,
	groups={snappy=3,flammable=2,leaves=1,dig_immediate = 3,attached_node=1,not_in_creative_inventory=1},
	damage_per_second = 4,
	selection_box={type="fixed",fixed = 
{-1/16,-0.6,-1/16, 1/16,-3/16,1/16}},
	collision_box = {type="fixed",fixed={
{-1/16,-0.6,-1/16, 1/16,-3/16,1/16}}},
	mesh = "shrub.obj",
	after_place_node = after_place_leaves,
})

minetest.register_abm({
    nodenames = {"stones:blom"},
    interval = 4,
    chance = 25,
    action = function(pos, node)
		s = minetest.env:get_node(pos)
		p2 = s.param2
        minetest.env:remove_node(pos)
        minetest.set_node(pos, {name = "stones:bloom", param2 = math.floor((p2)/4)*4+(p2)%4})
    end
})

minetest.register_node("stones:bloom", {
	description = "Dry Shrub Just Flwrs",
	drop = "stones:flwr 3",
	drawtype = "mesh",
	waving = 1,
	walkable = false,
	tiles = {"bush_06.png"},
	inventory_image = "twig_05.png",
	wield_image = "twig_05.png",
	paramtype = "light",
	paramtype2 = "facedir",
	place_param2 = math.random(0,3),
	sunlight_propagates = true,
	walkable = false,
	buildable_to = true,
	groups={snappy=3,flammable=2,leaves=1,dig_immediate = 3,not_in_creative_inventory=0},
	damage_per_second = -1,
	selection_box={type="fixed",fixed = 
{-1/16,-0.6,-1/16, 1/16,-3/16,1/16}},
	collision_box = {type="fixed",fixed={
{-1/16,-0.6,-1/16, 1/16,-3/16,1/16}}},
	mesh = "shrub.obj",
	after_place_node = after_place_leaves,
	node_dig_prediction = "stones:blom",
	after_dig_node = function(pos, oldnode, oldmetadata, digger)
		minetest.set_node(pos, {name = "stones:blom",  param2 = math.floor((oldnode.param2)/4)*4+(oldnode.param2)%4})
		minetest.get_node_timer(pos):start(math.random(300, 1500))
	end,
})

minetest.register_node("stones:su", {
	description = "Dry Shrub Sans Lum Sans Flwrs",
	drop = "stones:su",
	drawtype = "mesh",
	waving = 1,
	walkable = false,
	tiles = {"bush_03.png"},
	inventory_image = "twig_03.png",
	wield_image = "twig_03.png",
	paramtype = "light",
	paramtype2 = "facedir",
	place_param2 = math.random(0,3),
	sunlight_propagates = true,
	walkable = false,
	buildable_to = true,
	groups={snappy=1,flammable=1,leaves=1,attached_node=1,not_in_creative_inventory=1},
	damage_per_second = 4,
	selection_box={type="fixed",fixed = 
{-1/16,-0.6,-1/16, 1/16,-3/16,1/16}},
	collision_box = {type="fixed",fixed={
{-1/16,-0.6,-1/16, 1/16,-3/16,1/16}}},
	mesh = "shrub.obj",
	after_place_node = after_place_leaves,
})

minetest.register_abm({
    nodenames = {"stones:su"},
    interval = 7,
    chance = 20,
    action = function(pos, node)
		s = minetest.env:get_node(pos)
		p2 = s.param2
        minetest.env:remove_node(pos)
        minetest.set_node(pos, {name = "stones:shub", param2 = math.floor((p2)/4)*4+(p2)%4})
    end
})

minetest.register_craft({
	output = "stones:bulb",
	recipe = {
		{"stones:flwr", "stones:flwr", "stones:flwr"},
		{"stones:flwr", "", "stones:flwr"},
		{"stones:flwr", "stones:flwr", "stones:flwr"},
	}
})

minetest.register_node("stones:delum", {
	description = "Dodeca-Lum",
	paramtype = "light",
	light_source = 14,
	paramtype2 = "facedir",
	tiles = {{name="C16x4608.png", animation = {type = "vertical_frames", length=31.8}}},
	inventory_image = "denum.png",
	groups = {cracky=1, oddly_breakable_by_hand=1, not_in_creative_inventory=1},
	drop = "stones:denum",
	selection_box = {type="fixed",fixed={
{-0.28,-0.28,-0.28, 0.28,0.28,0.28}}},
	collision_box = {type="fixed",fixed={
{-0.28,-0.28,-0.28, 0.28,0.28,0.28}}},
	drawtype = "mesh",
	mesh = "dedalum.obj",
	on_rightclick = function(pos, node, clicker, pointed_thing)
		minetest.set_node(pos, {name = "stones:deluma", param2 = node.param2})
	end,
})

minetest.register_node("stones:deluma", {
	description = "Dodeca-Lum A",
	paramtype = "light",
	light_source = 14,
	paramtype2 = "facedir",
	tiles = {{name="K8x4608.png", animation = {type = "vertical_frames", length=31.8}}},
	inventory_image = "denum.png",
	groups = {cracky=1, oddly_breakable_by_hand=1, not_in_creative_inventory=1},
	drop = "stones:denum",
	selection_box = {type="fixed",fixed={
{-0.28,-0.28,-0.28, 0.28,0.28,0.28}}},
	collision_box = {type="fixed",fixed={
{-0.28,-0.28,-0.28, 0.28,0.28,0.28}}},
	drawtype = "mesh",
	mesh = "dedalum.obj",
	on_rightclick = function(pos, node, clicker, pointed_thing)
		minetest.set_node(pos, {name = "stones:denum", param2 = node.param2})
	end,
})

minetest.register_node("stones:denum", {
	description = "Dodeca-Lum-Nil",
	paramtype = "light",
	light_source = 0,
	paramtype2 = "facedir",
	tiles = {"rock.png"},
	groups = {cracky=1, oddly_breakable_by_hand=1, not_in_creative_inventory=1},
	drop = "stones:denum",
	inventory_image = "denum.png",
	selection_box = {type="fixed",fixed={
{-0.28,-0.28,-0.28, 0.28,0.28,0.28}}},
	collision_box = {type="fixed",fixed={
{-0.28,-0.28,-0.28, 0.28,0.28,0.28}}},
	drawtype = "mesh",
	mesh = "dedalum.obj",
	on_rightclick = function(pos, node, clicker, pointed_thing)
		minetest.set_node(pos, {name = "stones:delum", param2 = node.param2})
	end,
})

minetest.register_node("stones:isokar", {
	description = "Icosahedron Flamed",
	paramtype = "light",
	paramtype2 = "facedir",
	tiles = {{name = "rock_1x24.png^opaq_1x24.png^star_1x24.png", animation = {type = "vertical_frames", length = 5.0}}},
	light_source = 14,
	groups = {vcol=0.5, cracky=1, oddly_breakable_by_hand=1, not_in_creative_inventory=1},
	drop = "stones:isokar",
	collision_box={type="fixed",fixed={
{-0.2245,-0.5,-0.309, 0.2245,-0.05,0.216},
{-0.27,-0.5,-0.16, -0.2245,-0.05,0.185},
{-0.31,-0.5,-0.04, -0.27,-0.05,0.155},
{-0.35,-0.5,0.08, -0.31,-0.05,0.125},
{0.2245,-0.5,-0.16, 0.27,-0.05,0.185},
{0.27,-0.5,-0.04, 0.31,-0.05,0.155},
{0.31,-0.5,0.08, 0.35,-0.05,0.125},
{-0.1875,-0.5,0.216, 0.1875,-0.05,0.245},
{-0.125,-0.5,0.245, 0.125,-0.05,0.29},
{-0.0625,-0.5,0.29, 0.0625,-0.05,0.333},
{-0.02,-0.5,0.333, 0.02,-0.05,0.37},
{-0.3,-0.05,-0.3, 0.3,0.05,0.3},
{-0.2245,0.05,0.309, 0.2245,0.5,-0.216},
{-0.27,0.05,0.16, -0.2245,0.5,-0.185},
{-0.31,0.05,0.04, -0.27,0.5,-0.155},
{-0.35,0.05,-0.08, -0.31,0.5,-0.125},
{0.2245,0.05,0.16, 0.27,0.5,-0.185},
{0.27,0.05,0.04, 0.31,0.5,-0.155},
{0.31,0.05,-0.08, 0.35,0.5,-0.125},
{-0.1875,0.05,-0.216, 0.1875,0.5,-0.245},
{-0.125,0.05,-0.245, 0.125,0.5,-0.29},
{-0.0625,0.05,-0.29, 0.0625,0.5,-0.333},
{-0.02,0.05,-0.333, 0.02,0.5,-0.37}}},
	selection_box={type="fixed",fixed={
{-0.2245,-0.5,-0.309, 0.2245,-0.1,0.216},
{-0.27,-0.5,-0.16, -0.2245,-0.1,0.185},
{-0.31,-0.5,-0.04, -0.27,-0.1,0.155},
{-0.35,-0.5,0.08, -0.31,-0.1,0.125},
{0.2245,-0.5,-0.16, 0.27,-0.1,0.185},
{0.27,-0.5,-0.04, 0.31,-0.1,0.155},
{0.31,-0.5,0.08, 0.35,-0.1,0.125},
{-0.1875,-0.5,0.216, 0.1875,-0.1,0.245},
{-0.125,-0.5,0.245, 0.125,-0.1,0.29},
{-0.0625,-0.5,0.29, 0.0625,-0.1,0.333},
{-0.02,-0.5,0.333, 0.02,-0.1,0.37},
{-0.35,-0.1,-0.35, 0.35,0.1,0.35},
{-0.2245,0.1,0.309, 0.2245,0.5,-0.216},
{-0.27,0.1,0.16, -0.2245,0.5,-0.185},
{-0.31,0.1,0.04, -0.27,0.5,-0.155},
{-0.35,0.1,-0.08, -0.31,0.5,-0.125},
{0.2245,0.1,0.16, 0.27,0.5,-0.185},
{0.27,0.1,0.04, 0.31,0.5,-0.155},
{0.31,0.1,-0.08, 0.35,0.5,-0.125},
{-0.1875,0.1,-0.216, 0.1875,0.5,-0.245},
{-0.125,0.1,-0.245, 0.125,0.5,-0.29},
{-0.0625,0.1,-0.29, 0.0625,0.5,-0.333},
{-0.02,0.1,-0.333, 0.02,0.5,-0.37},
{0-(1/128),-0.11803-(1/128),0.61803-(1/128), 0+(1/128),-0.11803+(1/128),0.61803+(1/128)},
{-0.36327-(1/128),0.11803-(1/128),0.5-(1/128), -0.36327+(1/128),0.11803+(1/128),0.5+(1/128)},
{-0.58779-(1/128),-0.11803-(1/128),0.19098-(1/128), -0.58779+(1/128),-0.11803+(1/128),0.19098+(1/128)},
{-0.58779-(1/128),0.11803-(1/128),-0.19098-(1/128), -0.58779+(1/128),0.11803+(1/128),-0.19098+(1/128)},
{-0.36327-(1/128),-0.11803-(1/128),-0.5-(1/128), -0.36327+(1/128),-0.11803+(1/128),-0.5+(1/128)},
{0-(1/128),0.11803-(1/128),-0.61803-(1/128), 0+(1/128),0.11803+(1/128),-0.61803+(1/128)},
{0.36327-(1/128),-0.11803-(1/128),-0.5-(1/128), 0.36327+(1/128),-0.11803+(1/128),-0.5+(1/128)},
{0.58779-(1/128),0.11803-(1/128),-0.19098-(1/128), 0.58779+(1/128),0.11803+(1/128),-0.19098+(1/128)},
{0.58779-(1/128),-0.11803-(1/128),0.19098-(1/128), 0.58779+(1/128),-0.11803+(1/128),0.19098+(1/128)},
{0.36327-(1/128),0.11803-(1/128),0.5-(1/128), 0.36327+(1/128),0.11803+(1/128),0.5+(1/128)}}},
	drawtype="mesh",
	mesh = "isokar.obj"
})

minetest.register_node("stones:isodark", {
	description = "Icosahedron Dark",
	paramtype = "light",
	paramtype2 = "facedir",
	tiles = {"rock.png^stark.png"},
	light_source = 0,
	groups = {vcol=0.5, cracky=1, oddly_breakable_by_hand=1},
	drop = "stones:isodark",
	collision_box={type="fixed",fixed={
{-0.2245,-0.5,-0.309, 0.2245,-0.05,0.216},
{-0.27,-0.5,-0.16, -0.2245,-0.05,0.185},
{-0.31,-0.5,-0.04, -0.27,-0.05,0.155},
{-0.35,-0.5,0.08, -0.31,-0.05,0.125},
{0.2245,-0.5,-0.16, 0.27,-0.05,0.185},
{0.27,-0.5,-0.04, 0.31,-0.05,0.155},
{0.31,-0.5,0.08, 0.35,-0.05,0.125},
{-0.1875,-0.5,0.216, 0.1875,-0.05,0.245},
{-0.125,-0.5,0.245, 0.125,-0.05,0.29},
{-0.0625,-0.5,0.29, 0.0625,-0.05,0.333},
{-0.02,-0.5,0.333, 0.02,-0.05,0.37},
{-0.3,-0.05,-0.3, 0.3,0.05,0.3},
{-0.2245,0.05,0.309, 0.2245,0.5,-0.216},
{-0.27,0.05,0.16, -0.2245,0.5,-0.185},
{-0.31,0.05,0.04, -0.27,0.5,-0.155},
{-0.35,0.05,-0.08, -0.31,0.5,-0.125},
{0.2245,0.05,0.16, 0.27,0.5,-0.185},
{0.27,0.05,0.04, 0.31,0.5,-0.155},
{0.31,0.05,-0.08, 0.35,0.5,-0.125},
{-0.1875,0.05,-0.216, 0.1875,0.5,-0.245},
{-0.125,0.05,-0.245, 0.125,0.5,-0.29},
{-0.0625,0.05,-0.29, 0.0625,0.5,-0.333},
{-0.02,0.05,-0.333, 0.02,0.5,-0.37}}},
	selection_box={type="fixed",fixed={
{-0.2245,-0.5,-0.309, 0.2245,-0.1,0.216},
{-0.27,-0.5,-0.16, -0.2245,-0.1,0.185},
{-0.31,-0.5,-0.04, -0.27,-0.1,0.155},
{-0.35,-0.5,0.08, -0.31,-0.1,0.125},
{0.2245,-0.5,-0.16, 0.27,-0.1,0.185},
{0.27,-0.5,-0.04, 0.31,-0.1,0.155},
{0.31,-0.5,0.08, 0.35,-0.1,0.125},
{-0.1875,-0.5,0.216, 0.1875,-0.1,0.245},
{-0.125,-0.5,0.245, 0.125,-0.1,0.29},
{-0.0625,-0.5,0.29, 0.0625,-0.1,0.333},
{-0.02,-0.5,0.333, 0.02,-0.1,0.37},
{-0.35,-0.1,-0.35, 0.35,0.1,0.35},
{-0.2245,0.1,0.309, 0.2245,0.5,-0.216},
{-0.27,0.1,0.16, -0.2245,0.5,-0.185},
{-0.31,0.1,0.04, -0.27,0.5,-0.155},
{-0.35,0.1,-0.08, -0.31,0.5,-0.125},
{0.2245,0.1,0.16, 0.27,0.5,-0.185},
{0.27,0.1,0.04, 0.31,0.5,-0.155},
{0.31,0.1,-0.08, 0.35,0.5,-0.125},
{-0.1875,0.1,-0.216, 0.1875,0.5,-0.245},
{-0.125,0.1,-0.245, 0.125,0.5,-0.29},
{-0.0625,0.1,-0.29, 0.0625,0.5,-0.333},
{-0.02,0.1,-0.333, 0.02,0.5,-0.37},
{0-(1/128),-0.11803-(1/128),0.61803-(1/128), 0+(1/128),-0.11803+(1/128),0.61803+(1/128)},
{-0.36327-(1/128),0.11803-(1/128),0.5-(1/128), -0.36327+(1/128),0.11803+(1/128),0.5+(1/128)},
{-0.58779-(1/128),-0.11803-(1/128),0.19098-(1/128), -0.58779+(1/128),-0.11803+(1/128),0.19098+(1/128)},
{-0.58779-(1/128),0.11803-(1/128),-0.19098-(1/128), -0.58779+(1/128),0.11803+(1/128),-0.19098+(1/128)},
{-0.36327-(1/128),-0.11803-(1/128),-0.5-(1/128), -0.36327+(1/128),-0.11803+(1/128),-0.5+(1/128)},
{0-(1/128),0.11803-(1/128),-0.61803-(1/128), 0+(1/128),0.11803+(1/128),-0.61803+(1/128)},
{0.36327-(1/128),-0.11803-(1/128),-0.5-(1/128), 0.36327+(1/128),-0.11803+(1/128),-0.5+(1/128)},
{0.58779-(1/128),0.11803-(1/128),-0.19098-(1/128), 0.58779+(1/128),0.11803+(1/128),-0.19098+(1/128)},
{0.58779-(1/128),-0.11803-(1/128),0.19098-(1/128), 0.58779+(1/128),-0.11803+(1/128),0.19098+(1/128)},
{0.36327-(1/128),0.11803-(1/128),0.5-(1/128), 0.36327+(1/128),0.11803+(1/128),0.5+(1/128)}}},
	drawtype="mesh",
	mesh = "isokar.obj"
})


minetest.register_node("stones:isocol", {
	description = "Pentagonal Column",
	paramtype = "light",
	paramtype2 = "facedir",
	tiles = {"rock.png"},
	light_source = 0.1,
	groups = {vcol=0.344, cracky=1, oddly_breakable_by_hand=1},
	drop = "stones:isocol",
	collision_box={type="fixed",fixed={
{-0.2245,-0.5,-0.309, 0.2245,0.5,0.216},
{-0.27,-0.5,-0.16, -0.2245,0.5,0.185},
{-0.31,-0.5,-0.04, -0.27,0.5,0.155},
{-0.35,-0.5,0.08, -0.31,0.5,0.125},
{0.2245,-0.5,-0.16, 0.27,0.5,0.185},
{0.27,-0.5,-0.04, 0.31,0.5,0.155},
{0.31,-0.5,0.08, 0.35,0.5,0.125},
{-0.1875,-0.5,0.216, 0.1875,0.5,0.245},
{-0.125,-0.5,0.245, 0.125,0.5,0.29},
{-0.0625,-0.5,0.29, 0.0625,0.5,0.333},
{-0.02,-0.5,0.333, 0.02,0.5,0.37}}},
	selection_box={type="fixed",fixed={
{-0.2245,-0.5,-0.309, 0.2245,0.5,0.216},
{-0.27,-0.5,-0.16, -0.2245,0.5,0.185},
{-0.31,-0.5,-0.04, -0.27,0.5,0.155},
{-0.35,-0.5,0.08, -0.31,0.5,0.125},
{0.2245,-0.5,-0.16, 0.27,0.5,0.185},
{0.27,-0.5,-0.04, 0.31,0.5,0.155},
{0.31,-0.5,0.08, 0.35,0.5,0.125},
{-0.1875,-0.5,0.216, 0.1875,0.5,0.245},
{-0.125,-0.5,0.245, 0.125,0.5,0.29},
{-0.0625,-0.5,0.29, 0.0625,0.5,0.333},
{-0.02,-0.5,0.333, 0.02,0.5,0.37}}},
	drawtype="mesh",
	mesh = "isocol.obj"
})

minetest.register_node("stones:irocol", {
	description = "Pentagonal Column Rubble",
	paramtype = "light",
	paramtype2 = "facedir",
	tiles = {"rubble.png"},
	light_source = 0.1,
	groups = {vcol=0.344, cracky=3, oddly_breakable_by_hand=1, not_in_creative_inventory=1},
	drop = "stones:irocol",
	collision_box={type="fixed",fixed={
{-0.2245,-0.5,-0.309, 0.2245,0.5,0.216},
{-0.27,-0.5,-0.16, -0.2245,0.5,0.185},
{-0.31,-0.5,-0.04, -0.27,0.5,0.155},
{-0.35,-0.5,0.08, -0.31,0.5,0.125},
{0.2245,-0.5,-0.16, 0.27,0.5,0.185},
{0.27,-0.5,-0.04, 0.31,0.5,0.155},
{0.31,-0.5,0.08, 0.35,0.5,0.125},
{-0.1875,-0.5,0.216, 0.1875,0.5,0.245},
{-0.125,-0.5,0.245, 0.125,0.5,0.29},
{-0.0625,-0.5,0.29, 0.0625,0.5,0.333},
{-0.02,-0.5,0.333, 0.02,0.5,0.37}}},
	selection_box={type="fixed",fixed={
{-0.2245,-0.5,-0.309, 0.2245,0.5,0.216},
{-0.27,-0.5,-0.16, -0.2245,0.5,0.185},
{-0.31,-0.5,-0.04, -0.27,0.5,0.155},
{-0.35,-0.5,0.08, -0.31,0.5,0.125},
{0.2245,-0.5,-0.16, 0.27,0.5,0.185},
{0.27,-0.5,-0.04, 0.31,0.5,0.155},
{0.31,-0.5,0.08, 0.35,0.5,0.125},
{-0.1875,-0.5,0.216, 0.1875,0.5,0.245},
{-0.125,-0.5,0.245, 0.125,0.5,0.29},
{-0.0625,-0.5,0.29, 0.0625,0.5,0.333},
{-0.02,-0.5,0.333, 0.02,0.5,0.37}}},
	drawtype="mesh",
	mesh = "isocol.obj"
})

minetest.register_node("stones:iso54", {
	description = "Pentagon / Square Joiner",
	paramtype = "light",
	paramtype2 = "facedir",
	tiles = {"rock.png"},
	light_source = 0.1,
	groups = {vcol=0.672, cracky=1, oddly_breakable_by_hand=1},
	drop = "stones:iso54",
	collision_box={type="fixed",fixed={
{-0.5,-0.5,-0.5, 0.5,-0.45,0.5},
{-0.2245,-0.45,-0.309, 0.2245,0.5,0.216},
{-0.27,-0.45,-0.16, -0.2245,0.5,0.185},
{-0.31,-0.45,-0.04, -0.27,0.5,0.155},
{-0.35,-0.45,0.08, -0.31,0.5,0.125},
{0.2245,-0.45,-0.16, 0.27,0.5,0.185},
{0.27,-0.45,-0.04, 0.31,0.5,0.155},
{0.31,-0.45,0.08, 0.35,0.5,0.125},
{-0.1875,-0.45,0.216, 0.1875,0.5,0.245},
{-0.125,-0.45,0.245, 0.125,0.5,0.29},
{-0.0625,-0.45,0.29, 0.0625,0.5,0.333},
{-0.02,-0.45,0.333, 0.02,0.5,0.37}}},
	selection_box={type="fixed",fixed={
{-0.5,-0.5,-0.5, 0.5,-0.45,0.5},
{-0.2245,-0.45,-0.309, 0.2245,0.5,0.216},
{-0.27,-0.45,-0.16, -0.2245,0.5,0.185},
{-0.31,-0.45,-0.04, -0.27,0.5,0.155},
{-0.35,-0.45,0.08, -0.31,0.5,0.125},
{0.2245,-0.45,-0.16, 0.27,0.5,0.185},
{0.27,-0.45,-0.04, 0.31,0.5,0.155},
{0.31,-0.45,0.08, 0.35,0.5,0.125},
{-0.1875,-0.45,0.216, 0.1875,0.5,0.245},
{-0.125,-0.45,0.245, 0.125,0.5,0.29},
{-0.0625,-0.45,0.29, 0.0625,0.5,0.333},
{-0.02,-0.45,0.333, 0.02,0.5,0.37}}},
	drawtype="mesh",
	mesh = "iso54.obj"
})

minetest.register_node("stones:isor54", {
	description = "Pentagon / Square Joiner Rubble",
	paramtype = "light",
	paramtype2 = "facedir",
	tiles = {"rubble.png"},
	light_source = 0.1,
	groups = {vcol=0672, cracky=3, oddly_breakable_by_hand=1, not_in_creative_inventory=1},
	drop = "stones:isor54",
	collision_box={type="fixed",fixed={
{-0.5,-0.5,-0.5, 0.5,-0.45,0.5},
{-0.2245,-0.45,-0.309, 0.2245,0.5,0.216},
{-0.27,-0.45,-0.16, -0.2245,0.5,0.185},
{-0.31,-0.45,-0.04, -0.27,0.5,0.155},
{-0.35,-0.45,0.08, -0.31,0.5,0.125},
{0.2245,-0.45,-0.16, 0.27,0.5,0.185},
{0.27,-0.45,-0.04, 0.31,0.5,0.155},
{0.31,-0.45,0.08, 0.35,0.5,0.125},
{-0.1875,-0.45,0.216, 0.1875,0.5,0.245},
{-0.125,-0.45,0.245, 0.125,0.5,0.29},
{-0.0625,-0.45,0.29, 0.0625,0.5,0.333},
{-0.02,-0.45,0.333, 0.02,0.5,0.37}}},
	selection_box={type="fixed",fixed={
{-0.5,-0.5,-0.5, 0.5,-0.45,0.5},
{-0.2245,-0.45,-0.309, 0.2245,0.5,0.216},
{-0.27,-0.45,-0.16, -0.2245,0.5,0.185},
{-0.31,-0.45,-0.04, -0.27,0.5,0.155},
{-0.35,-0.45,0.08, -0.31,0.5,0.125},
{0.2245,-0.45,-0.16, 0.27,0.5,0.185},
{0.27,-0.45,-0.04, 0.31,0.5,0.155},
{0.31,-0.45,0.08, 0.35,0.5,0.125},
{-0.1875,-0.45,0.216, 0.1875,0.5,0.245},
{-0.125,-0.45,0.245, 0.125,0.5,0.29},
{-0.0625,-0.45,0.29, 0.0625,0.5,0.333},
{-0.02,-0.45,0.333, 0.02,0.5,0.37}}},
	drawtype="mesh",
	mesh = "iso54.obj"
})

minetest.register_node("stones:estruk", {
	description = "Star Struck HalfSlab",
	paramtype = "light",
	paramtype2 = "facedir",
	tiles = {"rock.png"},
	groups = {vcol=0.332, cracky=1, oddly_breakable_by_hand=1},
	drop = "stones:estruk",
	climbable = false,
	collision_box = {type="fixed",fixed={
{-0.5,-0.5,-0.25, 0.5,0,0.1},
{0.08,-0.5,-0.5, 0.5,0,-0.25},
{-0.5,-0.5,-0.5, -0.08,0,-0.25},
{0.34,-0.5,0.1, 0.5,0,0.5},
{0.21,-0.5,0.1, 0.34,0,0.41},
{-0.1,-0.5,0.1, 0.1,0,0.18},
{-0.34,-0.5,0.1, -0.21,0,0.41},
{-0.5,-0.5,0.1, -0.34,0,0.5}}},
	selection_box = {type="fixed",fixed={
{-0.5,-0.5,-0.25, 0.5,0,0.1},
{0.08,-0.5,-0.5, 0.5,0,-0.25},
{-0.5,-0.5,-0.5, -0.08,0,-0.25},
{0.34,-0.5,0.1, 0.5,0,0.5},
{0.21,-0.5,0.1, 0.34,0,0.41},
{-0.1,-0.5,0.1, 0.1,0,0.18},
{-0.34,-0.5,0.1, -0.21,0,0.41},
{-0.5,-0.5,0.1, -0.34,0,0.5}}},
	drawtype = "mesh",
	mesh = "estruk.obj"
})

minetest.register_node("stones:estruble", {
	description = "Star Struck HalfSlab Rubble",
	paramtype = "light",
	paramtype2 = "facedir",
	tiles = {"rubble.png"},
	groups = {vcol=0.332, cracky=3, oddly_breakable_by_hand=1, not_in_creative_inventory=1},
	drop = "stones:estruble",
	climbable = false,
	collision_box = {type="fixed",fixed={
{-0.5,-0.5,-0.25, 0.5,0,0.1},
{0.08,-0.5,-0.5, 0.5,0,-0.25},
{-0.5,-0.5,-0.5, -0.08,0,-0.25},
{0.34,-0.5,0.1, 0.5,0,0.5},
{0.21,-0.5,0.1, 0.34,0,0.41},
{-0.1,-0.5,0.1, 0.1,0,0.18},
{-0.34,-0.5,0.1, -0.21,0,0.41},
{-0.5,-0.5,0.1, -0.34,0,0.5}}},
	selection_box = {type="fixed",fixed={
{-0.5,-0.5,-0.25, 0.5,0,0.1},
{0.08,-0.5,-0.5, 0.5,0,-0.25},
{-0.5,-0.5,-0.5, -0.08,0,-0.25},
{0.34,-0.5,0.1, 0.5,0,0.5},
{0.21,-0.5,0.1, 0.34,0,0.41},
{-0.1,-0.5,0.1, 0.1,0,0.18},
{-0.34,-0.5,0.1, -0.21,0,0.41},
{-0.5,-0.5,0.1, -0.34,0,0.5}}},
	drawtype = "mesh",
	mesh = "estruk.obj"
})

minetest.register_node("stones:steps", {
	description = "Steps",
	paramtype = "light",
	paramtype2 = "facedir",
	tiles = {"rock.png"},
	groups = {vcol=0.5, cracky=1, oddly_breakable_by_hand=1},
	drop = "stones:steps",
	node_box = {type="fixed",fixed={
	{-0.5,-0.5,-0.5, 0.5,0,0},
	{-0.5,0,0, 0.5,0.5,0.5}}},
	drawtype = "nodebox"
})

minetest.register_node("stones:stru", {
	description = "Steps Rubble",
	paramtype = "light",
	paramtype2 = "facedir",
	tiles = {"rubble.png"},
	groups = {vcol=0.5, cracky=3, oddly_breakable_by_hand=1, not_in_creative_inventory=1},
	drop = "stones:stru",
	node_box = {type="fixed",fixed={
	{-0.5,-0.5,-0.5, 0.5,0,0},
	{-0.5,0,0, 0.5,0.5,0.5}}},
	drawtype = "nodebox"
})

minetest.register_node("stones:diagsteps_13", {
	description = "Quart to 3 Quart Steps",
	paramtype = "light",
	paramtype2 = "facedir",
	tiles = {"rock.png"},
	groups = {vcol=0.5, cracky=1, oddly_breakable_by_hand=1},
	drop = "stones:diagsteps_13",
	collision_box = {type="fixed",fixed={
{-0.5,-0.5,-0.5, 0,0,0.5},
{0,-0.5,-0.375, 0.0625,0,0.5},
{0.0625,-0.5,-0.25, 0.125,0,0.5},
{0.125,-0.5,-0.125, 0.1875,0,0.5},
{0.1875,-0.5,0, 0.25,0,0.5},
{0.25,-0.5,0.125, 0.3125,0,0.5},
{0.3125,-0.5,0.25, 0.375,0,0.5},
{0.375,-0.5,0.375, 0.4375,0,0.5},
{-0.5,0,-0.4375, -0.4375,0.5,0.5},
{-0.4375,0,-0.3125, -0.375,0.5,0.5},
{-0.375,0,-0.1875, -0.3125,0.5,0.5},
{-0.3125,0,-0.0625, -0.25,0.5,0.5},
{-0.25,0,0.0625, -0.1875,0.5,0.5},
{-0.1875,0,0.1875, -0.125,0.5,0.5},
{-0.125,0,0.3125, -0.0625,0.5,0.5},
{-0.0625,0,0.4375, 0,0.5,0.5}}},
		selection_box = {type="fixed",fixed={
{-0.5,-0.5,-0.5, 0,0,0.5},
{0,-0.5,-0.375, 0.0625,0,0.5},
{0.0625,-0.5,-0.25, 0.125,0,0.5},
{0.125,-0.5,-0.125, 0.1875,0,0.5},
{0.1875,-0.5,0, 0.25,0,0.5},
{0.25,-0.5,0.125, 0.3125,0,0.5},
{0.3125,-0.5,0.25, 0.375,0,0.5},
{0.375,-0.5,0.375, 0.4375,0,0.5},
{-0.5,0,-0.4375, -0.4375,0.5,0.5},
{-0.4375,0,-0.3125, -0.375,0.5,0.5},
{-0.375,0,-0.1875, -0.3125,0.5,0.5},
{-0.3125,0,-0.0625, -0.25,0.5,0.5},
{-0.25,0,0.0625, -0.1875,0.5,0.5},
{-0.1875,0,0.1875, -0.125,0.5,0.5},
{-0.125,0,0.3125, -0.0625,0.5,0.5},
{-0.0625,0,0.4375, 0,0.5,0.5}}},
	drawtype = "mesh",
	mesh = "diagsteps_13.obj"
})

minetest.register_node("stones:diagsterps_13", {
	description = "Quart to 3 Quart Steps Rubble",
	paramtype = "light",
	paramtype2 = "facedir",
	tiles = {"rubble.png"},
	groups = {vcol=0.5, cracky=3, oddly_breakable_by_hand=1, not_in_creative_inventory=1},
	drop = "stones:diagsterps_13",
	collision_box = {type="fixed",fixed={
{-0.5,-0.5,-0.5, 0,0,0.5},
{0,-0.5,-0.375, 0.0625,0,0.5},
{0.0625,-0.5,-0.25, 0.125,0,0.5},
{0.125,-0.5,-0.125, 0.1875,0,0.5},
{0.1875,-0.5,0, 0.25,0,0.5},
{0.25,-0.5,0.125, 0.3125,0,0.5},
{0.3125,-0.5,0.25, 0.375,0,0.5},
{0.375,-0.5,0.375, 0.4375,0,0.5},
{-0.5,0,-0.4375, -0.4375,0.5,0.5},
{-0.4375,0,-0.3125, -0.375,0.5,0.5},
{-0.375,0,-0.1875, -0.3125,0.5,0.5},
{-0.3125,0,-0.0625, -0.25,0.5,0.5},
{-0.25,0,0.0625, -0.1875,0.5,0.5},
{-0.1875,0,0.1875, -0.125,0.5,0.5},
{-0.125,0,0.3125, -0.0625,0.5,0.5},
{-0.0625,0,0.4375, 0,0.5,0.5}}},
		selection_box = {type="fixed",fixed={
{-0.5,-0.5,-0.5, 0,0,0.5},
{0,-0.5,-0.375, 0.0625,0,0.5},
{0.0625,-0.5,-0.25, 0.125,0,0.5},
{0.125,-0.5,-0.125, 0.1875,0,0.5},
{0.1875,-0.5,0, 0.25,0,0.5},
{0.25,-0.5,0.125, 0.3125,0,0.5},
{0.3125,-0.5,0.25, 0.375,0,0.5},
{0.375,-0.5,0.375, 0.4375,0,0.5},
{-0.5,0,-0.4375, -0.4375,0.5,0.5},
{-0.4375,0,-0.3125, -0.375,0.5,0.5},
{-0.375,0,-0.1875, -0.3125,0.5,0.5},
{-0.3125,0,-0.0625, -0.25,0.5,0.5},
{-0.25,0,0.0625, -0.1875,0.5,0.5},
{-0.1875,0,0.1875, -0.125,0.5,0.5},
{-0.125,0,0.3125, -0.0625,0.5,0.5},
{-0.0625,0,0.4375, 0,0.5,0.5}}},
	drawtype = "mesh",
	mesh = "diagsteps_13.obj"
})

minetest.register_node("stones:diagsteps_31", {
	description = "3 Quart to Quart Steps",
	paramtype = "light",
	paramtype2 = "facedir",
	tiles = {"rock.png"},
	groups = {vcol=0.5, cracky=1, oddly_breakable_by_hand=1},
	drop = "stones:diagsteps_31",
	selection_box = {type="fixed",fixed={
{-0.5,-0.5,0, 0.5,0,0.5},
{-0.5,-0.5,-0.0625, 0.375,0,0},
{-0.5,-0.5,-0.125, 0.25,0,-0.0625},
{-0.5,-0.5,-0.1875, 0.125,0,-0.125},
{-0.5,-0.5,-0.25, 0,0,-0.1875},
{-0.5,-0.5,-0.3125, -0.125,0,-0.25},
{-0.5,-0.5,-0.375, -0.25,0,-0.3125},
{-0.5,-0.5,-0.4375, -0.375,0,-0.375},
{-0.5,0,0.4375, 0.375,0.5,0.5},
{-0.5,0,0.375, 0.25,0.5,0.4375},
{-0.5,0,0.3125, 0.125,0.5,0.375},
{-0.5,0,0.25, 0,0.5,0.3125},
{-0.5,0,0.1875, -0.125,0.5,0.25},
{-0.5,0,0.125, -0.25,0.5,0.1875},
{-0.5,0,0.0625, -0.375,0.5,0.125}}},
	collision_box = {type="fixed",fixed={
{-0.5,-0.5,0, 0.5,0,0.5},
{-0.5,-0.5,-0.0625, 0.375,0,0},
{-0.5,-0.5,-0.125, 0.25,0,-0.0625},
{-0.5,-0.5,-0.1875, 0.125,0,-0.125},
{-0.5,-0.5,-0.25, 0,0,-0.1875},
{-0.5,-0.5,-0.3125, -0.125,0,-0.25},
{-0.5,-0.5,-0.375, -0.25,0,-0.3125},
{-0.5,-0.5,-0.4375, -0.375,0,-0.375},
{-0.5,0,0.4375, 0.4375,0.5,0.5},
{-0.5,0,0.375, 0.3125,0.5,0.4375},
{-0.5,0,0.3125, 0.1875,0.5,0.375},
{-0.5,0,0.25, 0.0625,0.5,0.3125},
{-0.5,0,0.1875, -0.0625,0.5,0.25},
{-0.5,0,0.125, -0.1875,0.5,0.1875},
{-0.5,0,0.0625, -0.3125,0.5,0.125},
{-0.5,0,0, -0.4375,0.5,0.0625}}},
	drawtype = "mesh",
	mesh = "diagsteps_31.obj"
})

minetest.register_node("stones:diagsterps_31", {
	description = "3 Quart to Quart Steps Rubble",
	paramtype = "light",
	paramtype2 = "facedir",
	tiles = {"rubble.png"},
	groups = {vcol=0.5, cracky=3, oddly_breakable_by_hand=1, not_in_creative_inventory=1},
	drop = "stones:diagsterps_31",
	selection_box = {type="fixed",fixed={
{-0.5,-0.5,0, 0.5,0,0.5},
{-0.5,-0.5,-0.0625, 0.375,0,0},
{-0.5,-0.5,-0.125, 0.25,0,-0.0625},
{-0.5,-0.5,-0.1875, 0.125,0,-0.125},
{-0.5,-0.5,-0.25, 0,0,-0.1875},
{-0.5,-0.5,-0.3125, -0.125,0,-0.25},
{-0.5,-0.5,-0.375, -0.25,0,-0.3125},
{-0.5,-0.5,-0.4375, -0.375,0,-0.375},
{-0.5,0,0.4375, 0.375,0.5,0.5},
{-0.5,0,0.375, 0.25,0.5,0.4375},
{-0.5,0,0.3125, 0.125,0.5,0.375},
{-0.5,0,0.25, 0,0.5,0.3125},
{-0.5,0,0.1875, -0.125,0.5,0.25},
{-0.5,0,0.125, -0.25,0.5,0.1875},
{-0.5,0,0.0625, -0.375,0.5,0.125}}},
	collision_box = {type="fixed",fixed={
{-0.5,-0.5,0, 0.5,0,0.5},
{-0.5,-0.5,-0.0625, 0.375,0,0},
{-0.5,-0.5,-0.125, 0.25,0,-0.0625},
{-0.5,-0.5,-0.1875, 0.125,0,-0.125},
{-0.5,-0.5,-0.25, 0,0,-0.1875},
{-0.5,-0.5,-0.3125, -0.125,0,-0.25},
{-0.5,-0.5,-0.375, -0.25,0,-0.3125},
{-0.5,-0.5,-0.4375, -0.375,0,-0.375},
{-0.5,0,0.4375, 0.4375,0.5,0.5},
{-0.5,0,0.375, 0.3125,0.5,0.4375},
{-0.5,0,0.3125, 0.1875,0.5,0.375},
{-0.5,0,0.25, 0.0625,0.5,0.3125},
{-0.5,0,0.1875, -0.0625,0.5,0.25},
{-0.5,0,0.125, -0.1875,0.5,0.1875},
{-0.5,0,0.0625, -0.3125,0.5,0.125},
{-0.5,0,0, -0.4375,0.5,0.0625}}},
	drawtype = "mesh",
	mesh = "diagsteps_31.obj"
})

minetest.register_node("stones:cish", {
	description = "Round Corner Slab",
	paramtype = "light",
	paramtype2 = "facedir",
	tiles = {"rock.png"},
	groups = {vcol=0.393, cracky=1, oddly_breakable_by_hand=1},
	drop = "stones:cish",
	collision_box = {type="fixed",fixed={
{-0.5,-0.5,-0.2071, 0.2071,0,0.5},
{-0.5,-0.5,-0.4375, -0.1464,0,-0.2071},
{0.2071,-0.5,0.1464, 0.4375,0,0.5},
{-0.1464,-0.5,-0.375, -0.0214,0,-0.2071},
{0.2071,-0.5,0.0214, 0.375,0,0.1464},
{-0.0214,-0.5,-0.3125, 0.0786,0,-0.2071},
{0.2071,-0.5,-0.0786, 0.3125,0,0.0214},
{-0.5,-0.5,-0.49, -0.375,0,-0.4375},
{0.4375,-0.5,0.375, 0.49,0,0.5}}},
	selection_box = {type="fixed",fixed={
{-0.5,-0.5,-0.2071, 0.2071,0,0.5},
{-0.5,-0.5,-0.4375, -0.1464,0,-0.2071},
{0.2071,-0.5,0.1464, 0.4375,0,0.5},
{-0.1464,-0.5,-0.375, -0.0214,0,-0.2071},
{0.2071,-0.5,0.0214, 0.375,0,0.1464},
{-0.0214,-0.5,-0.3125, 0.0786,0,-0.2071},
{0.2071,-0.5,-0.0786, 0.3125,0,0.0214},
{-0.5,-0.5,-0.49, -0.375,0,-0.4375},
{0.4375,-0.5,0.375, 0.49,0,0.5}}},
	drawtype = "mesh",
	mesh = "cish.obj"
})

minetest.register_node("stones:crish", {
	description = "Round Corner Slab Rubble",
	paramtype = "light",
	paramtype2 = "facedir",
	tiles = {"rubble.png"},
	groups = {vcol=0.393, cracky=3, oddly_breakable_by_hand=1, not_in_creative_inventory=1},
	drop = "stones:crish",
	collision_box = {type="fixed",fixed={
{-0.5,-0.5,-0.2071, 0.2071,0,0.5},
{-0.5,-0.5,-0.4375, -0.1464,0,-0.2071},
{0.2071,-0.5,0.1464, 0.4375,0,0.5},
{-0.1464,-0.5,-0.375, -0.0214,0,-0.2071},
{0.2071,-0.5,0.0214, 0.375,0,0.1464},
{-0.0214,-0.5,-0.3125, 0.0786,0,-0.2071},
{0.2071,-0.5,-0.0786, 0.3125,0,0.0214},
{-0.5,-0.5,-0.49, -0.375,0,-0.4375},
{0.4375,-0.5,0.375, 0.49,0,0.5}}},
	selection_box = {type="fixed",fixed={
{-0.5,-0.5,-0.2071, 0.2071,0,0.5},
{-0.5,-0.5,-0.4375, -0.1464,0,-0.2071},
{0.2071,-0.5,0.1464, 0.4375,0,0.5},
{-0.1464,-0.5,-0.375, -0.0214,0,-0.2071},
{0.2071,-0.5,0.0214, 0.375,0,0.1464},
{-0.0214,-0.5,-0.3125, 0.0786,0,-0.2071},
{0.2071,-0.5,-0.0786, 0.3125,0,0.0214},
{-0.5,-0.5,-0.49, -0.375,0,-0.4375},
{0.4375,-0.5,0.375, 0.49,0,0.5}}},
	drawtype = "mesh",
	mesh = "cish.obj"
})

minetest.register_node("stones:cis", {
	description = "Round Corner",
	paramtype = "light",
	paramtype2 = "facedir",
	tiles = {"rock.png"},
	groups = {vcol=0.785, cracky=1, oddly_breakable_by_hand=1},
	drop = "stones:cis",
	collision_box = {type="fixed",fixed={
{-0.5,-0.5,-0.2071, 0.2071,0.5,0.5},
{-0.5,-0.5,-0.4375, -0.1464,0.5,-0.2071},
{0.2071,-0.5,0.1464, 0.4375,0.5,0.5},
{-0.1464,-0.5,-0.375, -0.0214,0.5,-0.2071},
{0.2071,-0.5,0.0214, 0.375,0.5,0.1464},
{-0.0214,-0.5,-0.3125, 0.0786,0.5,-0.2071},
{0.2071,-0.5,-0.0786, 0.3125,0.5,0.0214},
{-0.5,-0.5,-0.49, -0.375,0.5,-0.4375},
{0.4375,-0.5,0.375, 0.49,0.5,0.5}}},
	selection_box = {type="fixed",fixed={
{-0.5,-0.5,-0.2071, 0.2071,0.5,0.5},
{-0.5,-0.5,-0.4375, -0.1464,0.5,-0.2071},
{0.2071,-0.5,0.1464, 0.4375,0.5,0.5},
{-0.1464,-0.5,-0.375, -0.0214,0.5,-0.2071},
{0.2071,-0.5,0.0214, 0.375,0.5,0.1464},
{-0.0214,-0.5,-0.3125, 0.0786,0.5,-0.2071},
{0.2071,-0.5,-0.0786, 0.3125,0.5,0.0214},
{-0.5,-0.5,-0.49, -0.375,0.5,-0.4375},
{0.4375,-0.5,0.375, 0.49,0.5,0.5}}},
	drawtype = "mesh",
	mesh = "cis.obj"
})

minetest.register_node("stones:cris", {
	description = "Round Corner Rubble",
	paramtype = "light",
	paramtype2 = "facedir",
	tiles = {"rubble.png"},
	groups = {vcol=0.785, cracky=3, oddly_breakable_by_hand=1, not_in_creative_inventory=1},
	drop = "stones:cris",
	collision_box = {type="fixed",fixed={
{-0.5,-0.5,-0.2071, 0.2071,0.5,0.5},
{-0.5,-0.5,-0.4375, -0.1464,0.5,-0.2071},
{0.2071,-0.5,0.1464, 0.4375,0.5,0.5},
{-0.1464,-0.5,-0.375, -0.0214,0.5,-0.2071},
{0.2071,-0.5,0.0214, 0.375,0.5,0.1464},
{-0.0214,-0.5,-0.3125, 0.0786,0.5,-0.2071},
{0.2071,-0.5,-0.0786, 0.3125,0.5,0.0214},
{-0.5,-0.5,-0.49, -0.375,0.5,-0.4375},
{0.4375,-0.5,0.375, 0.49,0.5,0.5}}},
	selection_box = {type="fixed",fixed={
{-0.5,-0.5,-0.2071, 0.2071,0.5,0.5},
{-0.5,-0.5,-0.4375, -0.1464,0.5,-0.2071},
{0.2071,-0.5,0.1464, 0.4375,0.5,0.5},
{-0.1464,-0.5,-0.375, -0.0214,0.5,-0.2071},
{0.2071,-0.5,0.0214, 0.375,0.5,0.1464},
{-0.0214,-0.5,-0.3125, 0.0786,0.5,-0.2071},
{0.2071,-0.5,-0.0786, 0.3125,0.5,0.0214},
{-0.5,-0.5,-0.49, -0.375,0.5,-0.4375},
{0.4375,-0.5,0.375, 0.49,0.5,0.5}}},
	drawtype = "mesh",
	mesh = "cis.obj"
})

minetest.register_node("stones:hex", {
	description = "Hexagonal Prism R3",
	paramtype = "light",
	paramtype2 = "facedir",
	tiles = {"default_stone_64.png"},
	groups = {vcol=1, cracky=1, oddly_breakable_by_hand=1},
	drop = "stones:hex",
	collision_box = {type="fixed",fixed={
{-0.1667,-0.1667,-0.1667, 0.1667,0.1667,0.1667},
{-0.3333,-0.5,-0.3333, 0,-0.1667,0},
{-0.3333,-0.6667,-0.3333, -0.0833,-0.5,-0.0883},
{0,0.1667,0, 0.3333,0.5,0.3333},
{0.0833,0.5,0.0833, 0.3333,0.6667,0.3333},
{-0.3333,0,0.1667, 0,0.3333,0.5},
{-0.3333,0.0833,0.5, -0.0833,0.3333,0.6667},
{0,-0.3333,-0.5, 0.3333,0,-0.1667},
{0.0833,-0.3333,-0.6667, 0.3333,-0.0833,-0.5},
{0.1667,0,-0.3333, 0.5,0.3333,0},
{0.5,0.0833,-0.3333, 0.6667,0.3333,-0.0833},
{-0.5,-0.3333,0, -0.1667,0,0.3333},
{-0.6667,-0.3333,0.0833, -0.5,-0.0833,0.3333}}},
		selection_box = {type="fixed",fixed={
{-0.1667,-0.1667,-0.1667, 0.1667,0.1667,0.1667},
{-0.3333,-0.5,-0.3333, 0,-0.1667,0},
{-0.3333,-0.6667,-0.3333, -0.0833,-0.5,-0.0883},
{0,0.1667,0, 0.3333,0.5,0.3333},
{0.0833,0.5,0.0833, 0.3333,0.6667,0.3333},
{-0.3333,0,0.1667, 0,0.3333,0.5},
{-0.3333,0.0833,0.5, -0.0833,0.3333,0.6667},
{0,-0.3333,-0.5, 0.3333,0,-0.1667},
{0.0833,-0.3333,-0.6667, 0.3333,-0.0833,-0.5},
{0.1667,0,-0.3333, 0.5,0.3333,0},
{0.5,0.0833,-0.3333, 0.6667,0.3333,-0.0833},
{-0.5,-0.3333,0, -0.1667,0,0.3333},
{-0.6667,-0.3333,0.0833, -0.5,-0.0833,0.3333}}},
	drawtype = "mesh",
	mesh = "hex.obj"
})

minetest.register_node("stones:hrex", {
	description = "Hexagonal Prism R3 Rubble",
	paramtype = "light",
	paramtype2 = "facedir",
	tiles = {"default_rubble_64.png"},
	groups = {vcol=1, cracky=3, oddly_breakable_by_hand=1, not_in_creative_inventory=1},
	drop = "stones:hrex",
	collision_box = {type="fixed",fixed={
{-0.1667,-0.1667,-0.1667, 0.1667,0.1667,0.1667},
{-0.3333,-0.5,-0.3333, 0,-0.1667,0},
{-0.3333,-0.6667,-0.3333, -0.0833,-0.5,-0.0883},
{0,0.1667,0, 0.3333,0.5,0.3333},
{0.0833,0.5,0.0833, 0.3333,0.6667,0.3333},
{-0.3333,0,0.1667, 0,0.3333,0.5},
{-0.3333,0.0833,0.5, -0.0833,0.3333,0.6667},
{0,-0.3333,-0.5, 0.3333,0,-0.1667},
{0.0833,-0.3333,-0.6667, 0.3333,-0.0833,-0.5},
{0.1667,0,-0.3333, 0.5,0.3333,0},
{0.5,0.0833,-0.3333, 0.6667,0.3333,-0.0833},
{-0.5,-0.3333,0, -0.1667,0,0.3333},
{-0.6667,-0.3333,0.0833, -0.5,-0.0833,0.3333}}},
		selection_box = {type="fixed",fixed={
{-0.1667,-0.1667,-0.1667, 0.1667,0.1667,0.1667},
{-0.3333,-0.5,-0.3333, 0,-0.1667,0},
{-0.3333,-0.6667,-0.3333, -0.0833,-0.5,-0.0883},
{0,0.1667,0, 0.3333,0.5,0.3333},
{0.0833,0.5,0.0833, 0.3333,0.6667,0.3333},
{-0.3333,0,0.1667, 0,0.3333,0.5},
{-0.3333,0.0833,0.5, -0.0833,0.3333,0.6667},
{0,-0.3333,-0.5, 0.3333,0,-0.1667},
{0.0833,-0.3333,-0.6667, 0.3333,-0.0833,-0.5},
{0.1667,0,-0.3333, 0.5,0.3333,0},
{0.5,0.0833,-0.3333, 0.6667,0.3333,-0.0833},
{-0.5,-0.3333,0, -0.1667,0,0.3333},
{-0.6667,-0.3333,0.0833, -0.5,-0.0833,0.3333}}},
	drawtype = "mesh",
	mesh = "hex.obj"
})

minetest.register_node("stones:hexp", {
	description = "Hexagonal Lattice Pyramid Joinder",
	paramtype = "light",
	paramtype2 = "facedir",
	tiles = {"default_stone_64.png"},
	groups = {vcol=0.056, cracky=1, oddly_breakable_by_hand=1},
	drop = "stones:hexp",
	collision_box = {type="fixed",fixed={
{-0.4,-0.5,0.125, -0.0625,-0.4,0.4},
{-0.0625,-0.5,0.25, 0.15,-0.4,0.4},
{-0.4,-0.5,-0.125, -0.2143,-0.4,0.125},
{-0.3125,-0.4,0.09, -0.09,-0.3125,0.3125}}},
		selection_box = {type="fixed",fixed={
{-0.4,-0.5,0.125, -0.0625,-0.4,0.4},
{-0.0625,-0.5,0.25, 0.15,-0.4,0.4},
{-0.4,-0.5,-0.125, -0.2143,-0.4,0.125},
{-0.3125,-0.4,0.09, -0.09,-0.3125,0.3125}}},
	drawtype = "mesh",
	mesh = "hexp.obj"
})

minetest.register_node("stones:hrexp", {
	description = "Hexagonal Lattice Pyramid Joinder Rubble",
	paramtype = "light",
	paramtype2 = "facedir",
	tiles = {"default_rubble_64.png"},
	groups = {vcol=0.056, cracky=3, oddly_breakable_by_hand=1, not_in_creative_inventory=1},
	drop = "stones:hrexp",
	collision_box = {type="fixed",fixed={
{-0.4,-0.5,0.125, -0.0625,-0.4,0.4},
{-0.0625,-0.5,0.25, 0.15,-0.4,0.4},
{-0.4,-0.5,-0.125, -0.2143,-0.4,0.125},
{-0.3125,-0.4,0.09, -0.09,-0.3125,0.3125}}},
		selection_box = {type="fixed",fixed={
{-0.4,-0.5,0.125, -0.0625,-0.4,0.4},
{-0.0625,-0.5,0.25, 0.15,-0.4,0.4},
{-0.4,-0.5,-0.125, -0.2143,-0.4,0.125},
{-0.3125,-0.4,0.09, -0.09,-0.3125,0.3125}}},
	drawtype = "mesh",
	mesh = "hexp.obj"
})

minetest.register_node("stones:hexar", {
	description = "Hexagonal Lattice Arrowhead Joinder",
	paramtype = "light",
	paramtype2 = "facedir",
	tiles = {"default_stone_64.png"},
	groups = {vcol=0.111, cracky=1, oddly_breakable_by_hand=1},
	drop = "stones:hexar",
	collision_box = {type="fixed",fixed={
{-0.5,-0.3572,-0.0714, -0.3572,-0.2143,0.5},
{-0.3572,-0.3572,0.3572, 0.0714,-0.2143,0.5},
{-0.5,-0.2143,0.0714, -0.3572,-0.0714,0.5},
{-0.3572,-0.2143,0.2143, -0.2143,-0.0714,0.5},
{-0.2143,-0.2143,0.3572, -0.0714,-0.0714,0.5},
{-0.5,-0.0714,0.2143, -0.3572,0.0714,0.5},
{-0.3572,-0.0714,0.3572, -0.2143,0.0714,0.5},
{-0.5,0.0714,0.3572, -0.3572,0.2143,0.5}}},
		selection_box = {type="fixed",fixed={
{-0.5,-0.3572,-0.0714, -0.3572,-0.2143,0.5},
{-0.3572,-0.3572,0.3572, 0.0714,-0.2143,0.5},
{-0.5,-0.2143,0.0714, -0.3572,-0.0714,0.5},
{-0.3572,-0.2143,0.2143, -0.2143,-0.0714,0.5},
{-0.2143,-0.2143,0.3572, -0.0714,-0.0714,0.5},
{-0.5,-0.0714,0.2143, -0.3572,0.0714,0.5},
{-0.3572,-0.0714,0.3572, -0.2143,0.0714,0.5},
{-0.5,0.0714,0.3572, -0.3572,0.2143,0.5}}},
	drawtype = "mesh",
	mesh = "hexar.obj"
})

minetest.register_node("stones:hrexar", {
	description = "Hexagonal Lattice Arrowhead Joinder Rubble",
	paramtype = "light",
	paramtype2 = "facedir",
	tiles = {"default_rubble_64.png"},
	groups = {vcol=0.111, cracky=3, oddly_breakable_by_hand=1, not_in_creative_inventory=1},
	drop = "stones:hrexar",
	collision_box = {type="fixed",fixed={
{-0.5,-0.3572,-0.0714, -0.3572,-0.2143,0.5},
{-0.3572,-0.3572,0.3572, 0.0714,-0.2143,0.5},
{-0.5,-0.2143,0.0714, -0.3572,-0.0714,0.5},
{-0.3572,-0.2143,0.2143, -0.2143,-0.0714,0.5},
{-0.2143,-0.2143,0.3572, -0.0714,-0.0714,0.5},
{-0.5,-0.0714,0.2143, -0.3572,0.0714,0.5},
{-0.3572,-0.0714,0.3572, -0.2143,0.0714,0.5},
{-0.5,0.0714,0.3572, -0.3572,0.2143,0.5}}},
		selection_box = {type="fixed",fixed={
{-0.5,-0.3572,-0.0714, -0.3572,-0.2143,0.5},
{-0.3572,-0.3572,0.3572, 0.0714,-0.2143,0.5},
{-0.5,-0.2143,0.0714, -0.3572,-0.0714,0.5},
{-0.3572,-0.2143,0.2143, -0.2143,-0.0714,0.5},
{-0.2143,-0.2143,0.3572, -0.0714,-0.0714,0.5},
{-0.5,-0.0714,0.2143, -0.3572,0.0714,0.5},
{-0.3572,-0.0714,0.3572, -0.2143,0.0714,0.5},
{-0.5,0.0714,0.3572, -0.3572,0.2143,0.5}}},
	drawtype = "mesh",
	mesh = "hexar.obj"
})

minetest.register_node("stones:arschil", {
	description = "Shallow to Arch Left Slim",
	paramtype = "light",
	paramtype2 = "facedir",
	tiles = {"rock.png"},
	drawtype = "mesh",
	mesh = "arschil.obj",
	climbable = false,
	selection_box = {type = "fixed", fixed = {
{-0.5,-0.4375,0.4938, -0.4688,0.5,0.5},
{-0.4688,-0.2344,0.4813, -0.4063,0.5,0.5},
{-0.4063,-0.0469,0.45, -0.3438,0.5,0.5},
{-0.3438,0.0156,0.4188, -0.2813,0.5,0.5},
{-0.2813,0.1719,0.3875, -0.1875,0.5,0.5},
{-0.1875,0.2344,0.3406, -0.125,0.5,0.5},
{-0.125,0.2969,0.3, 0,0.5,0.5},
{0,0.3594,0.2438, 0.0625,0.5,0.5},
{0.0625,0.4219,0.2, 0.25,0.5,0.5},
{0.25,0.4844,0.0938, 0.5,0.5,0.5}}},
	collision_box = {type = "fixed", fixed = {
{-0.5,-0.4375,0.4938, -0.4688,0.5,0.5},
{-0.4688,-0.2344,0.4813, -0.4063,0.5,0.5},
{-0.4063,-0.0469,0.45, -0.3438,0.5,0.5},
{-0.3438,0.0156,0.4188, -0.2813,0.5,0.5},
{-0.2813,0.1719,0.3875, -0.1875,0.5,0.5},
{-0.1875,0.2344,0.3406, -0.125,0.5,0.5},
{-0.125,0.2969,0.3, 0,0.5,0.5},
{0,0.3594,0.2438, 0.0625,0.5,0.5},
{0.0625,0.4219,0.2, 0.25,0.5,0.5},
{0.25,0.4844,0.0938, 0.5,0.5,0.5}}},
	groups = {vcol=0.102, cracky=1,oddly_breakable_by_hand=1},
	drop = "stones:arschil"
})

minetest.register_node("stones:aruschil", {
	description = "Shallow to Arch Left Slim Rubble",
	paramtype = "light",
	paramtype2 = "facedir",
	tiles = {"rubble.png"},
	drawtype = "mesh",
	mesh = "arschil.obj",
	climbable = false,
	selection_box = {type = "fixed", fixed = {
{-0.5,-0.4375,0.4938, -0.4688,0.5,0.5},
{-0.4688,-0.2344,0.4813, -0.4063,0.5,0.5},
{-0.4063,-0.0469,0.45, -0.3438,0.5,0.5},
{-0.3438,0.0156,0.4188, -0.2813,0.5,0.5},
{-0.2813,0.1719,0.3875, -0.1875,0.5,0.5},
{-0.1875,0.2344,0.3406, -0.125,0.5,0.5},
{-0.125,0.2969,0.3, 0,0.5,0.5},
{0,0.3594,0.2438, 0.0625,0.5,0.5},
{0.0625,0.4219,0.2, 0.25,0.5,0.5},
{0.25,0.4844,0.0938, 0.5,0.5,0.5}}},
	collision_box = {type = "fixed", fixed = {
{-0.5,-0.4375,0.4938, -0.4688,0.5,0.5},
{-0.4688,-0.2344,0.4813, -0.4063,0.5,0.5},
{-0.4063,-0.0469,0.45, -0.3438,0.5,0.5},
{-0.3438,0.0156,0.4188, -0.2813,0.5,0.5},
{-0.2813,0.1719,0.3875, -0.1875,0.5,0.5},
{-0.1875,0.2344,0.3406, -0.125,0.5,0.5},
{-0.125,0.2969,0.3, 0,0.5,0.5},
{0,0.3594,0.2438, 0.0625,0.5,0.5},
{0.0625,0.4219,0.2, 0.25,0.5,0.5},
{0.25,0.4844,0.0938, 0.5,0.5,0.5}}},
	groups = {vcol=0.102, cracky=3,oddly_breakable_by_hand=1, not_in_creative_inventory=1},
	drop = "stones:arschil"
})

minetest.register_node("stones:arcshil", {
	description = "Arch to Shallow Left Slim",
	paramtype = "light",
	paramtype2 = "facedir",
	tiles = {"rock.png"},
	drawtype = "mesh",
	mesh = "arcshil.obj",
	climbable = false,
	selection_box = {type = "fixed", fixed = {
{-0.5,-0.4375,0, -0.4688,0.5,0.5},
{-0.4688,-0.2344,0.0469, -0.4063,0.5,0.5},
{-0.4063,-0.0469,0.0781, -0.3438,0.5,0.5},
{-0.3438,0.0156,0.1094, -0.2813,0.5,0.5},
{-0.2813,0.1719,0.1563, -0.1875,0.5,0.5},
{-0.1875,0.2344,0.1875, -0.125,0.5,0.5},
{-0.125,0.2969,0.25, 0,0.5,0.5},
{0,0.3594,0.2813, 0.0625,0.5,0.5},
{0.0625,0.4219,0.375, 0.25,0.5,0.5},
{0.25,0.4844,0.4375, 0.375,0.5,0.5}}},
	collision_box = {type = "fixed", fixed = {
{-0.5,-0.4375,0, -0.4688,0.5,0.5},
{-0.4688,-0.2344,0.0469, -0.4063,0.5,0.5},
{-0.4063,-0.0469,0.0781, -0.3438,0.5,0.5},
{-0.3438,0.0156,0.1094, -0.2813,0.5,0.5},
{-0.2813,0.1719,0.1563, -0.1875,0.5,0.5},
{-0.1875,0.2344,0.1875, -0.125,0.5,0.5},
{-0.125,0.2969,0.25, 0,0.5,0.5},
{0,0.3594,0.2813, 0.0625,0.5,0.5},
{0.0625,0.4219,0.375, 0.25,0.5,0.5},
{0.25,0.4844,0.4375, 0.375,0.5,0.5}}},
	groups = {vcol=0.089, cracky=1, oddly_breakable_by_hand=1},
	drop = "stones:arcshil"
})

minetest.register_node("stones:arucshil", {
	description = "Arch to Shallow Left Slim Rubble",
	paramtype = "light",
	paramtype2 = "facedir",
	tiles = {"rubble.png"},
	drawtype = "mesh",
	mesh = "arcshil.obj",
	climbable = false,
	selection_box = {type = "fixed", fixed = {
{-0.5,-0.4375,0, -0.4688,0.5,0.5},
{-0.4688,-0.2344,0.0469, -0.4063,0.5,0.5},
{-0.4063,-0.0469,0.0781, -0.3438,0.5,0.5},
{-0.3438,0.0156,0.1094, -0.2813,0.5,0.5},
{-0.2813,0.1719,0.1563, -0.1875,0.5,0.5},
{-0.1875,0.2344,0.1875, -0.125,0.5,0.5},
{-0.125,0.2969,0.25, 0,0.5,0.5},
{0,0.3594,0.2813, 0.0625,0.5,0.5},
{0.0625,0.4219,0.375, 0.25,0.5,0.5},
{0.25,0.4844,0.4375, 0.375,0.5,0.5}}},
	collision_box = {type = "fixed", fixed = {
{-0.5,-0.4375,0, -0.4688,0.5,0.5},
{-0.4688,-0.2344,0.0469, -0.4063,0.5,0.5},
{-0.4063,-0.0469,0.0781, -0.3438,0.5,0.5},
{-0.3438,0.0156,0.1094, -0.2813,0.5,0.5},
{-0.2813,0.1719,0.1563, -0.1875,0.5,0.5},
{-0.1875,0.2344,0.1875, -0.125,0.5,0.5},
{-0.125,0.2969,0.25, 0,0.5,0.5},
{0,0.3594,0.2813, 0.0625,0.5,0.5},
{0.0625,0.4219,0.375, 0.25,0.5,0.5},
{0.25,0.4844,0.4375, 0.375,0.5,0.5}}},
	groups = {vcol=0.089, cracky=3, oddly_breakable_by_hand=1, not_in_creative_inventory=1},
	drop = "stones:arcshil"
})


minetest.register_node("stones:arschir", {
	description = "Shallow to Arch Right Slim",
	paramtype = "light",
	paramtype2 = "facedir",
	tiles = {"rock.png"},
	drawtype = "mesh",
	mesh = "arschir.obj",
	climbable = false,
	selection_box = {type = "fixed", fixed = {
{0.4688,-0.4375,0.4906, 0.5,0.5,0.5},
{0.4063,-0.2344,0.4844, 0.4688,0.5,0.5},
{0.3438,-0.0469,0.4531, 0.4063,0.5,0.5},
{0.2813,0.0156,0.4219, 0.3438,0.5,0.5},
{0.1875,0.1719,0.3906, 0.2813,0.5,0.5},
{0.125,0.2344,0.3438, 0.1875,0.5,0.5},
{0,0.2969,0.3125, 0.125,0.5,0.5},
{-0.0625,0.3594,0.25, 0,0.5,0.5},
{-0.25,0.4219,0.2188, -0.0625,0.5,0.5},
{-0.5,0.4844,0.125, -0.25,0.5,0.5}}},
	collision_box = {type = "fixed", fixed = {
{0.4688,-0.4375,0.4906, 0.5,0.5,0.5},
{0.4063,-0.2344,0.4844, 0.4688,0.5,0.5},
{0.3438,-0.0469,0.4531, 0.4063,0.5,0.5},
{0.2813,0.0156,0.4219, 0.3438,0.5,0.5},
{0.1875,0.1719,0.3906, 0.2813,0.5,0.5},
{0.125,0.2344,0.3438, 0.1875,0.5,0.5},
{0,0.2969,0.3125, 0.125,0.5,0.5},
{-0.0625,0.3594,0.25, 0,0.5,0.5},
{-0.25,0.4219,0.2188, -0.0625,0.5,0.5},
{-0.5,0.4844,0.125, -0.25,0.5,0.5}}},
	groups = {vcol=0.102, cracky=1,oddly_breakable_by_hand=1},
	drop = "stones:arschir"
})

minetest.register_node("stones:aruschir", {
	description = "Shallow to Arch Right Slim Rubble",
	paramtype = "light",
	paramtype2 = "facedir",
	tiles = {"rubble.png"},
	drawtype = "mesh",
	mesh = "arschir.obj",
	climbable = false,
	selection_box = {type = "fixed", fixed = {
{0.4688,-0.4375,0.4906, 0.5,0.5,0.5},
{0.4063,-0.2344,0.4844, 0.4688,0.5,0.5},
{0.3438,-0.0469,0.4531, 0.4063,0.5,0.5},
{0.2813,0.0156,0.4219, 0.3438,0.5,0.5},
{0.1875,0.1719,0.3906, 0.2813,0.5,0.5},
{0.125,0.2344,0.3438, 0.1875,0.5,0.5},
{0,0.2969,0.3125, 0.125,0.5,0.5},
{-0.0625,0.3594,0.25, 0,0.5,0.5},
{-0.25,0.4219,0.2188, -0.0625,0.5,0.5},
{-0.5,0.4844,0.125, -0.25,0.5,0.5}}},
	collision_box = {type = "fixed", fixed = {
{0.4688,-0.4375,0.4906, 0.5,0.5,0.5},
{0.4063,-0.2344,0.4844, 0.4688,0.5,0.5},
{0.3438,-0.0469,0.4531, 0.4063,0.5,0.5},
{0.2813,0.0156,0.4219, 0.3438,0.5,0.5},
{0.1875,0.1719,0.3906, 0.2813,0.5,0.5},
{0.125,0.2344,0.3438, 0.1875,0.5,0.5},
{0,0.2969,0.3125, 0.125,0.5,0.5},
{-0.0625,0.3594,0.25, 0,0.5,0.5},
{-0.25,0.4219,0.2188, -0.0625,0.5,0.5},
{-0.5,0.4844,0.125, -0.25,0.5,0.5}}},
	groups = {vcol=0.102, cracky=3,oddly_breakable_by_hand=1, not_in_creative_inventory=1},
	drop = "stones:aruschir"
})

minetest.register_node("stones:arcshir", {
	description = "Arch to Shallow Right Slim",
	paramtype = "light",
	paramtype2 = "facedir",
	tiles = {"rock.png"},
	drawtype = "mesh",
	mesh = "arcshir.obj",
	climbable = false,
	selection_box = {type = "fixed", fixed = {
{0.4688,-0.4375,0.0156, 0.5,0.5,0.5},
{0.4063,-0.2344,0.0469, 0.4688,0.5,0.5},
{0.3438,-0.0469,0.0781, 0.4063,0.5,0.5},
{0.2813,0.0156,0.1094, 0.3438,0.5,0.5},
{0.1875,0.1719,0.1563, 0.2813,0.5,0.5},
{0.125,0.2344,0.1875, 0.1875,0.5,0.5},
{0,0.2969,0.25, 0.125,0.5,0.5},
{-0.0625,0.3594,0.2813, 0,0.5,0.5},
{-0.25,0.4219,0.375, -0.0625,0.5,0.5},
{-0.375,0.4844,0.4375, -0.25,0.5,0.5}}},
	collision_box = {type = "fixed", fixed = {
{0.4688,-0.4375,0.0156, 0.5,0.5,0.5},
{0.4063,-0.2344,0.0469, 0.4688,0.5,0.5},
{0.3438,-0.0469,0.0781, 0.4063,0.5,0.5},
{0.2813,0.0156,0.1094, 0.3438,0.5,0.5},
{0.1875,0.1719,0.1563, 0.2813,0.5,0.5},
{0.125,0.2344,0.1875, 0.1875,0.5,0.5},
{0,0.2969,0.25, 0.125,0.5,0.5},
{-0.0625,0.3594,0.2813, 0,0.5,0.5},
{-0.25,0.4219,0.375, -0.0625,0.5,0.5},
{-0.375,0.4844,0.4375, -0.25,0.5,0.5}}},
	groups = {vcol=0.089, cracky=1,oddly_breakable_by_hand=1},
	drop = "stones:arcshir"
})

minetest.register_node("stones:arucshir", {
	description = "Arch to Shallow Right Slim Rubble",
	paramtype = "light",
	paramtype2 = "facedir",
	tiles = {"rubble.png"},
	drawtype = "mesh",
	mesh = "arcshir.obj",
	climbable = false,
	selection_box = {type = "fixed", fixed = {
{0.4688,-0.4375,0.0156, 0.5,0.5,0.5},
{0.4063,-0.2344,0.0469, 0.4688,0.5,0.5},
{0.3438,-0.0469,0.0781, 0.4063,0.5,0.5},
{0.2813,0.0156,0.1094, 0.3438,0.5,0.5},
{0.1875,0.1719,0.1563, 0.2813,0.5,0.5},
{0.125,0.2344,0.1875, 0.1875,0.5,0.5},
{0,0.2969,0.25, 0.125,0.5,0.5},
{-0.0625,0.3594,0.2813, 0,0.5,0.5},
{-0.25,0.4219,0.375, -0.0625,0.5,0.5},
{-0.375,0.4844,0.4375, -0.25,0.5,0.5}}},
	collision_box = {type = "fixed", fixed = {
{0.4688,-0.4375,0.0156, 0.5,0.5,0.5},
{0.4063,-0.2344,0.0469, 0.4688,0.5,0.5},
{0.3438,-0.0469,0.0781, 0.4063,0.5,0.5},
{0.2813,0.0156,0.1094, 0.3438,0.5,0.5},
{0.1875,0.1719,0.1563, 0.2813,0.5,0.5},
{0.125,0.2344,0.1875, 0.1875,0.5,0.5},
{0,0.2969,0.25, 0.125,0.5,0.5},
{-0.0625,0.3594,0.2813, 0,0.5,0.5},
{-0.25,0.4219,0.375, -0.0625,0.5,0.5},
{-0.375,0.4844,0.4375, -0.25,0.5,0.5}}},
	groups = {vcol=0.089, cracky=3,oddly_breakable_by_hand=1, not_in_creative_inventory=1},
	drop = "stones:arucshir"
})

minetest.register_node("stones:diagsteps_52s", {
	description = "*2 Steps R5/2 S",
	paramtype = "light",
	paramtype2 = "facedir",
	tiles = {"rock.png"},
	groups = {vcol=0.75, cracky=1, oddly_breakable_by_hand=1},
	drop = "stones:diagsteps_52s",
	collision_box = {type="fixed",fixed={
{-0.5,-0.5,-0.5, 0.5,0,0},
{-0.5,-0.5,0, 0.375,0,0.0625},
{-0.5,-0.5,0.0625, 0.25,0,0.125},
{-0.5,-0.5,0.125, 0.125,0,0.1875},
{-0.5,-0.5,0.1875, 0,0,0.25},
{-0.5,-0.5,0.25, -0.125,0,0.3125},
{-0.5,-0.5,0.3125, -0.25,0,0.375},
{-0.5,-0.5,0.375, -0.375,0,0.4375},
{0.375,0,-0.4375, 0.5,0.5,-0.375},
{0.25,0,-0.375, 0.5,0.5,-0.3125},
{0.125,0,-0.3125, 0.5,0.5,-0.25},
{0,0,-0.25, 0.5,0.5,-0.1875},
{-0.125,0,-0.1875, 0.5,0.5,-0.125},
{-0.25,0,-0.125, 0.5,0.5,-0.0625},
{-0.375,0,-0.0625, 0.5,0.5,0},
{-0.5,0,0, 0.5,0.5,0.5}}},
		selection_box = {type="fixed",fixed={
{-0.5,-0.5,-0.5, 0.5,0,0},
{-0.5,-0.5,0, 0.375,0,0.0625},
{-0.5,-0.5,0.0625, 0.25,0,0.125},
{-0.5,-0.5,0.125, 0.125,0,0.1875},
{-0.5,-0.5,0.1875, 0,0,0.25},
{-0.5,-0.5,0.25, -0.125,0,0.3125},
{-0.5,-0.5,0.3125, -0.25,0,0.375},
{-0.5,-0.5,0.375, -0.375,0,0.4375},
{0.375,0,-0.4375, 0.5,0.5,-0.375},
{0.25,0,-0.375, 0.5,0.5,-0.3125},
{0.125,0,-0.3125, 0.5,0.5,-0.25},
{0,0,-0.25, 0.5,0.5,-0.1875},
{-0.125,0,-0.1875, 0.5,0.5,-0.125},
{-0.25,0,-0.125, 0.5,0.5,-0.0625},
{-0.375,0,-0.0625, 0.5,0.5,0},
{-0.5,0,0, 0.5,0.5,0.5}}},
	drawtype = "mesh",
	mesh = "diagsteps_52s.obj"
})

minetest.register_node("stones:diagsterps_52s", {
	description = "*2 Steps R5/2 S Rubble",
	paramtype = "light",
	paramtype2 = "facedir",
	tiles = {"rubble.png"},
	groups = {vcol=0.75, cracky=3, oddly_breakable_by_hand=1, not_in_creative_inventory=1},
	drop = "stones:diagsterps_52s",
	collision_box = {type="fixed",fixed={
{-0.5,-0.5,-0.5, 0.5,0,0},
{-0.5,-0.5,0, 0.375,0,0.0625},
{-0.5,-0.5,0.0625, 0.25,0,0.125},
{-0.5,-0.5,0.125, 0.125,0,0.1875},
{-0.5,-0.5,0.1875, 0,0,0.25},
{-0.5,-0.5,0.25, -0.125,0,0.3125},
{-0.5,-0.5,0.3125, -0.25,0,0.375},
{-0.5,-0.5,0.375, -0.375,0,0.4375},
{0.375,0,-0.4375, 0.5,0.5,-0.375},
{0.25,0,-0.375, 0.5,0.5,-0.3125},
{0.125,0,-0.3125, 0.5,0.5,-0.25},
{0,0,-0.25, 0.5,0.5,-0.1875},
{-0.125,0,-0.1875, 0.5,0.5,-0.125},
{-0.25,0,-0.125, 0.5,0.5,-0.0625},
{-0.375,0,-0.0625, 0.5,0.5,0},
{-0.5,0,0, 0.5,0.5,0.5}}},
		selection_box = {type="fixed",fixed={
{-0.5,-0.5,-0.5, 0.5,0,0},
{-0.5,-0.5,0, 0.375,0,0.0625},
{-0.5,-0.5,0.0625, 0.25,0,0.125},
{-0.5,-0.5,0.125, 0.125,0,0.1875},
{-0.5,-0.5,0.1875, 0,0,0.25},
{-0.5,-0.5,0.25, -0.125,0,0.3125},
{-0.5,-0.5,0.3125, -0.25,0,0.375},
{-0.5,-0.5,0.375, -0.375,0,0.4375},
{0.375,0,-0.4375, 0.5,0.5,-0.375},
{0.25,0,-0.375, 0.5,0.5,-0.3125},
{0.125,0,-0.3125, 0.5,0.5,-0.25},
{0,0,-0.25, 0.5,0.5,-0.1875},
{-0.125,0,-0.1875, 0.5,0.5,-0.125},
{-0.25,0,-0.125, 0.5,0.5,-0.0625},
{-0.375,0,-0.0625, 0.5,0.5,0},
{-0.5,0,0, 0.5,0.5,0.5}}},
	drawtype = "mesh",
	mesh = "diagsteps_52s.obj"
})

minetest.register_node("stones:diagsteps_58s", {
	description = "*2 Steps R5/2 5/8 S",
	paramtype = "light",
	paramtype2 = "facedir",
	tiles = {"rock.png"},
	groups = {vcol=0.75, cracky=1, oddly_breakable_by_hand=1, not_in_creative_inventory=1},
	drop = "stones:diagsteps_58s",
	collision_box = {type="fixed",fixed={
{-0.5,-0.5,-0.5, 0.5,0,0},
{-0.5,-0.5,0, 0.375,0.5,0.0625},
{-0.5,-0.5,0.0625, 0.25,0.5,0.125},
{-0.5,-0.5,0.125, 0.125,0.5,0.1875},
{-0.5,-0.5,0.1875, 0,0.5,0.25},
{-0.5,-0.5,0.25, -0.125,0.5,0.3125},
{-0.5,-0.5,0.3125, -0.25,0.5,0.375},
{-0.5,-0.5,0.375, -0.375,0.5,0.4375},
{0.375,0,-0.4375, 0.5,0.5,-0.375},
{0.25,0,-0.375, 0.5,0.5,-0.3125},
{0.125,0,-0.3125, 0.5,0.5,-0.25},
{0,0,-0.25, 0.5,0.5,-0.1875},
{-0.125,0,-0.1875, 0.5,0.5,-0.125},
{-0.25,0,-0.125, 0.5,0.5,-0.0625},
{-0.375,0,-0.0625, 0.5,0.5,0}}},
		selection_box = {type="fixed",fixed={
{-0.5,-0.5,-0.5, 0.5,0,0},
{-0.5,-0.5,0, 0.375,0.5,0.0625},
{-0.5,-0.5,0.0625, 0.25,0.5,0.125},
{-0.5,-0.5,0.125, 0.125,0.5,0.1875},
{-0.5,-0.5,0.1875, 0,0.5,0.25},
{-0.5,-0.5,0.25, -0.125,0.5,0.3125},
{-0.5,-0.5,0.3125, -0.25,0.5,0.375},
{-0.5,-0.5,0.375, -0.375,0.5,0.4375},
{0.375,0,-0.4375, 0.5,0.5,-0.375},
{0.25,0,-0.375, 0.5,0.5,-0.3125},
{0.125,0,-0.3125, 0.5,0.5,-0.25},
{0,0,-0.25, 0.5,0.5,-0.1875},
{-0.125,0,-0.1875, 0.5,0.5,-0.125},
{-0.25,0,-0.125, 0.5,0.5,-0.0625},
{-0.375,0,-0.0625, 0.5,0.5,0}}},
	drawtype = "mesh",
	mesh = "diagsteps_58s.obj"
})

minetest.register_node("stones:diagsterps_58s", {
	description = "*2 Steps R5/2 5/8 S Rubble",
	paramtype = "light",
	paramtype2 = "facedir",
	tiles = {"rubble.png"},
	groups = {vcol=0.75, cracky=3, oddly_breakable_by_hand=1, not_in_creative_inventory=1},
	drop = "stones:diagsterps_58s",
	collision_box = {type="fixed",fixed={
{-0.5,-0.5,-0.5, 0.5,0,0},
{-0.5,-0.5,0, 0.375,0.5,0.0625},
{-0.5,-0.5,0.0625, 0.25,0.5,0.125},
{-0.5,-0.5,0.125, 0.125,0.5,0.1875},
{-0.5,-0.5,0.1875, 0,0.5,0.25},
{-0.5,-0.5,0.25, -0.125,0.5,0.3125},
{-0.5,-0.5,0.3125, -0.25,0.5,0.375},
{-0.5,-0.5,0.375, -0.375,0.5,0.4375},
{0.375,0,-0.4375, 0.5,0.5,-0.375},
{0.25,0,-0.375, 0.5,0.5,-0.3125},
{0.125,0,-0.3125, 0.5,0.5,-0.25},
{0,0,-0.25, 0.5,0.5,-0.1875},
{-0.125,0,-0.1875, 0.5,0.5,-0.125},
{-0.25,0,-0.125, 0.5,0.5,-0.0625},
{-0.375,0,-0.0625, 0.5,0.5,0}}},
		selection_box = {type="fixed",fixed={
{-0.5,-0.5,-0.5, 0.5,0,0},
{-0.5,-0.5,0, 0.375,0.5,0.0625},
{-0.5,-0.5,0.0625, 0.25,0.5,0.125},
{-0.5,-0.5,0.125, 0.125,0.5,0.1875},
{-0.5,-0.5,0.1875, 0,0.5,0.25},
{-0.5,-0.5,0.25, -0.125,0.5,0.3125},
{-0.5,-0.5,0.3125, -0.25,0.5,0.375},
{-0.5,-0.5,0.375, -0.375,0.5,0.4375},
{0.375,0,-0.4375, 0.5,0.5,-0.375},
{0.25,0,-0.375, 0.5,0.5,-0.3125},
{0.125,0,-0.3125, 0.5,0.5,-0.25},
{0,0,-0.25, 0.5,0.5,-0.1875},
{-0.125,0,-0.1875, 0.5,0.5,-0.125},
{-0.25,0,-0.125, 0.5,0.5,-0.0625},
{-0.375,0,-0.0625, 0.5,0.5,0}}},
	drawtype = "mesh",
	mesh = "diagsteps_58s.obj"
})

minetest.register_node("stones:diagsteps_52z", {
	description = "*2 Steps R5/2 Z",
	paramtype = "light",
	paramtype2 = "facedir",
	tiles = {"rock.png"},
	groups = {vcol=0.75, cracky=1, oddly_breakable_by_hand=1},
	drop = "stones:diagsteps_52z",
	collision_box = {type="fixed",fixed={
{-0.4375,-0.5,0.375, -0.375,0,0.5},
{-0.375,-0.5,0.25, -0.3125,0,0.5},
{-0.3125,-0.5,0.125, -0.25,0,0.5},
{-0.25,-0.5,0, -0.1875,0,0.5},
{-0.1875,-0.5,-0.125, -0.125,0,0.5},
{-0.125,-0.5,-0.25, -0.0625,0,0.5},
{-0.0625,-0.5,-0.375, 0,0,0.5},
{0,-0.5,-0.5, 0.5,0,0.5},
{0.375,0,-0.5, 0.4375,0.5,-0.375},
{0.3125,0,-0.5, 0.375,0.5,-0.25},
{0.25,0,-0.5, 0.3125,0.5,-0.125},
{0.1875,0,-0.5, 0.25,0.5,0},
{0.125,0,-0.5, 0.1875,0.5,0.125},
{0.0625,0,-0.5, 0.125,0.5,0.25},
{0,0,-0.5, 0.0625,0.5,0.375},
{-0.5,0,-0.5, 0,0.5,0.5}}},
		selection_box = {type="fixed",fixed={
{-0.4375,-0.5,0.375, -0.375,0,0.5},
{-0.375,-0.5,0.25, -0.3125,0,0.5},
{-0.3125,-0.5,0.125, -0.25,0,0.5},
{-0.25,-0.5,0, -0.1875,0,0.5},
{-0.1875,-0.5,-0.125, -0.125,0,0.5},
{-0.125,-0.5,-0.25, -0.0625,0,0.5},
{-0.0625,-0.5,-0.375, 0,0,0.5},
{0,-0.5,-0.5, 0.5,0,0.5},
{0.375,0,-0.5, 0.4375,0.5,-0.375},
{0.3125,0,-0.5, 0.375,0.5,-0.25},
{0.25,0,-0.5, 0.3125,0.5,-0.125},
{0.1875,0,-0.5, 0.25,0.5,0},
{0.125,0,-0.5, 0.1875,0.5,0.125},
{0.0625,0,-0.5, 0.125,0.5,0.25},
{0,0,-0.5, 0.0625,0.5,0.375},
{-0.5,0,-0.5, 0,0.5,0.5}}},
	drawtype = "mesh",
	mesh = "diagsteps_52z.obj"
})

minetest.register_node("stones:diagsterps_52z", {
	description = "*2 Steps R5/2 Z Rubble",
	paramtype = "light",
	paramtype2 = "facedir",
	tiles = {"rubble.png"},
	groups = {vcol=0.75, cracky=3, oddly_breakable_by_hand=1, not_in_creative_inventory=1},
	drop = "stones:diagsterps_52z",
	collision_box = {type="fixed",fixed={
{-0.4375,-0.5,0.375, -0.375,0,0.5},
{-0.375,-0.5,0.25, -0.3125,0,0.5},
{-0.3125,-0.5,0.125, -0.25,0,0.5},
{-0.25,-0.5,0, -0.1875,0,0.5},
{-0.1875,-0.5,-0.125, -0.125,0,0.5},
{-0.125,-0.5,-0.25, -0.0625,0,0.5},
{-0.0625,-0.5,-0.375, 0,0,0.5},
{0,-0.5,-0.5, 0.5,0,0.5},
{0.375,0,-0.5, 0.4375,0.5,-0.375},
{0.3125,0,-0.5, 0.375,0.5,-0.25},
{0.25,0,-0.5, 0.3125,0.5,-0.125},
{0.1875,0,-0.5, 0.25,0.5,0},
{0.125,0,-0.5, 0.1875,0.5,0.125},
{0.0625,0,-0.5, 0.125,0.5,0.25},
{0,0,-0.5, 0.0625,0.5,0.375},
{-0.5,0,-0.5, 0,0.5,0.5}}},
		selection_box = {type="fixed",fixed={
{-0.4375,-0.5,0.375, -0.375,0,0.5},
{-0.375,-0.5,0.25, -0.3125,0,0.5},
{-0.3125,-0.5,0.125, -0.25,0,0.5},
{-0.25,-0.5,0, -0.1875,0,0.5},
{-0.1875,-0.5,-0.125, -0.125,0,0.5},
{-0.125,-0.5,-0.25, -0.0625,0,0.5},
{-0.0625,-0.5,-0.375, 0,0,0.5},
{0,-0.5,-0.5, 0.5,0,0.5},
{0.375,0,-0.5, 0.4375,0.5,-0.375},
{0.3125,0,-0.5, 0.375,0.5,-0.25},
{0.25,0,-0.5, 0.3125,0.5,-0.125},
{0.1875,0,-0.5, 0.25,0.5,0},
{0.125,0,-0.5, 0.1875,0.5,0.125},
{0.0625,0,-0.5, 0.125,0.5,0.25},
{0,0,-0.5, 0.0625,0.5,0.375},
{-0.5,0,-0.5, 0,0.5,0.5}}},
	drawtype = "mesh",
	mesh = "diagsteps_52z.obj"
})

minetest.register_node("stones:diagsteps_58z", {
	description = "*2 Steps R5/2 5/8 Z",
	paramtype = "light",
	paramtype2 = "facedir",
	tiles = {"rock.png"},
	groups = {vcol=0.75, cracky=1, oddly_breakable_by_hand=1, not_in_creative_inventory=1},
	drop = "stones:diagsteps_58z",
	collision_box = {type="fixed",fixed={
{-0.4375,-0.5,0.375, -0.375,0.5,0.5},
{-0.375,-0.5,0.25, -0.3125,0.5,0.5},
{-0.3125,-0.5,0.125, -0.25,0.5,0.5},
{-0.25,-0.5,0, -0.1875,0.5,0.5},
{-0.1875,-0.5,-0.125, -0.125,0.5,0.5},
{-0.125,-0.5,-0.25, -0.0625,0.5,0.5},
{-0.0625,-0.5,-0.375, 0,0.5,0.5},
{0,-0.5,-0.5, 0.5,0,0.5},
{0.375,0,-0.5, 0.4375,0.5,-0.375},
{0.3125,0,-0.5, 0.375,0.5,-0.25},
{0.25,0,-0.5, 0.3125,0.5,-0.125},
{0.1875,0,-0.5, 0.25,0.5,0},
{0.125,0,-0.5, 0.1875,0.5,0.125},
{0.0625,0,-0.5, 0.125,0.5,0.25},
{0,0,-0.5, 0.0625,0.5,0.375}}},
		selection_box = {type="fixed",fixed={
{-0.4375,-0.5,0.375, -0.375,0.5,0.5},
{-0.375,-0.5,0.25, -0.3125,0.5,0.5},
{-0.3125,-0.5,0.125, -0.25,0.5,0.5},
{-0.25,-0.5,0, -0.1875,0.5,0.5},
{-0.1875,-0.5,-0.125, -0.125,0.5,0.5},
{-0.125,-0.5,-0.25, -0.0625,0.5,0.5},
{-0.0625,-0.5,-0.375, 0,0.5,0.5},
{0,-0.5,-0.5, 0.5,0,0.5},
{0.375,0,-0.5, 0.4375,0.5,-0.375},
{0.3125,0,-0.5, 0.375,0.5,-0.25},
{0.25,0,-0.5, 0.3125,0.5,-0.125},
{0.1875,0,-0.5, 0.25,0.5,0},
{0.125,0,-0.5, 0.1875,0.5,0.125},
{0.0625,0,-0.5, 0.125,0.5,0.25},
{0,0,-0.5, 0.0625,0.5,0.375}}},
	drawtype = "mesh",
	mesh = "diagsteps_58z.obj"
})

minetest.register_node("stones:diagsterps_58z", {
	description = "*2 Steps R5/2 5/8 Z Rubble",
	paramtype = "light",
	paramtype2 = "facedir",
	tiles = {"rubble.png"},
	groups = {vcol=0.75, cracky=3, oddly_breakable_by_hand=1, not_in_creative_inventory=1},
	drop = "stones:diagsterps_58z",
	collision_box = {type="fixed",fixed={
{-0.4375,-0.5,0.375, -0.375,0.5,0.5},
{-0.375,-0.5,0.25, -0.3125,0.5,0.5},
{-0.3125,-0.5,0.125, -0.25,0.5,0.5},
{-0.25,-0.5,0, -0.1875,0.5,0.5},
{-0.1875,-0.5,-0.125, -0.125,0.5,0.5},
{-0.125,-0.5,-0.25, -0.0625,0.5,0.5},
{-0.0625,-0.5,-0.375, 0,0.5,0.5},
{0,-0.5,-0.5, 0.5,0,0.5},
{0.375,0,-0.5, 0.4375,0.5,-0.375},
{0.3125,0,-0.5, 0.375,0.5,-0.25},
{0.25,0,-0.5, 0.3125,0.5,-0.125},
{0.1875,0,-0.5, 0.25,0.5,0},
{0.125,0,-0.5, 0.1875,0.5,0.125},
{0.0625,0,-0.5, 0.125,0.5,0.25},
{0,0,-0.5, 0.0625,0.5,0.375}}},
		selection_box = {type="fixed",fixed={
{-0.4375,-0.5,0.375, -0.375,0.5,0.5},
{-0.375,-0.5,0.25, -0.3125,0.5,0.5},
{-0.3125,-0.5,0.125, -0.25,0.5,0.5},
{-0.25,-0.5,0, -0.1875,0.5,0.5},
{-0.1875,-0.5,-0.125, -0.125,0.5,0.5},
{-0.125,-0.5,-0.25, -0.0625,0.5,0.5},
{-0.0625,-0.5,-0.375, 0,0.5,0.5},
{0,-0.5,-0.5, 0.5,0,0.5},
{0.375,0,-0.5, 0.4375,0.5,-0.375},
{0.3125,0,-0.5, 0.375,0.5,-0.25},
{0.25,0,-0.5, 0.3125,0.5,-0.125},
{0.1875,0,-0.5, 0.25,0.5,0},
{0.125,0,-0.5, 0.1875,0.5,0.125},
{0.0625,0,-0.5, 0.125,0.5,0.25},
{0,0,-0.5, 0.0625,0.5,0.375}}},
	drawtype = "mesh",
	mesh = "diagsteps_58z.obj"
})

minetest.register_node("stones:dias52r", {
	description = "R5/2 Diagstep Siding R",
	paramtype = "light",
	paramtype2 = "facedir",
	tiles = {"rock.png"},
	groups = {vcol=0.175, cracky=1, oddly_breakable_by_hand=1},
	drop = "stones:dias52r",
	collision_box = {type="fixed",fixed={
{-0.5,-0.5,-0.375, -0.4375,0,0.4688},
{-0.5,0,0, -0.4375,0.375,0.125},
{-0.5,0,0.125, -0.4375,0.5,0.4688},
{-0.4375,-0.5,-0.25, -0.375,0,0.4375},
{-0.4375,0,0, -0.375,0.25,0.125},
{-0.4375,0,0.125, -0.375,0.375,0.25},
{-0.4375,0,0.25, -0.375,0.5,0.4375},
{-0.375,-0.5,-0.125, -0.3125,0,0.4063},
{-0.375,0,0, -0.3125,0.125,0.125},
{-0.375,0,0.125, -0.3125,0.25,0.25},
{-0.375,0,0.25, -0.3125,0.375,0.375},
{-0.375,0,0.375, -0.3125,0.5,0.4062},
{-0.3125,-0.5,0, -0.25,0,0.375},
{-0.3125,0,0.125, -0.25,0.125,0.25},
{-0.3125,0,0.25, -0.25,0.25,0.375},
{-0.25,-0.5,-0.0625, -0.1875,-0.1875,0.3125},
{-0.25,-0.1875,0.0625, -0.1875,-0.0625,0.1875},
{-0.25,-0.1875,0.1875, -0.1875,0.0625,0.3125},
{-0.25,-0.5,0.3125, -0.1875,0.1875,0.3438},
{-0.1875,-0.5,-0.125, -0.125,-0.375,0.25},
{-0.1875,-0.375,0, -0.125,-0.25,0.125},
{-0.1875,-0.375,0.125, -0.125,-0.125,0.25},
{-0.1875,-0.5,0.25, -0.125,0,0.3125},
{-0.125,-0.5,-0.0625, -0.0625,-0.4375,0.25},
{-0.125,-0.4375,0.0625, -0.0625,-0.3125,0.1875},
{-0.125,-0.4375,0.1875, -0.0625,-0.1875,0.2812},
{-0.0625,-0.5,0.125, 0,-0.375,0.25}}},
		selection_box = {type="fixed",fixed={
{-0.5,-0.5,-0.375, -0.4375,0,0.4688},
{-0.5,0,0, -0.4375,0.375,0.125},
{-0.5,0,0.125, -0.4375,0.5,0.4688},
{-0.4375,-0.5,-0.25, -0.375,0,0.4375},
{-0.4375,0,0, -0.375,0.25,0.125},
{-0.4375,0,0.125, -0.375,0.375,0.25},
{-0.4375,0,0.25, -0.375,0.5,0.4375},
{-0.375,-0.5,-0.125, -0.3125,0,0.4063},
{-0.375,0,0, -0.3125,0.125,0.125},
{-0.375,0,0.125, -0.3125,0.25,0.25},
{-0.375,0,0.25, -0.3125,0.375,0.375},
{-0.375,0,0.375, -0.3125,0.5,0.4062},
{-0.3125,-0.5,0, -0.25,0,0.375},
{-0.3125,0,0.125, -0.25,0.125,0.25},
{-0.3125,0,0.25, -0.25,0.25,0.375},
{-0.25,-0.5,-0.0625, -0.1875,-0.1875,0.3125},
{-0.25,-0.1875,0.0625, -0.1875,-0.0625,0.1875},
{-0.25,-0.1875,0.1875, -0.1875,0.0625,0.3125},
{-0.25,-0.5,0.3125, -0.1875,0.1875,0.3438},
{-0.1875,-0.5,-0.125, -0.125,-0.375,0.25},
{-0.1875,-0.375,0, -0.125,-0.25,0.125},
{-0.1875,-0.375,0.125, -0.125,-0.125,0.25},
{-0.1875,-0.5,0.25, -0.125,0,0.3125},
{-0.125,-0.5,-0.0625, -0.0625,-0.4375,0.25},
{-0.125,-0.4375,0.0625, -0.0625,-0.3125,0.1875},
{-0.125,-0.4375,0.1875, -0.0625,-0.1875,0.2812},
{-0.0625,-0.5,0.125, 0,-0.375,0.25}}},
	drawtype = "mesh",
	mesh = "dias52r.obj"
})

minetest.register_node("stones:diras52r", {
	description = "R5/2 Diagstep Siding R Rubble",
	paramtype = "light",
	paramtype2 = "facedir",
	tiles = {"rubble.png"},
	groups = {vcol=0.175, cracky=3, oddly_breakable_by_hand=1, not_in_creative_inventory=1},
	drop = "stones:diras52r",
	collision_box = {type="fixed",fixed={
{-0.5,-0.5,-0.375, -0.4375,0,0.4688},
{-0.5,0,0, -0.4375,0.375,0.125},
{-0.5,0,0.125, -0.4375,0.5,0.4688},
{-0.4375,-0.5,-0.25, -0.375,0,0.4375},
{-0.4375,0,0, -0.375,0.25,0.125},
{-0.4375,0,0.125, -0.375,0.375,0.25},
{-0.4375,0,0.25, -0.375,0.5,0.4375},
{-0.375,-0.5,-0.125, -0.3125,0,0.4063},
{-0.375,0,0, -0.3125,0.125,0.125},
{-0.375,0,0.125, -0.3125,0.25,0.25},
{-0.375,0,0.25, -0.3125,0.375,0.375},
{-0.375,0,0.375, -0.3125,0.5,0.4062},
{-0.3125,-0.5,0, -0.25,0,0.375},
{-0.3125,0,0.125, -0.25,0.125,0.25},
{-0.3125,0,0.25, -0.25,0.25,0.375},
{-0.25,-0.5,-0.0625, -0.1875,-0.1875,0.3125},
{-0.25,-0.1875,0.0625, -0.1875,-0.0625,0.1875},
{-0.25,-0.1875,0.1875, -0.1875,0.0625,0.3125},
{-0.25,-0.5,0.3125, -0.1875,0.1875,0.3438},
{-0.1875,-0.5,-0.125, -0.125,-0.375,0.25},
{-0.1875,-0.375,0, -0.125,-0.25,0.125},
{-0.1875,-0.375,0.125, -0.125,-0.125,0.25},
{-0.1875,-0.5,0.25, -0.125,0,0.3125},
{-0.125,-0.5,-0.0625, -0.0625,-0.4375,0.25},
{-0.125,-0.4375,0.0625, -0.0625,-0.3125,0.1875},
{-0.125,-0.4375,0.1875, -0.0625,-0.1875,0.2812},
{-0.0625,-0.5,0.125, 0,-0.375,0.25}}},
		selection_box = {type="fixed",fixed={
{-0.5,-0.5,-0.375, -0.4375,0,0.4688},
{-0.5,0,0, -0.4375,0.375,0.125},
{-0.5,0,0.125, -0.4375,0.5,0.4688},
{-0.4375,-0.5,-0.25, -0.375,0,0.4375},
{-0.4375,0,0, -0.375,0.25,0.125},
{-0.4375,0,0.125, -0.375,0.375,0.25},
{-0.4375,0,0.25, -0.375,0.5,0.4375},
{-0.375,-0.5,-0.125, -0.3125,0,0.4063},
{-0.375,0,0, -0.3125,0.125,0.125},
{-0.375,0,0.125, -0.3125,0.25,0.25},
{-0.375,0,0.25, -0.3125,0.375,0.375},
{-0.375,0,0.375, -0.3125,0.5,0.4062},
{-0.3125,-0.5,0, -0.25,0,0.375},
{-0.3125,0,0.125, -0.25,0.125,0.25},
{-0.3125,0,0.25, -0.25,0.25,0.375},
{-0.25,-0.5,-0.0625, -0.1875,-0.1875,0.3125},
{-0.25,-0.1875,0.0625, -0.1875,-0.0625,0.1875},
{-0.25,-0.1875,0.1875, -0.1875,0.0625,0.3125},
{-0.25,-0.5,0.3125, -0.1875,0.1875,0.3438},
{-0.1875,-0.5,-0.125, -0.125,-0.375,0.25},
{-0.1875,-0.375,0, -0.125,-0.25,0.125},
{-0.1875,-0.375,0.125, -0.125,-0.125,0.25},
{-0.1875,-0.5,0.25, -0.125,0,0.3125},
{-0.125,-0.5,-0.0625, -0.0625,-0.4375,0.25},
{-0.125,-0.4375,0.0625, -0.0625,-0.3125,0.1875},
{-0.125,-0.4375,0.1875, -0.0625,-0.1875,0.2812},
{-0.0625,-0.5,0.125, 0,-0.375,0.25}}},
	drawtype = "mesh",
	mesh = "dias52r.obj"
})

minetest.register_node("stones:dias52l", {
	description = "R5/2 Diagstep Siding L",
	paramtype = "light",
	paramtype2 = "facedir",
	tiles = {"rock.png"},
	groups = {vcol=0.175, cracky=1, oddly_breakable_by_hand=1},
	drop = "stones:dias52l",
	collision_box = {type="fixed",fixed={
{-0.4688,-0.5,0.4375, 0.375,0,0.5},
{-0.125,0,0.4375, 0,0.375,0.5},
{-0.4688,0,0.4375, -0.125,0.5,0.5},
{-0.4375,-0.5,0.375, 0.25,0,0.4375},
{-0.125,0,0.375, 0,0.25,0.4375},
{-0.25,0,0.375, -0.125,0.375,0.4375},
{-0.4375,0,0.375, -0.25,0.5,0.4375},
{-0.4063,-0.5,0.3125, 0.125,0,0.375},
{-0.125,0,0.3125, 0,0.125,0.375},
{-0.25,0,0.3125, -0.125,0.25,0.375},
{-0.375,0,0.3125, -0.25,0.375,0.375},
{-0.4062,0,0.3125, -0.375,0.5,0.375},
{-0.375,-0.5,0.25, 0,0,0.3125},
{-0.25,0,0.25, -0.125,0.125,0.3125},
{-0.375,0,0.25, -0.25,0.25,0.3125},
{-0.3125,-0.5,0.1875, 0.0625,-0.1875,0.25},
{-0.1875,-0.1875,0.1875, -0.0625,-0.0625,0.25},
{-0.3125,-0.1875,0.1875, -0.1875,0.0625,0.25},
{-0.3438,-0.5,0.1875, -0.3125,0.1875,0.25},
{-0.25,-0.5,0.125, 0.125,-0.375,0.1875},
{-0.125,-0.375,0.125, 0,-0.25,0.1875},
{-0.25,-0.375,0.125, -0.125,-0.125,0.1875},
{-0.3125,-0.5,0.125, -0.25,0,0.1875},
{-0.25,-0.5,0.0625, 0.0625,-0.4375,0.125},
{-0.1875,-0.4375,0.0625, -0.0625,-0.3125,0.125},
{-0.2812,-0.4375,0.0625, -0.1875,-0.1875,0.125},
{-0.25,-0.5,0, -0.125,-0.375,0.0625}}},
		selection_box = {type="fixed",fixed={
{-0.4688,-0.5,0.4375, 0.375,0,0.5},
{-0.125,0,0.4375, 0,0.375,0.5},
{-0.4688,0,0.4375, -0.125,0.5,0.5},
{-0.4375,-0.5,0.375, 0.25,0,0.4375},
{-0.125,0,0.375, 0,0.25,0.4375},
{-0.25,0,0.375, -0.125,0.375,0.4375},
{-0.4375,0,0.375, -0.25,0.5,0.4375},
{-0.4063,-0.5,0.3125, 0.125,0,0.375},
{-0.125,0,0.3125, 0,0.125,0.375},
{-0.25,0,0.3125, -0.125,0.25,0.375},
{-0.375,0,0.3125, -0.25,0.375,0.375},
{-0.4062,0,0.3125, -0.375,0.5,0.375},
{-0.375,-0.5,0.25, 0,0,0.3125},
{-0.25,0,0.25, -0.125,0.125,0.3125},
{-0.375,0,0.25, -0.25,0.25,0.3125},
{-0.3125,-0.5,0.1875, 0.0625,-0.1875,0.25},
{-0.1875,-0.1875,0.1875, -0.0625,-0.0625,0.25},
{-0.3125,-0.1875,0.1875, -0.1875,0.0625,0.25},
{-0.3438,-0.5,0.1875, -0.3125,0.1875,0.25},
{-0.25,-0.5,0.125, 0.125,-0.375,0.1875},
{-0.125,-0.375,0.125, 0,-0.25,0.1875},
{-0.25,-0.375,0.125, -0.125,-0.125,0.1875},
{-0.3125,-0.5,0.125, -0.25,0,0.1875},
{-0.25,-0.5,0.0625, 0.0625,-0.4375,0.125},
{-0.1875,-0.4375,0.0625, -0.0625,-0.3125,0.125},
{-0.2812,-0.4375,0.0625, -0.1875,-0.1875,0.125},
{-0.25,-0.5,0, -0.125,-0.375,0.0625}}},
	drawtype = "mesh",
	mesh = "dias52l.obj"
})

minetest.register_node("stones:diras52l", {
	description = "R5/2 Diagstep Siding L Rubble",
	paramtype = "light",
	paramtype2 = "facedir",
	tiles = {"rubble.png"},
	groups = {vcol=0.175, cracky=3, oddly_breakable_by_hand=1, not_in_creative_inventory=1},
	drop = "stones:diras52l",
	collision_box = {type="fixed",fixed={
{-0.4688,-0.5,0.4375, 0.375,0,0.5},
{-0.125,0,0.4375, 0,0.375,0.5},
{-0.4688,0,0.4375, -0.125,0.5,0.5},
{-0.4375,-0.5,0.375, 0.25,0,0.4375},
{-0.125,0,0.375, 0,0.25,0.4375},
{-0.25,0,0.375, -0.125,0.375,0.4375},
{-0.4375,0,0.375, -0.25,0.5,0.4375},
{-0.4063,-0.5,0.3125, 0.125,0,0.375},
{-0.125,0,0.3125, 0,0.125,0.375},
{-0.25,0,0.3125, -0.125,0.25,0.375},
{-0.375,0,0.3125, -0.25,0.375,0.375},
{-0.4062,0,0.3125, -0.375,0.5,0.375},
{-0.375,-0.5,0.25, 0,0,0.3125},
{-0.25,0,0.25, -0.125,0.125,0.3125},
{-0.375,0,0.25, -0.25,0.25,0.3125},
{-0.3125,-0.5,0.1875, 0.0625,-0.1875,0.25},
{-0.1875,-0.1875,0.1875, -0.0625,-0.0625,0.25},
{-0.3125,-0.1875,0.1875, -0.1875,0.0625,0.25},
{-0.3438,-0.5,0.1875, -0.3125,0.1875,0.25},
{-0.25,-0.5,0.125, 0.125,-0.375,0.1875},
{-0.125,-0.375,0.125, 0,-0.25,0.1875},
{-0.25,-0.375,0.125, -0.125,-0.125,0.1875},
{-0.3125,-0.5,0.125, -0.25,0,0.1875},
{-0.25,-0.5,0.0625, 0.0625,-0.4375,0.125},
{-0.1875,-0.4375,0.0625, -0.0625,-0.3125,0.125},
{-0.2812,-0.4375,0.0625, -0.1875,-0.1875,0.125},
{-0.25,-0.5,0, -0.125,-0.375,0.0625}}},
		selection_box = {type="fixed",fixed={
{-0.4688,-0.5,0.4375, 0.375,0,0.5},
{-0.125,0,0.4375, 0,0.375,0.5},
{-0.4688,0,0.4375, -0.125,0.5,0.5},
{-0.4375,-0.5,0.375, 0.25,0,0.4375},
{-0.125,0,0.375, 0,0.25,0.4375},
{-0.25,0,0.375, -0.125,0.375,0.4375},
{-0.4375,0,0.375, -0.25,0.5,0.4375},
{-0.4063,-0.5,0.3125, 0.125,0,0.375},
{-0.125,0,0.3125, 0,0.125,0.375},
{-0.25,0,0.3125, -0.125,0.25,0.375},
{-0.375,0,0.3125, -0.25,0.375,0.375},
{-0.4062,0,0.3125, -0.375,0.5,0.375},
{-0.375,-0.5,0.25, 0,0,0.3125},
{-0.25,0,0.25, -0.125,0.125,0.3125},
{-0.375,0,0.25, -0.25,0.25,0.3125},
{-0.3125,-0.5,0.1875, 0.0625,-0.1875,0.25},
{-0.1875,-0.1875,0.1875, -0.0625,-0.0625,0.25},
{-0.3125,-0.1875,0.1875, -0.1875,0.0625,0.25},
{-0.3438,-0.5,0.1875, -0.3125,0.1875,0.25},
{-0.25,-0.5,0.125, 0.125,-0.375,0.1875},
{-0.125,-0.375,0.125, 0,-0.25,0.1875},
{-0.25,-0.375,0.125, -0.125,-0.125,0.1875},
{-0.3125,-0.5,0.125, -0.25,0,0.1875},
{-0.25,-0.5,0.0625, 0.0625,-0.4375,0.125},
{-0.1875,-0.4375,0.0625, -0.0625,-0.3125,0.125},
{-0.2812,-0.4375,0.0625, -0.1875,-0.1875,0.125},
{-0.25,-0.5,0, -0.125,-0.375,0.0625}}},
	drawtype = "mesh",
	mesh = "dias52l.obj"
})

minetest.register_node("stones:dias52d", {
	description = "R5/2 Diagstep Siding D",
	paramtype = "light",
	paramtype2 = "facedir",
	tiles = {"rock.png"},
	groups = {vcol=0.25, cracky=1, oddly_breakable_by_hand=1},
	drop = "stones:dias52d",
	collision_box = {type="fixed",fixed={
{-0.4375,-0.5,0.375, 0,0,0.5},
{-0.375,-0.5,0.25, 0.0625,0,0.375},
{-0.3125,-0.5,0.125, 0.125,0,0.25},
{-0.25,-0.5,0, 0.1875,0,0.125},
{-0.1875,-0.5,-0.125, 0.25,0,0},
{-0.125,-0.5,-0.25, 0,0,-0.125},
{0,-0.5,-0.25, 0.125,-0.125,-0.125},
{0.125,-0.5,-0.25, 0.25,-0.25,-0.125},
{0.25,-0.5,-0.25, 0.3125,-0.3125,-0.125},
{-0.0625,-0.5,-0.375, 0.0625,-0.3125,-0.25},
{0.0625,-0.5,-0.375, 0.1875,-0.4375,-0.25},
{-0.4375,0,0.375, -0.25,0.5,0.5},
{-0.25,0,0.375, -0.125,0.375,0.5},
{-0.125,0,0.375, 0,0.25,0.5},
{-0.375,0,0.25, -0.3125,0.3125,0.375},
{-0.3125,0,0.25, -0.1875,0.1875,0.25}}},
		selection_box = {type="fixed",fixed={
{-0.4375,-0.5,0.375, 0,0,0.5},
{-0.375,-0.5,0.25, 0.0625,0,0.375},
{-0.3125,-0.5,0.125, 0.125,0,0.25},
{-0.25,-0.5,0, 0.1875,0,0.125},
{-0.1875,-0.5,-0.125, 0.25,0,0},
{-0.125,-0.5,-0.25, 0,0,-0.125},
{0,-0.5,-0.25, 0.125,-0.125,-0.125},
{0.125,-0.5,-0.25, 0.25,-0.25,-0.125},
{0.25,-0.5,-0.25, 0.3125,-0.3125,-0.125},
{-0.0625,-0.5,-0.375, 0.0625,-0.3125,-0.25},
{0.0625,-0.5,-0.375, 0.1875,-0.4375,-0.25},
{-0.4375,0,0.375, -0.25,0.5,0.5},
{-0.25,0,0.375, -0.125,0.375,0.5},
{-0.125,0,0.375, 0,0.25,0.5},
{-0.375,0,0.25, -0.3125,0.3125,0.375},
{-0.3125,0,0.25, -0.1875,0.1875,0.25}}},
	drawtype = "mesh",
	mesh = "dias52d.obj"
})

minetest.register_node("stones:diras52d", {
	description = "R5/2 Diagstep Siding D Rubble",
	paramtype = "light",
	paramtype2 = "facedir",
	tiles = {"rubble.png"},
	groups = {vcol=0.25, cracky=3, oddly_breakable_by_hand=1, not_in_creative_inventory=1},
	drop = "stones:diras52d",
	collision_box = {type="fixed",fixed={
{-0.4375,-0.5,0.375, 0,0,0.5},
{-0.375,-0.5,0.25, 0.0625,0,0.375},
{-0.3125,-0.5,0.125, 0.125,0,0.25},
{-0.25,-0.5,0, 0.1875,0,0.125},
{-0.1875,-0.5,-0.125, 0.25,0,0},
{-0.125,-0.5,-0.25, 0,0,-0.125},
{0,-0.5,-0.25, 0.125,-0.125,-0.125},
{0.125,-0.5,-0.25, 0.25,-0.25,-0.125},
{0.25,-0.5,-0.25, 0.3125,-0.3125,-0.125},
{-0.0625,-0.5,-0.375, 0.0625,-0.3125,-0.25},
{0.0625,-0.5,-0.375, 0.1875,-0.4375,-0.25},
{-0.4375,0,0.375, -0.25,0.5,0.5},
{-0.25,0,0.375, -0.125,0.375,0.5},
{-0.125,0,0.375, 0,0.25,0.5},
{-0.375,0,0.25, -0.3125,0.3125,0.375},
{-0.3125,0,0.25, -0.1875,0.1875,0.25}}},
		selection_box = {type="fixed",fixed={
{-0.4375,-0.5,0.375, 0,0,0.5},
{-0.375,-0.5,0.25, 0.0625,0,0.375},
{-0.3125,-0.5,0.125, 0.125,0,0.25},
{-0.25,-0.5,0, 0.1875,0,0.125},
{-0.1875,-0.5,-0.125, 0.25,0,0},
{-0.125,-0.5,-0.25, 0,0,-0.125},
{0,-0.5,-0.25, 0.125,-0.125,-0.125},
{0.125,-0.5,-0.25, 0.25,-0.25,-0.125},
{0.25,-0.5,-0.25, 0.3125,-0.3125,-0.125},
{-0.0625,-0.5,-0.375, 0.0625,-0.3125,-0.25},
{0.0625,-0.5,-0.375, 0.1875,-0.4375,-0.25},
{-0.4375,0,0.375, -0.25,0.5,0.5},
{-0.25,0,0.375, -0.125,0.375,0.5},
{-0.125,0,0.375, 0,0.25,0.5},
{-0.375,0,0.25, -0.3125,0.3125,0.375},
{-0.3125,0,0.25, -0.1875,0.1875,0.25}}},
	drawtype = "mesh",
	mesh = "dias52d.obj"
})

minetest.register_node("stones:dias52b", {
	description = "R5/2 Diagstep Siding B",
	paramtype = "light",
	paramtype2 = "facedir",
	tiles = {"rock.png"},
	groups = {vcol=0.25, cracky=1, oddly_breakable_by_hand=1},
	drop = "stones:dias52b",
	collision_box = {type="fixed",fixed={
{-0.5,-0.5,0, -0.375,0,0.4375},
{-0.375,-0.5,-0.0625, -0.25,0,0.375},
{-0.25,-0.5,-0.125, -0.125,0,0.3125},
{-0.125,-0.5,-0.1875, 0,0,0.25},
{0,-0.5,-0.25, 0.125,0,0.1875},
{0.125,-0.5,0, 0.25,0,0.125},
{0.125,-0.5,-0.125, 0.25,-0.125,0},
{0.125,-0.5,-0.25, 0.25,-0.25,-0.125},
{0.125,-0.5,-0.3125, 0.25,-0.3125,-0.25},
{0.25,-0.5,-0.0625, 0.375,-0.3125,0.0625},
{0.25,-0.5,-0.1875, 0.375,-0.4375,-0.0625},
{-0.5,0,0.25, -0.375,0.5,0.4375},
{-0.5,0,0.125, -0.375,0.375,0.25},
{-0.5,0,0, -0.375,0.25,0.125},
{-0.375,0,0.3125, -0.25,0.3125,0.375},
{-0.375,0,0.1875, -0.25,0.1875,0.3125}}},
		selection_box = {type="fixed",fixed={
{-0.5,-0.5,0, -0.375,0,0.4375},
{-0.375,-0.5,-0.0625, -0.25,0,0.375},
{-0.25,-0.5,-0.125, -0.125,0,0.3125},
{-0.125,-0.5,-0.1875, 0,0,0.25},
{0,-0.5,-0.25, 0.125,0,0.1875},
{0.125,-0.5,0, 0.25,0,0.125},
{0.125,-0.5,-0.125, 0.25,-0.125,0},
{0.125,-0.5,-0.25, 0.25,-0.25,-0.125},
{0.125,-0.5,-0.3125, 0.25,-0.3125,-0.25},
{0.25,-0.5,-0.0625, 0.375,-0.3125,0.0625},
{0.25,-0.5,-0.1875, 0.375,-0.4375,-0.0625},
{-0.5,0,0.25, -0.375,0.5,0.4375},
{-0.5,0,0.125, -0.375,0.375,0.25},
{-0.5,0,0, -0.375,0.25,0.125},
{-0.375,0,0.3125, -0.25,0.3125,0.375},
{-0.375,0,0.1875, -0.25,0.1875,0.3125}}},
	drawtype = "mesh",
	mesh = "dias52b.obj"
})

minetest.register_node("stones:diras52b", {
	description = "R5/2 Diagstep Siding B Rubble",
	paramtype = "light",
	paramtype2 = "facedir",
	tiles = {"rubble.png"},
	groups = {vcol=0.25, cracky=3, oddly_breakable_by_hand=1, not_in_creative_inventory=1},
	drop = "stones:diras52b",
	collision_box = {type="fixed",fixed={
{-0.5,-0.5,0, -0.375,0,0.4375},
{-0.375,-0.5,-0.0625, -0.25,0,0.375},
{-0.25,-0.5,-0.125, -0.125,0,0.3125},
{-0.125,-0.5,-0.1875, 0,0,0.25},
{0,-0.5,-0.25, 0.125,0,0.1875},
{0.125,-0.5,0, 0.25,0,0.125},
{0.125,-0.5,-0.125, 0.25,-0.125,0},
{0.125,-0.5,-0.25, 0.25,-0.25,-0.125},
{0.125,-0.5,-0.3125, 0.25,-0.3125,-0.25},
{0.25,-0.5,-0.0625, 0.375,-0.3125,0.0625},
{0.25,-0.5,-0.1875, 0.375,-0.4375,-0.0625},
{-0.5,0,0.25, -0.375,0.5,0.4375},
{-0.5,0,0.125, -0.375,0.375,0.25},
{-0.5,0,0, -0.375,0.25,0.125},
{-0.375,0,0.3125, -0.25,0.3125,0.375},
{-0.375,0,0.1875, -0.25,0.1875,0.3125}}},
		selection_box = {type="fixed",fixed={
{-0.5,-0.5,0, -0.375,0,0.4375},
{-0.375,-0.5,-0.0625, -0.25,0,0.375},
{-0.25,-0.5,-0.125, -0.125,0,0.3125},
{-0.125,-0.5,-0.1875, 0,0,0.25},
{0,-0.5,-0.25, 0.125,0,0.1875},
{0.125,-0.5,0, 0.25,0,0.125},
{0.125,-0.5,-0.125, 0.25,-0.125,0},
{0.125,-0.5,-0.25, 0.25,-0.25,-0.125},
{0.125,-0.5,-0.3125, 0.25,-0.3125,-0.25},
{0.25,-0.5,-0.0625, 0.375,-0.3125,0.0625},
{0.25,-0.5,-0.1875, 0.375,-0.4375,-0.0625},
{-0.5,0,0.25, -0.375,0.5,0.4375},
{-0.5,0,0.125, -0.375,0.375,0.25},
{-0.5,0,0, -0.375,0.25,0.125},
{-0.375,0,0.3125, -0.25,0.3125,0.375},
{-0.375,0,0.1875, -0.25,0.1875,0.3125}}},
	drawtype = "mesh",
	mesh = "dias52b.obj"
})

minetest.register_node("stones:vsedr", {
	description = "Part Lowhalf Vsect R",
	paramtype = "light",
	paramtype2 = "facedir",
	tiles = {"rock.png"},
	groups = {vcol=0.083, cracky=1, oddly_breakable_by_hand=1},
	drop = "stones:vsedr",
	collision_box = {type="fixed",fixed={
{-0.5,-0.5,0.4375, 0.4375,-0.0313,0.5},
{-0.5,-0.5,0.375, 0.375,-0.0625,0.4375},
{-0.5,-0.5,0.3125, 0.3125,-0.0937,0.375},
{-0.5,-0.5,0.25, 0.25,-0.125,0.3125},
{-0.5,-0.5,0.1875, 0.1875,-0.1563,0.25},
{-0.5,-0.5,0.125, 0.125,-0.1875,0.1875},
{-0.5,-0.5,0.0625, 0.0625,-0.2188,0.125},
{-0.5,-0.5,0, 0,-0.25,0.0625},
{-0.5,-0.5,-0.0625, -0.0625,-0.2813,0},
{-0.5,-0.5,-0.125, -0.125,-0.3125,-0.0625},
{-0.5,-0.5,-0.1875, -0.1875,-0.3438,-0.125},
{-0.5,-0.5,-0.25, -0.25,-0.375,-0.1875},
{-0.5,-0.5,-0.3125, -0.3125,-0.4063,-0.25},
{-0.5,-0.5,-0.375, -0.375,-0.4375,-0.3125},
{-0.5,-0.5,-0.4375, -0.4375,-0.4688,-0.375}}},
		selection_box = {type="fixed",fixed={
{-0.5,-0.5,0.4375, 0.4375,-0.0313,0.5},
{-0.5,-0.5,0.375, 0.375,-0.0625,0.4375},
{-0.5,-0.5,0.3125, 0.3125,-0.0937,0.375},
{-0.5,-0.5,0.25, 0.25,-0.125,0.3125},
{-0.5,-0.5,0.1875, 0.1875,-0.1563,0.25},
{-0.5,-0.5,0.125, 0.125,-0.1875,0.1875},
{-0.5,-0.5,0.0625, 0.0625,-0.2188,0.125},
{-0.5,-0.5,0, 0,-0.25,0.0625},
{-0.5,-0.5,-0.0625, -0.0625,-0.2813,0},
{-0.5,-0.5,-0.125, -0.125,-0.3125,-0.0625},
{-0.5,-0.5,-0.1875, -0.1875,-0.3438,-0.125},
{-0.5,-0.5,-0.25, -0.25,-0.375,-0.1875},
{-0.5,-0.5,-0.3125, -0.3125,-0.4063,-0.25},
{-0.5,-0.5,-0.375, -0.375,-0.4375,-0.3125},
{-0.5,-0.5,-0.4375, -0.4375,-0.4688,-0.375}}},
	drawtype = "mesh",
	mesh = "vsedr.obj"
})

minetest.register_node("stones:vsrud", {
	description = "Part Lowhalf Vsect R Rubble",
	paramtype = "light",
	paramtype2 = "facedir",
	tiles = {"rubble.png"},
	groups = {vcol=0.83, cracky=3, oddly_breakable_by_hand=1, not_in_creative_inventory=1},
	drop = "stones:vsrud",
	collision_box = {type="fixed",fixed={
{-0.5,-0.5,0.4375, 0.4375,-0.0313,0.5},
{-0.5,-0.5,0.375, 0.375,-0.0625,0.4375},
{-0.5,-0.5,0.3125, 0.3125,-0.0937,0.375},
{-0.5,-0.5,0.25, 0.25,-0.125,0.3125},
{-0.5,-0.5,0.1875, 0.1875,-0.1563,0.25},
{-0.5,-0.5,0.125, 0.125,-0.1875,0.1875},
{-0.5,-0.5,0.0625, 0.0625,-0.2188,0.125},
{-0.5,-0.5,0, 0,-0.25,0.0625},
{-0.5,-0.5,-0.0625, -0.0625,-0.2813,0},
{-0.5,-0.5,-0.125, -0.125,-0.3125,-0.0625},
{-0.5,-0.5,-0.1875, -0.1875,-0.3438,-0.125},
{-0.5,-0.5,-0.25, -0.25,-0.375,-0.1875},
{-0.5,-0.5,-0.3125, -0.3125,-0.4063,-0.25},
{-0.5,-0.5,-0.375, -0.375,-0.4375,-0.3125},
{-0.5,-0.5,-0.4375, -0.4375,-0.4688,-0.375}}},
		selection_box = {type="fixed",fixed={
{-0.5,-0.5,0.4375, 0.4375,-0.0313,0.5},
{-0.5,-0.5,0.375, 0.375,-0.0625,0.4375},
{-0.5,-0.5,0.3125, 0.3125,-0.0937,0.375},
{-0.5,-0.5,0.25, 0.25,-0.125,0.3125},
{-0.5,-0.5,0.1875, 0.1875,-0.1563,0.25},
{-0.5,-0.5,0.125, 0.125,-0.1875,0.1875},
{-0.5,-0.5,0.0625, 0.0625,-0.2188,0.125},
{-0.5,-0.5,0, 0,-0.25,0.0625},
{-0.5,-0.5,-0.0625, -0.0625,-0.2813,0},
{-0.5,-0.5,-0.125, -0.125,-0.3125,-0.0625},
{-0.5,-0.5,-0.1875, -0.1875,-0.3438,-0.125},
{-0.5,-0.5,-0.25, -0.25,-0.375,-0.1875},
{-0.5,-0.5,-0.3125, -0.3125,-0.4063,-0.25},
{-0.5,-0.5,-0.375, -0.375,-0.4375,-0.3125},
{-0.5,-0.5,-0.4375, -0.4375,-0.4688,-0.375}}},
	drawtype = "mesh",
	mesh = "vsedr.obj"
})

minetest.register_node("stones:vsedl", {
	description = "Part Lowhalf Vsect L",
	paramtype = "light",
	paramtype2 = "facedir",
	tiles = {"rock.png"},
	groups = {vcol=0.83, cracky=1, oddly_breakable_by_hand=1},
	drop = "stones:vsedl",
	collision_box = {type="fixed",fixed={
{-0.4375,-0.5,0.4375, 0.5,-0.0313,0.5},
{-0.375,-0.5,0.375, 0.5,-0.0625,0.4375},
{-0.3125,-0.5,0.3125, 0.5,-0.0937,0.375},
{-0.25,-0.5,0.25, 0.5,-0.125,0.3125},
{-0.1875,-0.5,0.1875, 0.5,-0.1563,0.25},
{-0.125,-0.5,0.125, 0.5,-0.1875,0.1875},
{-0.0625,-0.5,0.0625, 0.5,-0.2188,0.125},
{0,-0.5,0, 0.5,-0.25,0.0625},
{0.0625,-0.5,-0.0625, 0.5,-0.2818,0},
{0.125,-0.5,-0.125, 0.5,-0.3125,-0.0625},
{0.1875,-0.5,-0.1875, 0.5,-0.3438,-0.125},
{0.25,-0.5,-0.25, 0.5,-0.375,-0.1875},
{0.3125,-0.5,-0.3125, 0.5,-0.4088,-0.25},
{0.375,-0.5,-0.375, 0.5,-0.4375,-0.3125},
{0.4375,-0.5,-0.4375, 0.5,-0.4688,-0.375}}},
		selection_box = {type="fixed",fixed={
{-0.4375,-0.5,0.4375, 0.5,-0.0313,0.5},
{-0.375,-0.5,0.375, 0.5,-0.0625,0.4375},
{-0.3125,-0.5,0.3125, 0.5,-0.0937,0.375},
{-0.25,-0.5,0.25, 0.5,-0.125,0.3125},
{-0.1875,-0.5,0.1875, 0.5,-0.1563,0.25},
{-0.125,-0.5,0.125, 0.5,-0.1875,0.1875},
{-0.0625,-0.5,0.0625, 0.5,-0.2188,0.125},
{0,-0.5,0, 0.5,-0.25,0.0625},
{0.0625,-0.5,-0.0625, 0.5,-0.2818,0},
{0.125,-0.5,-0.125, 0.5,-0.3125,-0.0625},
{0.1875,-0.5,-0.1875, 0.5,-0.3438,-0.125},
{0.25,-0.5,-0.25, 0.5,-0.375,-0.1875},
{0.3125,-0.5,-0.3125, 0.5,-0.4088,-0.25},
{0.375,-0.5,-0.375, 0.5,-0.4375,-0.3125},
{0.4375,-0.5,-0.4375, 0.5,-0.4688,-0.375}}},
	drawtype = "mesh",
	mesh = "vsedl.obj"
})

minetest.register_node("stones:vsudl", {
	description = "Part Lowhalf Vsect L Rubble",
	paramtype = "light",
	paramtype2 = "facedir",
	tiles = {"rubble.png"},
	groups = {vcol=0.83, cracky=3, oddly_breakable_by_hand=1, not_in_creative_inventory=1},
	drop = "stones:vsudl",
	collision_box = {type="fixed",fixed={
{-0.4375,-0.5,0.4375, 0.5,-0.0313,0.5},
{-0.375,-0.5,0.375, 0.5,-0.0625,0.4375},
{-0.3125,-0.5,0.3125, 0.5,-0.0937,0.375},
{-0.25,-0.5,0.25, 0.5,-0.125,0.3125},
{-0.1875,-0.5,0.1875, 0.5,-0.1563,0.25},
{-0.125,-0.5,0.125, 0.5,-0.1875,0.1875},
{-0.0625,-0.5,0.0625, 0.5,-0.2188,0.125},
{0,-0.5,0, 0.5,-0.25,0.0625},
{0.0625,-0.5,-0.0625, 0.5,-0.2818,0},
{0.125,-0.5,-0.125, 0.5,-0.3125,-0.0625},
{0.1875,-0.5,-0.1875, 0.5,-0.3438,-0.125},
{0.25,-0.5,-0.25, 0.5,-0.375,-0.1875},
{0.3125,-0.5,-0.3125, 0.5,-0.4088,-0.25},
{0.375,-0.5,-0.375, 0.5,-0.4375,-0.3125},
{0.4375,-0.5,-0.4375, 0.5,-0.4688,-0.375}}},
		selection_box = {type="fixed",fixed={
{-0.4375,-0.5,0.4375, 0.5,-0.0313,0.5},
{-0.375,-0.5,0.375, 0.5,-0.0625,0.4375},
{-0.3125,-0.5,0.3125, 0.5,-0.0937,0.375},
{-0.25,-0.5,0.25, 0.5,-0.125,0.3125},
{-0.1875,-0.5,0.1875, 0.5,-0.1563,0.25},
{-0.125,-0.5,0.125, 0.5,-0.1875,0.1875},
{-0.0625,-0.5,0.0625, 0.5,-0.2188,0.125},
{0,-0.5,0, 0.5,-0.25,0.0625},
{0.0625,-0.5,-0.0625, 0.5,-0.2818,0},
{0.125,-0.5,-0.125, 0.5,-0.3125,-0.0625},
{0.1875,-0.5,-0.1875, 0.5,-0.3438,-0.125},
{0.25,-0.5,-0.25, 0.5,-0.375,-0.1875},
{0.3125,-0.5,-0.3125, 0.5,-0.4088,-0.25},
{0.375,-0.5,-0.375, 0.5,-0.4375,-0.3125},
{0.4375,-0.5,-0.4375, 0.5,-0.4688,-0.375}}},
	drawtype = "mesh",
	mesh = "vsedl.obj"
})
