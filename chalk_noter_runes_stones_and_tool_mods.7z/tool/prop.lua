tool = {}

minetest.register_node("tool:prop", {
	description = "Propped P-Staff",
	paramtype = "light",
	paramtype2 = "facedir",
    inventory_image = "smokestaff.png",
	tiles = {"proptop.png", "propbottom.png", {name = "propipd.png",
		tileable_vertical = true}},
	groups = {vcol=0.00, choppy=2, dig_immediate=3, oddly_breakable_by_hand=1, not_in_creative_inventory=1},
	drop = "tool:pok",
	pointable = true,
	light_source = 14,
    node_box={type="fixed",fixed={
    {-0.0313,-0.5,-0.0313, 0.0313,0.5,0.0313}}},
	drawtype = "nodebox",
    use_texture_alpha = "clip",
    on_rightclick = function(pos, node, clicker, itemstack, pointed_thing)
		minetest.set_node(pos, {name = "tool:prup", param2 = node.param2})
        minetest.sound_play({name="whoosh", gain=0.05}, {pos=selfpos}, true)
	end
})

minetest.register_abm({
    nodenames = {"tool:prop"},
    interval = 3,
    chance = 10,
    action = function(pos, node)
        minetest.env:remove_node(pos)
        minetest.set_node(pos, {name = "tool:prup", param2 = node.param2})
        minetest.sound_play({name="whoosh", gain=0.05}, {pos=selfpos}, true)
        minetest.add_particlespawner({
    		amount = 1,
    		time = 1,
    		glow = 14,
       		pos = {x=pos.x, y=pos.y+0.5, z=pos.z},
    		minvel = {x=-0.2, y=0, z=-0.2},
    		maxvel = {x=0.2, y=0, z=0.2},
    		minacc = {x=0, y=0.2, z=0},
    		maxacc = {x=0, y=0.7, z=0},
    		exptime = {min=2, max=2},
    		collisiondetection = true,
    		collision_removal = false,
	    	texpool = {{name = "bubbles.png", animation = {type = "vertical_frames", aspect_w = 40, aspect_h = 40, length = 2.1}, blend='alpha', scale_tween={{x=10,y=10}}}}})
        minetest.add_particlespawner({
		amount = 10+math.random(1,10),
		time = 5+math.random(1,10),
		glow = 14,
		pos = {min={x=pos.x-0.5, y=pos.y+0.5, z=pos.z-0.5}, max={x=pos.x+0.5, y=pos.y+0.5, z=pos.z+0.5}, bias=math.random(0,1)},
		minvel = {x=-0.2+math.sin(pos.x), y=-0.2+math.sin(pos.x), z=-0.2+math.cos(pos.x)},
		maxvel = {x=0.2+math.sin(pos.x), y=0.8+math.sin(pos.x), z=0.2+math.cos(pos.x)},
		minacc = {x=-0.2+math.sin(pos.x), y=-0.8+math.sin(pos.x), z=-0.2+math.cos(pos.x)},
		maxacc = {x=0.2+math.cos(pos.x), y=0.2+math.sin(pos.x), z=0.2-math.sin(pos.x)},
		exptime = {min=2, max=5},
		collisiondetection = true,
		collision_removal = false,
		texpool = {
			{name = "glypy20.png", animation = {type = "vertical_frames", aspect_w = 6, aspect_h = 6, length = 2}, blend='alpha', scale_tween={{x=(math.random(10,20)/20),y=(math.random(10,20)/20)}}}}
        })
minetest.add_particlespawner({
		amount = 5+math.random(1,10),
		time = 10+math.random(1,10),
		glow = 14,
		pos = {min={x=pos.x-0.5, y=pos.y+0.5, z=pos.z-0.5}, max={x=pos.x+0.5, y=pos.y+0.5, z=pos.z+0.5}, bias=math.random(0,1)},
		minvel = {x=-0.1+math.sin(pos.x), y=-0.1+math.sin(pos.x), z=-0.1+math.cos(pos.x)},
		maxvel = {x=0.1+math.sin(pos.x), y=0.4+math.sin(pos.x), z=0.1+math.cos(pos.x)},
		minacc = {x=-0.1+math.sin(pos.x), y=-0.4+math.sin(pos.x), z=-0.1+math.cos(pos.x)},
		maxacc = {x=0.1+math.cos(pos.x), y=0.1+math.sin(pos.x), z=0.1-math.sin(pos.x)},
		exptime = {min=2, max=5},
		collisiondetection = true,
		collision_removal = false,
		texpool = {
			{name = "glypy20.png", animation = {type = "vertical_frames", aspect_w = 6, aspect_h = 6, length = 2}, blend='alpha', scale_tween={{x=(math.random(10,20)/40),y=(math.random(10,20)/40)}}}}
		})
    end
})

minetest.register_abm({
	nodenames = {"stones:blush"},
	neighbors = {"tool:prup"},
	interval = 1.0, -- Run every 10 seconds
	chance = 5, -- Select every 1 in 50 nodes
	action = function(pos, node, active_object_count, active_object_count_wider)
        minetest.env:remove_node(pos)
		minetest.set_node({x = pos.x, y = pos.y, z = pos.z}, {name = "stones:brush"})
	end
})

minetest.register_abm({
	nodenames = {"stones:brush"},
	neighbors = {"tool:prup"},
	interval = 1.0, -- Run every 10 seconds
	chance = 5, -- Select every 1 in 50 nodes
	action = function(pos, node, active_object_count, active_object_count_wider)
        minetest.env:remove_node(pos)
		minetest.set_node({x = pos.x, y = pos.y, z = pos.z}, {name = "stones:rush"})
	end
})

minetest.register_abm({
	nodenames = {"stones:rush"},
	neighbors = {"tool:prop"},
	interval = 1.0, -- Run every 10 seconds
	chance = 5, -- Select every 1 in 50 nodes
	action = function(pos, node, active_object_count, active_object_count_wider)
        minetest.env:remove_node(pos)
		minetest.set_node({x = pos.x, y = pos.y, z = pos.z}, {name = "stones:brush"})
	end
})

minetest.register_abm({
	nodenames = {"stones:brush"},
	neighbors = {"tool:prop"},
	interval = 1.0, -- Run every 10 seconds
	chance = 5, -- Select every 1 in 50 nodes
	action = function(pos, node, active_object_count, active_object_count_wider)
        minetest.env:remove_node(pos)
		minetest.set_node({x = pos.x, y = pos.y, z = pos.z}, {name = "stones:blush"}, {param2 = math.random(0,3)})
	end
})

minetest.register_abm({
	nodenames = {"stones:blushrock_0"},
	neighbors = {"tool:prup"},
	interval = 1.0, -- Run every 10 seconds
	chance = 5, -- Select every 1 in 50 nodes
	action = function(pos, node, active_object_count, active_object_count_wider)
        minetest.env:remove_node(pos)
		minetest.set_node({x = pos.x, y = pos.y, z = pos.z}, {name = "stones:brushrock_0",  param2 = math.floor((node.param2)/4)*4+(node.param2-1)%4})
	end
})

minetest.register_abm({
	nodenames = {"stones:brushrock_0"},
	neighbors = {"tool:prup"},
	interval = 1.0, -- Run every 10 seconds
	chance = 5, -- Select every 1 in 50 nodes
	action = function(pos, node, active_object_count, active_object_count_wider)
        minetest.env:remove_node(pos)
		minetest.set_node({x = pos.x, y = pos.y, z = pos.z}, {name = "stones:rushrock_0",  param2 = math.floor((node.param2)/4)*4+(node.param2)%4})
	end
})

minetest.register_abm({
	nodenames = {"stones:rushrock_0"},
	neighbors = {"tool:prup"},
	interval = 1.0, -- Run every 10 seconds
	chance = 5, -- Select every 1 in 50 nodes
	action = function(pos, node, active_object_count, active_object_count_wider)
        minetest.env:remove_node(pos)
		minetest.set_node({x = pos.x, y = pos.y, z = pos.z}, {name = "stones:rublish_0",  param2 = math.floor((node.param2)/4)*4+(node.param2)%4})
	end
})

minetest.register_abm({
	nodenames = {"stones:rublish_0"},
	neighbors = {"tool:prop"},
	interval = 1.0, -- Run every 10 seconds
	chance = 5, -- Select every 1 in 50 nodes
	action = function(pos, node, active_object_count, active_object_count_wider)
        minetest.env:remove_node(pos)
		minetest.set_node({x = pos.x, y = pos.y, z = pos.z}, {name = "stones:rushrock_0",  param2 = math.floor((node.param2)/4)*4+(node.param2)%4})
	end
})

minetest.register_abm({
	nodenames = {"stones:rushrock_0"},
	neighbors = {"tool:prop"},
	interval = 1.0, -- Run every 10 seconds
	chance = 5, -- Select every 1 in 50 nodes
	action = function(pos, node, active_object_count, active_object_count_wider)
        minetest.env:remove_node(pos)
		minetest.set_node({x = pos.x, y = pos.y, z = pos.z},  {name = "stones:brushrock_0",  param2 = math.floor((node.param2)/4)*4+(node.param2)%4})
	end
})

minetest.register_abm({
	nodenames = {"stones:brushrock_0"},
	neighbors = {"tool:prop"},
	interval = 1.0, -- Run every 10 seconds
	chance = 5, -- Select every 1 in 50 nodes
	action = function(pos, node, active_object_count, active_object_count_wider)
        minetest.env:remove_node(pos)
		minetest.set_node({x = pos.x, y = pos.y, z = pos.z}, {name = "stones:blushrock_0",  param2 = math.floor((node.param2)/4)*4+(node.param2+1)%4})
	end
})

minetest.register_abm({
	nodenames = {"stones:blushrock_1"},
	neighbors = {"tool:prup"},
	interval = 1.0, -- Run every 10 seconds
	chance = 5, -- Select every 1 in 50 nodes
	action = function(pos, node, active_object_count, active_object_count_wider)
        minetest.env:remove_node(pos)
		minetest.set_node({x = pos.x, y = pos.y, z = pos.z}, {name = "stones:brushrock_1", param2 = math.floor((node.param2)/4)*4+(node.param2-1)%4})
	end
})

minetest.register_abm({
	nodenames = {"stones:brushrock_1"},
	neighbors = {"tool:prup"},
	interval = 1.0, -- Run every 10 seconds
	chance = 5, -- Select every 1 in 50 nodes
	action = function(pos, node, active_object_count, active_object_count_wider)
        minetest.env:remove_node(pos)
		minetest.set_node({x = pos.x, y = pos.y, z = pos.z},  {name = "stones:rushrock_1",  param2 = math.floor((node.param2)/4)*4+(node.param2)%4})
	end
})

minetest.register_abm({
	nodenames = {"stones:rushrock_1"},
	neighbors = {"tool:prup"},
	interval = 1.0, -- Run every 10 seconds
	chance = 5, -- Select every 1 in 50 nodes
	action = function(pos, node, active_object_count, active_object_count_wider)
        minetest.env:remove_node(pos)
		minetest.set_node({x = pos.x, y = pos.y, z = pos.z}, {name = "stones:rublish_1",  param2 = math.floor((node.param2)/4)*4+(node.param2)%4})
	end
})

minetest.register_abm({
	nodenames = {"stones:rublish_1"},
	neighbors = {"tool:prop"},
	interval = 1.0, -- Run every 10 seconds
	chance = 5, -- Select every 1 in 50 nodes
	action = function(pos, node, active_object_count, active_object_count_wider)
        minetest.env:remove_node(pos)
		minetest.set_node({x = pos.x, y = pos.y, z = pos.z}, {name = "stones:rushrock_1",  param2 = math.floor((node.param2)/4)*4+(node.param2)%4})
	end
})

minetest.register_abm({
	nodenames = {"stones:rushrock_1"},
	neighbors = {"tool:prop"},
	interval = 1.0, -- Run every 10 seconds
	chance = 5, -- Select every 1 in 50 nodes
	action = function(pos, node, active_object_count, active_object_count_wider)
        minetest.env:remove_node(pos)
		minetest.set_node({x = pos.x, y = pos.y, z = pos.z}, {name = "stones:brushrock_1",  param2 = math.floor((node.param2)/4)*4+(node.param2)%4})
	end
})

minetest.register_abm({
	nodenames = {"stones:brushrock_1"},
	neighbors = {"tool:prop"},
	interval = 1.0, -- Run every 10 seconds
	chance = 5, -- Select every 1 in 50 nodes
	action = function(pos, node, active_object_count, active_object_count_wider)
        minetest.env:remove_node(pos)
		minetest.set_node({x = pos.x, y = pos.y, z = pos.z}, {name = "stones:blushrock_1",  param2 = math.floor((node.param2)/4)*4+(node.param2+1)%4})
	end
})

minetest.register_abm({
	nodenames = {"stones:blushrock_2"},
	neighbors = {"tool:prup"},
	interval = 1.0, -- Run every 10 seconds
	chance = 5, -- Select every 1 in 50 nodes
	action = function(pos, node, active_object_count, active_object_count_wider)
        minetest.env:remove_node(pos)
		minetest.set_node({x = pos.x, y = pos.y, z = pos.z}, {name = "stones:brushrock_2", param2 = math.floor((node.param2)/4)*4+(node.param2)%4})
	end
})

minetest.register_abm({
	nodenames = {"stones:brushrock_2"},
	neighbors = {"tool:prup"},
	interval = 1.0, -- Run every 10 seconds
	chance = 5, -- Select every 1 in 50 nodes
	action = function(pos, node, active_object_count, active_object_count_wider)
        minetest.env:remove_node(pos)
		minetest.set_node({x = pos.x, y = pos.y, z = pos.z}, {name = "stones:rushrock_2", param2 = math.floor((node.param2)/4)*4+(node.param2)%4})
	end
})

minetest.register_abm({
	nodenames = {"stones:rushrock_2"},
	neighbors = {"tool:prup"},
	interval = 1.0, -- Run every 10 seconds
	chance = 5, -- Select every 1 in 50 nodes
	action = function(pos, node, active_object_count, active_object_count_wider)
        minetest.env:remove_node(pos)
		minetest.set_node({x = pos.x, y = pos.y, z = pos.z}, {name = "stones:rublish_2", param2 = math.floor((node.param2)/4)*4+(node.param2)%4})
	end
})

minetest.register_abm({
	nodenames = {"stones:rublish_2"},
	neighbors = {"tool:prop"},
	interval = 1.0, -- Run every 10 seconds
	chance = 5, -- Select every 1 in 50 nodes
	action = function(pos, node, active_object_count, active_object_count_wider)
        minetest.env:remove_node(pos)
		minetest.set_node({x = pos.x, y = pos.y, z = pos.z}, {name = "stones:rushrock_2", param2 = math.floor((node.param2)/4)*4+(node.param2)%4})
	end
})

minetest.register_abm({
	nodenames = {"stones:rushrock_2"},
	neighbors = {"tool:prop"},
	interval = 1.0, -- Run every 10 seconds
	chance = 5, -- Select every 1 in 50 nodes
	action = function(pos, node, active_object_count, active_object_count_wider)
        minetest.env:remove_node(pos)
		minetest.set_node({x = pos.x, y = pos.y, z = pos.z}, {name = "stones:brushrock_2", param2 = math.floor((node.param2)/4)*4+(node.param2)%4})
	end
})

minetest.register_abm({
	nodenames = {"stones:brushrock_2"},
	neighbors = {"tool:prop"},
	interval = 1.0, -- Run every 10 seconds
	chance = 5, -- Select every 1 in 50 nodes
	action = function(pos, node, active_object_count, active_object_count_wider)
        minetest.env:remove_node(pos)
		minetest.set_node({x = pos.x, y = pos.y, z = pos.z}, {name = "stones:blushrock_2", param2 = math.floor((node.param2)/4)*4+(node.param2)%4})
	end
})

minetest.register_abm({
	nodenames = {"stones:blushrock_3"},
	neighbors = {"tool:prup"},
	interval = 1.0, -- Run every 10 seconds
	chance = 5, -- Select every 1 in 50 nodes
	action = function(pos, node, active_object_count, active_object_count_wider)
        minetest.env:remove_node(pos)
		minetest.set_node({x = pos.x, y = pos.y, z = pos.z}, {name = "stones:brushrock_3", param2 = math.floor((node.param2)/4)*4+(node.param2-1)%4})
	end
})

minetest.register_abm({
	nodenames = {"stones:brushrock_3"},
	neighbors = {"tool:prup"},
	interval = 1.0, -- Run every 10 seconds
	chance = 5, -- Select every 1 in 50 nodes
	action = function(pos, node, active_object_count, active_object_count_wider)
        minetest.env:remove_node(pos)
		minetest.set_node({x = pos.x, y = pos.y, z = pos.z}, {name = "stones:rushrock_3",  param2 = math.floor((node.param2)/4)*4+(node.param2)%4})
	end
})

minetest.register_abm({
	nodenames = {"stones:rushrock_3"},
	neighbors = {"tool:prup"},
	interval = 1.0, -- Run every 10 seconds
	chance = 5, -- Select every 1 in 50 nodes
	action = function(pos, node, active_object_count, active_object_count_wider)
        minetest.env:remove_node(pos)
		minetest.set_node({x = pos.x, y = pos.y, z = pos.z}, {name = "stones:rublish_3",  param2 = math.floor((node.param2)/4)*4+(node.param2)%4})
	end
})

minetest.register_abm({
	nodenames = {"stones:rublish_3"},
	neighbors = {"tool:prop"},
	interval = 1.0, -- Run every 10 seconds
	chance = 5, -- Select every 1 in 50 nodes
	action = function(pos, node, active_object_count, active_object_count_wider)
        minetest.env:remove_node(pos)
		minetest.set_node({x = pos.x, y = pos.y, z = pos.z}, {name = "stones:rushrock_3",  param2 = math.floor((node.param2)/4)*4+(node.param2)%4})
	end
})

minetest.register_abm({
	nodenames = {"stones:rushrock_3"},
	neighbors = {"tool:prop"},
	interval = 1.0, -- Run every 10 seconds
	chance = 5, -- Select every 1 in 50 nodes
	action = function(pos, node, active_object_count, active_object_count_wider)
        minetest.env:remove_node(pos)
		minetest.set_node({x = pos.x, y = pos.y, z = pos.z}, {name = "stones:brushrock_3",  param2 = math.floor((node.param2)/4)*4+(node.param2)%4})
	end
})

minetest.register_abm({
	nodenames = {"stones:brushrock_3"},
	neighbors = {"tool:prop"},
	interval = 1.0, -- Run every 10 seconds
	chance = 5, -- Select every 1 in 50 nodes
	action = function(pos, node, active_object_count, active_object_count_wider)
        minetest.env:remove_node(pos)
		minetest.set_node({x = pos.x, y = pos.y, z = pos.z}, {name = "stones:blushrock_3",  param2 = math.floor((node.param2)/4)*4+(node.param2+1)%4})
	end
})

minetest.register_abm({
	nodenames = {"stones:blushrock_4"},
	neighbors = {"tool:prup"},
	interval = 1.0, -- Run every 10 seconds
	chance = 5, -- Select every 1 in 50 nodes
	action = function(pos, node, active_object_count, active_object_count_wider)
        minetest.env:remove_node(pos)
		minetest.set_node({x = pos.x, y = pos.y, z = pos.z}, {name = "stones:brushrock_4",  param2 = math.floor((node.param2)/4)*4+(node.param2)%4})
	end
})

minetest.register_abm({
	nodenames = {"stones:brushrock_4"},
	neighbors = {"tool:prup"},
	interval = 1.0, -- Run every 10 seconds
	chance = 5, -- Select every 1 in 50 nodes
	action = function(pos, node, active_object_count, active_object_count_wider)
        minetest.env:remove_node(pos)
		minetest.set_node({x = pos.x, y = pos.y, z = pos.z}, {name = "stones:rushrock_4",  param2 = math.floor((node.param2)/4)*4+(node.param2)%4})
	end
})

minetest.register_abm({
	nodenames = {"stones:rushrock_4"},
	neighbors = {"tool:prup"},
	interval = 1.0, -- Run every 10 seconds
	chance = 5, -- Select every 1 in 50 nodes
	action = function(pos, node, active_object_count, active_object_count_wider)
        minetest.env:remove_node(pos)
		minetest.set_node({x = pos.x, y = pos.y, z = pos.z}, {name = "stones:rublish_4",  param2 = math.floor((node.param2)/4)*4+(node.param2)%4})
	end
})

minetest.register_abm({
	nodenames = {"stones:rublish_4"},
	neighbors = {"tool:prop"},
	interval = 1.0, -- Run every 10 seconds
	chance = 5, -- Select every 1 in 50 nodes
	action = function(pos, node, active_object_count, active_object_count_wider)
        minetest.env:remove_node(pos)
		minetest.set_node({x = pos.x, y = pos.y, z = pos.z}, {name = "stones:rushrock_4",  param2 = math.floor((node.param2)/4)*4+(node.param2)%4})
	end
})

minetest.register_abm({
	nodenames = {"stones:rushrock_4"},
	neighbors = {"tool:prop"},
	interval = 1.0, -- Run every 10 seconds
	chance = 5, -- Select every 1 in 50 nodes
	action = function(pos, node, active_object_count, active_object_count_wider)
        minetest.env:remove_node(pos)
		minetest.set_node({x = pos.x, y = pos.y, z = pos.z}, {name = "stones:brushrock_4",  param2 = math.floor((node.param2)/4)*4+(node.param2)%4})
	end
})

minetest.register_abm({
	nodenames = {"stones:brushrock_4"},
	neighbors = {"tool:prop"},
	interval = 1.0, -- Run every 10 seconds
	chance = 5, -- Select every 1 in 50 nodes
	action = function(pos, node, active_object_count, active_object_count_wider)
        minetest.env:remove_node(pos)
		minetest.set_node({x = pos.x, y = pos.y, z = pos.z}, {name = "stones:blushrock_4",  param2 = math.floor((node.param2)/4)*4+(node.param2)%4})
	end
})

minetest.register_abm({
	nodenames = {"stones:blushrock_5"},
	neighbors = {"tool:prup"},
	interval = 1.0, -- Run every 10 seconds
	chance = 5, -- Select every 1 in 50 nodes
	action = function(pos, node, active_object_count, active_object_count_wider)
        minetest.env:remove_node(pos)
		minetest.set_node({x = pos.x, y = pos.y, z = pos.z}, {name = "stones:brushrock_5", param2 = math.floor((node.param2)/4)*4+(node.param2)%4})
	end
})

minetest.register_abm({
	nodenames = {"stones:brushrock_5"},
	neighbors = {"tool:prup"},
	interval = 1.0, -- Run every 10 seconds
	chance = 5, -- Select every 1 in 50 nodes
	action = function(pos, node, active_object_count, active_object_count_wider)
        minetest.env:remove_node(pos)
		minetest.set_node({x = pos.x, y = pos.y, z = pos.z}, {name = "stones:rushrock_5", param2 = math.floor((node.param2)/4)*4+(node.param2)%4})
	end
})

minetest.register_abm({
	nodenames = {"stones:rushrock_5"},
	neighbors = {"tool:prup"},
	interval = 1.0, -- Run every 10 seconds
	chance = 5, -- Select every 1 in 50 nodes
	action = function(pos, node, active_object_count, active_object_count_wider)
        minetest.env:remove_node(pos)
		minetest.set_node({x = pos.x, y = pos.y, z = pos.z}, {name = "stones:rublish_5", param2 = math.floor((node.param2)/4)*4+(node.param2)%4})
	end
})

minetest.register_abm({
	nodenames = {"stones:rublish_5"},
	neighbors = {"tool:prop"},
	interval = 1.0, -- Run every 10 seconds
	chance = 5, -- Select every 1 in 50 nodes
	action = function(pos, node, active_object_count, active_object_count_wider)
        minetest.env:remove_node(pos)
		minetest.set_node({x = pos.x, y = pos.y, z = pos.z}, {name = "stones:rushrock_5", param2 = math.floor((node.param2)/4)*4+(node.param2)%4})
	end
})

minetest.register_abm({
	nodenames = {"stones:rushrock_5"},
	neighbors = {"tool:prop"},
	interval = 1.0, -- Run every 10 seconds
	chance = 5, -- Select every 1 in 50 nodes
	action = function(pos, node, active_object_count, active_object_count_wider)
        minetest.env:remove_node(pos)
		minetest.set_node({x = pos.x, y = pos.y, z = pos.z}, {name = "stones:brushrock_5", param2 = math.floor((node.param2)/4)*4+(node.param2)%4})
	end
})

minetest.register_abm({
	nodenames = {"stones:brushrock_5"},
	neighbors = {"tool:prop"},
	interval = 1.0, -- Run every 10 seconds
	chance = 5, -- Select every 1 in 50 nodes
	action = function(pos, node, active_object_count, active_object_count_wider)
        minetest.env:remove_node(pos)
		minetest.set_node({x = pos.x, y = pos.y, z = pos.z}, {name = "stones:blushrock_5", param2 = math.floor((node.param2)/4)*4+(node.param2)%4})
	end
})

minetest.register_abm({
	nodenames = {"stones:blushrock_52ul"},
	neighbors = {"tool:prup"},
	interval = 1.0, -- Run every 10 seconds
	chance = 5, -- Select every 1 in 50 nodes
	action = function(pos, node, active_object_count, active_object_count_wider)
        minetest.env:remove_node(pos)
		minetest.set_node({x = pos.x, y = pos.y, z = pos.z}, {name = "stones:brushrock_52ul", param2 = math.floor((node.param2)/4)*4+(node.param2)%4})
	end
})

minetest.register_abm({
	nodenames = {"stones:brushrock_52ul"},
	neighbors = {"tool:prup"},
	interval = 1.0, -- Run every 10 seconds
	chance = 5, -- Select every 1 in 50 nodes
	action = function(pos, node, active_object_count, active_object_count_wider)
        minetest.env:remove_node(pos)
		minetest.set_node({x = pos.x, y = pos.y, z = pos.z}, {name = "stones:rushrock_52ul", param2 = math.floor((node.param2)/4)*4+(node.param2)%4})
	end
})

minetest.register_abm({
	nodenames = {"stones:rushrock_52ul"},
	neighbors = {"tool:prup"},
	interval = 1.0, -- Run every 10 seconds
	chance = 5, -- Select every 1 in 50 nodes
	action = function(pos, node, active_object_count, active_object_count_wider)
        minetest.env:remove_node(pos)
		minetest.set_node({x = pos.x, y = pos.y, z = pos.z}, {name = "stones:rublish_52ul", param2 = math.floor((node.param2)/4)*4+(node.param2)%4})
	end
})

minetest.register_abm({
	nodenames = {"stones:rublish_52ul"},
	neighbors = {"tool:prop"},
	interval = 1.0, -- Run every 10 seconds
	chance = 5, -- Select every 1 in 50 nodes
	action = function(pos, node, active_object_count, active_object_count_wider)
        minetest.env:remove_node(pos)
		minetest.set_node({x = pos.x, y = pos.y, z = pos.z}, {name = "stones:rushrock_52ul", param2 = math.floor((node.param2)/4)*4+(node.param2)%4})
	end
})

minetest.register_abm({
	nodenames = {"stones:rushrock_52ul"},
	neighbors = {"tool:prop"},
	interval = 1.0, -- Run every 10 seconds
	chance = 5, -- Select every 1 in 50 nodes
	action = function(pos, node, active_object_count, active_object_count_wider)
        minetest.env:remove_node(pos)
		minetest.set_node({x = pos.x, y = pos.y, z = pos.z}, {name = "stones:brushrock_52ul", param2 = math.floor((node.param2)/4)*4+(node.param2)%4})
	end
})

minetest.register_abm({
	nodenames = {"stones:brushrock_52ul"},
	neighbors = {"tool:prop"},
	interval = 1.0, -- Run every 10 seconds
	chance = 5, -- Select every 1 in 50 nodes
	action = function(pos, node, active_object_count, active_object_count_wider)
        minetest.env:remove_node(pos)
		minetest.set_node({x = pos.x, y = pos.y, z = pos.z}, {name = "stones:blushrock_52ul", param2 = math.floor((node.param2)/4)*4+(node.param2)%4})
	end
})

minetest.register_abm({
	nodenames = {"stones:blushrock_52ur"},
	neighbors = {"tool:prup"},
	interval = 1.0, -- Run every 10 seconds
	chance = 5, -- Select every 1 in 50 nodes
	action = function(pos, node, active_object_count, active_object_count_wider)
        minetest.env:remove_node(pos)
		minetest.set_node({x = pos.x, y = pos.y, z = pos.z}, {name = "stones:brushrock_52ur", param2 = math.floor((node.param2)/4)*4+(node.param2)%4})
	end
})

minetest.register_abm({
	nodenames = {"stones:brushrock_52ur"},
	neighbors = {"tool:prup"},
	interval = 1.0, -- Run every 10 seconds
	chance = 5, -- Select every 1 in 50 nodes
	action = function(pos, node, active_object_count, active_object_count_wider)
        minetest.env:remove_node(pos)
		minetest.set_node({x = pos.x, y = pos.y, z = pos.z}, {name = "stones:rushrock_52ur", param2 = math.floor((node.param2)/4)*4+(node.param2)%4})
	end
})

minetest.register_abm({
	nodenames = {"stones:rushrock_52ur"},
	neighbors = {"tool:prup"},
	interval = 1.0, -- Run every 10 seconds
	chance = 5, -- Select every 1 in 50 nodes
	action = function(pos, node, active_object_count, active_object_count_wider)
        minetest.env:remove_node(pos)
		minetest.set_node({x = pos.x, y = pos.y, z = pos.z}, {name = "stones:rublish_52ur", param2 = math.floor((node.param2)/4)*4+(node.param2)%4})
	end
})

minetest.register_abm({
	nodenames = {"stones:rublish_52ur"},
	neighbors = {"tool:prop"},
	interval = 1.0, -- Run every 10 seconds
	chance = 5, -- Select every 1 in 50 nodes
	action = function(pos, node, active_object_count, active_object_count_wider)
        minetest.env:remove_node(pos)
		minetest.set_node({x = pos.x, y = pos.y, z = pos.z}, {name = "stones:rushrock_52ur", param2 = math.floor((node.param2)/4)*4+(node.param2)%4})
	end
})

minetest.register_abm({
	nodenames = {"stones:rushrock_52ur"},
	neighbors = {"tool:prop"},
	interval = 1.0, -- Run every 10 seconds
	chance = 5, -- Select every 1 in 50 nodes
	action = function(pos, node, active_object_count, active_object_count_wider)
        minetest.env:remove_node(pos)
		minetest.set_node({x = pos.x, y = pos.y, z = pos.z}, {name = "stones:brushrock_52ur", param2 = math.floor((node.param2)/4)*4+(node.param2)%4})
	end
})

minetest.register_abm({
	nodenames = {"stones:brushrock_52ur"},
	neighbors = {"tool:prop"},
	interval = 1.0, -- Run every 10 seconds
	chance = 5, -- Select every 1 in 50 nodes
	action = function(pos, node, active_object_count, active_object_count_wider)
        minetest.env:remove_node(pos)
		minetest.set_node({x = pos.x, y = pos.y, z = pos.z}, {name = "stones:blushrock_52ur", param2 = math.floor((node.param2)/4)*4+(node.param2)%4})
	end
})

minetest.register_abm({
	nodenames = {"stones:blushrock_527l"},
	neighbors = {"tool:prup"},
	interval = 1.0, -- Run every 10 seconds
	chance = 5, -- Select every 1 in 50 nodes
	action = function(pos, node, active_object_count, active_object_count_wider)
        minetest.env:remove_node(pos)
		minetest.set_node({x = pos.x, y = pos.y, z = pos.z}, {name = "stones:brushrock_527l",  param2 = math.floor((node.param2)/4)*4+(node.param2)%4})
	end
})

minetest.register_abm({
	nodenames = {"stones:brushrock_527l"},
	neighbors = {"tool:prup"},
	interval = 1.0, -- Run every 10 seconds
	chance = 5, -- Select every 1 in 50 nodes
	action = function(pos, node, active_object_count, active_object_count_wider)
        minetest.env:remove_node(pos)
		minetest.set_node({x = pos.x, y = pos.y, z = pos.z}, {name = "stones:rushrock_527l",  param2 = math.floor((node.param2)/4)*4+(node.param2)%4})
	end
})

minetest.register_abm({
	nodenames = {"stones:rushrock_527l"},
	neighbors = {"tool:prup"},
	interval = 1.0, -- Run every 10 seconds
	chance = 5, -- Select every 1 in 50 nodes
	action = function(pos, node, active_object_count, active_object_count_wider)
        minetest.env:remove_node(pos)
		minetest.set_node({x = pos.x, y = pos.y, z = pos.z}, {name = "stones:rublish_527l",  param2 = math.floor((node.param2)/4)*4+(node.param2)%4})
	end
})

minetest.register_abm({
	nodenames = {"stones:rublish_527l"},
	neighbors = {"tool:prop"},
	interval = 1.0, -- Run every 10 seconds
	chance = 5, -- Select every 1 in 50 nodes
	action = function(pos, node, active_object_count, active_object_count_wider)
        minetest.env:remove_node(pos)
		minetest.set_node({x = pos.x, y = pos.y, z = pos.z}, {name = "stones:rushrock_527l",  param2 = math.floor((node.param2)/4)*4+(node.param2)%4})
	end
})

minetest.register_abm({
	nodenames = {"stones:rushrock_527l"},
	neighbors = {"tool:prop"},
	interval = 1.0, -- Run every 10 seconds
	chance = 5, -- Select every 1 in 50 nodes
	action = function(pos, node, active_object_count, active_object_count_wider)
        minetest.env:remove_node(pos)
		minetest.set_node({x = pos.x, y = pos.y, z = pos.z}, {name = "stones:brushrock_527l",  param2 = math.floor((node.param2)/4)*4+(node.param2)%4})
	end
})

minetest.register_abm({
	nodenames = {"stones:brushrock_527l"},
	neighbors = {"tool:prop"},
	interval = 1.0, -- Run every 10 seconds
	chance = 5, -- Select every 1 in 50 nodes
	action = function(pos, node, active_object_count, active_object_count_wider)
        minetest.env:remove_node(pos)
		minetest.set_node({x = pos.x, y = pos.y, z = pos.z}, {name = "stones:blushrock_527l",  param2 = math.floor((node.param2)/4)*4+(node.param2)%4})
	end
})

minetest.register_abm({
	nodenames = {"stones:blushrock_527r"},
	neighbors = {"tool:prup"},
	interval = 1.0, -- Run every 10 seconds
	chance = 5, -- Select every 1 in 50 nodes
	action = function(pos, node, active_object_count, active_object_count_wider)
        minetest.env:remove_node(pos)
		minetest.set_node({x = pos.x, y = pos.y, z = pos.z}, {name = "stones:brushrock_527r", param2 = math.floor((node.param2)/4)*4+(node.param2)%4})
	end
})

minetest.register_abm({
	nodenames = {"stones:brushrock_527r"},
	neighbors = {"tool:prup"},
	interval = 1.0, -- Run every 10 seconds
	chance = 5, -- Select every 1 in 50 nodes
	action = function(pos, node, active_object_count, active_object_count_wider)
        minetest.env:remove_node(pos)
		minetest.set_node({x = pos.x, y = pos.y, z = pos.z}, {name = "stones:rushrock_527r", param2 = math.floor((node.param2)/4)*4+(node.param2)%4})
	end
})

minetest.register_abm({
	nodenames = {"stones:rushrock_527r"},
	neighbors = {"tool:prup"},
	interval = 1.0, -- Run every 10 seconds
	chance = 5, -- Select every 1 in 50 nodes
	action = function(pos, node, active_object_count, active_object_count_wider)
        minetest.env:remove_node(pos)
		minetest.set_node({x = pos.x, y = pos.y, z = pos.z}, {name = "stones:rublish_527r", param2 = math.floor((node.param2)/4)*4+(node.param2)%4})
	end
})

minetest.register_abm({
	nodenames = {"stones:rublish_527r"},
	neighbors = {"tool:prop"},
	interval = 1.0, -- Run every 10 seconds
	chance = 5, -- Select every 1 in 50 nodes
	action = function(pos, node, active_object_count, active_object_count_wider)
        minetest.env:remove_node(pos)
		minetest.set_node({x = pos.x, y = pos.y, z = pos.z}, {name = "stones:rushrock_527r", param2 = math.floor((node.param2)/4)*4+(node.param2)%4})
	end
})

minetest.register_abm({
	nodenames = {"stones:rushrock_527r"},
	neighbors = {"tool:prop"},
	interval = 1.0, -- Run every 10 seconds
	chance = 5, -- Select every 1 in 50 nodes
	action = function(pos, node, active_object_count, active_object_count_wider)
        minetest.env:remove_node(pos)
		minetest.set_node({x = pos.x, y = pos.y, z = pos.z}, {name = "stones:brushrock_527r", param2 = math.floor((node.param2)/4)*4+(node.param2)%4})
	end
})

minetest.register_abm({
	nodenames = {"stones:brushrock_527r"},
	neighbors = {"tool:prop"},
	interval = 1.0, -- Run every 10 seconds
	chance = 5, -- Select every 1 in 50 nodes
	action = function(pos, node, active_object_count, active_object_count_wider)
        minetest.env:remove_node(pos)
		minetest.set_node({x = pos.x, y = pos.y, z = pos.z}, {name = "stones:blushrock_527r", param2 = math.floor((node.param2)/4)*4+(node.param2)%4})
	end
})

minetest.register_abm({
	nodenames = {"stones:blushrock_8"},
	neighbors = {"tool:prup"},
	interval = 1.0, -- Run every 10 seconds
	chance = 5, -- Select every 1 in 50 nodes
	action = function(pos, node, active_object_count, active_object_count_wider)
        minetest.env:remove_node(pos)
		minetest.set_node({x = pos.x, y = pos.y, z = pos.z}, {name = "stones:brushrock_8", param2 = math.floor((node.param2)/4)*4+(node.param2)%4})
	end
})

minetest.register_abm({
	nodenames = {"stones:brushrock_8"},
	neighbors = {"tool:prup"},
	interval = 1.0, -- Run every 10 seconds
	chance = 5, -- Select every 1 in 50 nodes
	action = function(pos, node, active_object_count, active_object_count_wider)
        minetest.env:remove_node(pos)
		minetest.set_node({x = pos.x, y = pos.y, z = pos.z}, {name = "stones:rushrock_8", param2 = math.floor((node.param2)/4)*4+(node.param2)%4})
	end
})

minetest.register_abm({
	nodenames = {"stones:rushrock_8"},
	neighbors = {"tool:prup"},
	interval = 1.0, -- Run every 10 seconds
	chance = 5, -- Select every 1 in 50 nodes
	action = function(pos, node, active_object_count, active_object_count_wider)
        minetest.env:remove_node(pos)
		minetest.set_node({x = pos.x, y = pos.y, z = pos.z}, {name = "stones:rublish_8", param2 = math.floor((node.param2)/4)*4+(node.param2)%4})
	end
})

minetest.register_abm({
	nodenames = {"stones:rublish_8"},
	neighbors = {"tool:prop"},
	interval = 1.0, -- Run every 10 seconds
	chance = 5, -- Select every 1 in 50 nodes
	action = function(pos, node, active_object_count, active_object_count_wider)
        minetest.env:remove_node(pos)
		minetest.set_node({x = pos.x, y = pos.y, z = pos.z}, {name = "stones:rushrock_8", param2 = math.floor((node.param2)/4)*4+(node.param2)%4})
	end
})

minetest.register_abm({
	nodenames = {"stones:rushrock_8"},
	neighbors = {"tool:prop"},
	interval = 1.0, -- Run every 10 seconds
	chance = 5, -- Select every 1 in 50 nodes
	action = function(pos, node, active_object_count, active_object_count_wider)
        minetest.env:remove_node(pos)
		minetest.set_node({x = pos.x, y = pos.y, z = pos.z}, {name = "stones:brushrock_8", param2 = math.floor((node.param2)/4)*4+(node.param2)%4})
	end
})

minetest.register_abm({
	nodenames = {"stones:brushrock_8"},
	neighbors = {"tool:prop"},
	interval = 1.0, -- Run every 10 seconds
	chance = 5, -- Select every 1 in 50 nodes
	action = function(pos, node, active_object_count, active_object_count_wider)
        minetest.env:remove_node(pos)
		minetest.set_node({x = pos.x, y = pos.y, z = pos.z}, {name = "stones:blushrock_8", param2 = math.floor((node.param2)/4)*4+(node.param2)%4})
	end
})

minetest.register_abm({
	nodenames = {"stones:blushrock_28"},
	neighbors = {"tool:prup"},
	interval = 1.0, -- Run every 10 seconds
	chance = 5, -- Select every 1 in 50 nodes
	action = function(pos, node, active_object_count, active_object_count_wider)
        minetest.env:remove_node(pos)
		minetest.set_node({x = pos.x, y = pos.y, z = pos.z},  {name = "stones:brushrock_28",  param2 = math.floor((node.param2)/4)*4+(node.param2)%4})
	end
})

minetest.register_abm({
	nodenames = {"stones:brushrock_28"},
	neighbors = {"tool:prup"},
	interval = 1.0, -- Run every 10 seconds
	chance = 5, -- Select every 1 in 50 nodes
	action = function(pos, node, active_object_count, active_object_count_wider)
        minetest.env:remove_node(pos)
		minetest.set_node({x = pos.x, y = pos.y, z = pos.z},  {name = "stones:rushrock_28",  param2 = math.floor((node.param2)/4)*4+(node.param2)%4})
	end
})

minetest.register_abm({
	nodenames = {"stones:rushrock_28"},
	neighbors = {"tool:prup"},
	interval = 1.0, -- Run every 10 seconds
	chance = 5, -- Select every 1 in 50 nodes
	action = function(pos, node, active_object_count, active_object_count_wider)
        minetest.env:remove_node(pos)
		minetest.set_node({x = pos.x, y = pos.y, z = pos.z},  {name = "stones:rublish_28", param2 = math.floor((node.param2)/4)*4+(node.param2)%4})
	end
})

minetest.register_abm({
	nodenames = {"stones:rublish_28"},
	neighbors = {"tool:prop"},
	interval = 1.0, -- Run every 10 seconds
	chance = 5, -- Select every 1 in 50 nodes
	action = function(pos, node, active_object_count, active_object_count_wider)
        minetest.env:remove_node(pos)
		minetest.set_node({x = pos.x, y = pos.y, z = pos.z},  {name = "stones:rushrock_28",  param2 = math.floor((node.param2)/4)*4+(node.param2)%4})
	end
})

minetest.register_abm({
	nodenames = {"stones:rushrock_28"},
	neighbors = {"tool:prop"},
	interval = 1.0, -- Run every 10 seconds
	chance = 5, -- Select every 1 in 50 nodes
	action = function(pos, node, active_object_count, active_object_count_wider)
        minetest.env:remove_node(pos)
		minetest.set_node({x = pos.x, y = pos.y, z = pos.z},  {name = "stones:brushrock_28",  param2 = math.floor((node.param2)/4)*4+(node.param2)%4})
	end
})

minetest.register_abm({
	nodenames = {"stones:brushrock_28"},
	neighbors = {"tool:prop"},
	interval = 1.0, -- Run every 10 seconds
	chance = 5, -- Select every 1 in 50 nodes
	action = function(pos, node, active_object_count, active_object_count_wider)
        minetest.env:remove_node(pos)
		minetest.set_node({x = pos.x, y = pos.y, z = pos.z},   {name = "stones:blushrock_28",  param2 = math.floor((node.param2)/4)*4+(node.param2)%4})
	end
})

minetest.register_abm({
	nodenames = {"stones:blushrock_2u"},
	neighbors = {"tool:prup"},
	interval = 1.0, -- Run every 10 seconds
	chance = 5, -- Select every 1 in 50 nodes
	action = function(pos, node, active_object_count, active_object_count_wider)
        minetest.env:remove_node(pos)
		minetest.set_node({x = pos.x, y = pos.y, z = pos.z}, {name = "stones:brushrock_2u", param2 = math.floor((node.param2)/4)*4+(node.param2)%4})
	end
})

minetest.register_abm({
	nodenames = {"stones:brushrock_2u"},
	neighbors = {"tool:prup"},
	interval = 1.0, -- Run every 10 seconds
	chance = 5, -- Select every 1 in 50 nodes
	action = function(pos, node, active_object_count, active_object_count_wider)
        minetest.env:remove_node(pos)
		minetest.set_node({x = pos.x, y = pos.y, z = pos.z}, {name = "stones:rushrock_2u", param2 = math.floor((node.param2)/4)*4+(node.param2)%4})
	end
})

minetest.register_abm({
	nodenames = {"stones:rushrock_2u"},
	neighbors = {"tool:prup"},
	interval = 1.0, -- Run every 10 seconds
	chance = 5, -- Select every 1 in 50 nodes
	action = function(pos, node, active_object_count, active_object_count_wider)
        minetest.env:remove_node(pos)
		minetest.set_node({x = pos.x, y = pos.y, z = pos.z}, {name = "stones:rublish_2u", param2 = math.floor((node.param2)/4)*4+(node.param2)%4})
	end
})

minetest.register_abm({
	nodenames = {"stones:rublish_2u"},
	neighbors = {"tool:prop"},
	interval = 1.0, -- Run every 10 seconds
	chance = 5, -- Select every 1 in 50 nodes
	action = function(pos, node, active_object_count, active_object_count_wider)
        minetest.env:remove_node(pos)
		minetest.set_node({x = pos.x, y = pos.y, z = pos.z}, {name = "stones:rushrock_2u", param2 = math.floor((node.param2)/4)*4+(node.param2)%4})
	end
})

minetest.register_abm({
	nodenames = {"stones:rushrock_2u"},
	neighbors = {"tool:prop"},
	interval = 1.0, -- Run every 10 seconds
	chance = 5, -- Select every 1 in 50 nodes
	action = function(pos, node, active_object_count, active_object_count_wider)
        minetest.env:remove_node(pos)
		minetest.set_node({x = pos.x, y = pos.y, z = pos.z}, {name = "stones:brushrock_2u", param2 = math.floor((node.param2)/4)*4+(node.param2)%4})
	end
})

minetest.register_abm({
	nodenames = {"stones:brushrock_2u"},
	neighbors = {"tool:prop"},
	interval = 1.0, -- Run every 10 seconds
	chance = 5, -- Select every 1 in 50 nodes
	action = function(pos, node, active_object_count, active_object_count_wider)
        minetest.env:remove_node(pos)
		minetest.set_node({x = pos.x, y = pos.y, z = pos.z}, {name = "stones:blushrock_2u", param2 = math.floor((node.param2)/4)*4+(node.param2)%4})
	end
})

minetest.register_abm({
	nodenames = {"stones:blushrock_2v"},
	neighbors = {"tool:prup"},
	interval = 1.0, -- Run every 10 seconds
	chance = 5, -- Select every 1 in 50 nodes
	action = function(pos, node, active_object_count, active_object_count_wider)
        minetest.env:remove_node(pos)
		minetest.set_node({x = pos.x, y = pos.y, z = pos.z}, {name = "stones:brushrock_2v", param2 = math.floor((node.param2)/4)*4+(node.param2)%4})
	end
})

minetest.register_abm({
	nodenames = {"stones:brushrock_2v"},
	neighbors = {"tool:prup"},
	interval = 1.0, -- Run every 10 seconds
	chance = 5, -- Select every 1 in 50 nodes
	action = function(pos, node, active_object_count, active_object_count_wider)
        minetest.env:remove_node(pos)
		minetest.set_node({x = pos.x, y = pos.y, z = pos.z}, {name = "stones:rushrock_2v", param2 = math.floor((node.param2)/4)*4+(node.param2)%4})
	end
})

minetest.register_abm({
	nodenames = {"stones:rushrock_2v"},
	neighbors = {"tool:prup"},
	interval = 1.0, -- Run every 10 seconds
	chance = 5, -- Select every 1 in 50 nodes
	action = function(pos, node, active_object_count, active_object_count_wider)
        minetest.env:remove_node(pos)
		minetest.set_node({x = pos.x, y = pos.y, z = pos.z}, {name = "stones:rublish_2v", param2 = math.floor((node.param2)/4)*4+(node.param2)%4})
	end
})

minetest.register_abm({
	nodenames = {"stones:rublish_2v"},
	neighbors = {"tool:prop"},
	interval = 1.0, -- Run every 10 seconds
	chance = 5, -- Select every 1 in 50 nodes
	action = function(pos, node, active_object_count, active_object_count_wider)
        minetest.env:remove_node(pos)
		minetest.set_node({x = pos.x, y = pos.y, z = pos.z}, {name = "stones:rushrock_2v", param2 = math.floor((node.param2)/4)*4+(node.param2)%4})
	end
})

minetest.register_abm({
	nodenames = {"stones:rushrock_2v"},
	neighbors = {"tool:prop"},
	interval = 1.0, -- Run every 10 seconds
	chance = 5, -- Select every 1 in 50 nodes
	action = function(pos, node, active_object_count, active_object_count_wider)
        minetest.env:remove_node(pos)
		minetest.set_node({x = pos.x, y = pos.y, z = pos.z}, {name = "stones:brushrock_2v", param2 = math.floor((node.param2)/4)*4+(node.param2)%4})
	end
})

minetest.register_abm({
	nodenames = {"stones:brushrock_2v"},
	neighbors = {"tool:prop"},
	interval = 1.0, -- Run every 10 seconds
	chance = 5, -- Select every 1 in 50 nodes
	action = function(pos, node, active_object_count, active_object_count_wider)
        minetest.env:remove_node(pos)
		minetest.set_node({x = pos.x, y = pos.y, z = pos.z}, {name = "stones:blushrock_2v", param2 = math.floor((node.param2)/4)*4+(node.param2)%4})
	end
})

minetest.register_abm({
	nodenames = {"stones:blushrock_21"},
	neighbors = {"tool:prup"},
	interval = 1.0, -- Run every 10 seconds
	chance = 5, -- Select every 1 in 50 nodes
	action = function(pos, node, active_object_count, active_object_count_wider)
        minetest.env:remove_node(pos)
		minetest.set_node({x = pos.x, y = pos.y, z = pos.z}, {name = "stones:brushrock_21", param2 = math.floor((node.param2)/4)*4+(node.param2)%4})
	end
})

minetest.register_abm({
	nodenames = {"stones:brushrock_21"},
	neighbors = {"tool:prup"},
	interval = 1.0, -- Run every 10 seconds
	chance = 5, -- Select every 1 in 50 nodes
	action = function(pos, node, active_object_count, active_object_count_wider)
        minetest.env:remove_node(pos)
		minetest.set_node({x = pos.x, y = pos.y, z = pos.z}, {name = "stones:rushrock_21", param2 = math.floor((node.param2)/4)*4+(node.param2)%4})
	end
})

minetest.register_abm({
	nodenames = {"stones:rushrock_21"},
	neighbors = {"tool:prup"},
	interval = 1.0, -- Run every 10 seconds
	chance = 5, -- Select every 1 in 50 nodes
	action = function(pos, node, active_object_count, active_object_count_wider)
        minetest.env:remove_node(pos)
		minetest.set_node({x = pos.x, y = pos.y, z = pos.z}, {name = "stones:rublish_21", param2 = math.floor((node.param2)/4)*4+(node.param2)%4})
	end
})

minetest.register_abm({
	nodenames = {"stones:rublish_21"},
	neighbors = {"tool:prop"},
	interval = 1.0, -- Run every 10 seconds
	chance = 5, -- Select every 1 in 50 nodes
	action = function(pos, node, active_object_count, active_object_count_wider)
        minetest.env:remove_node(pos)
		minetest.set_node({x = pos.x, y = pos.y, z = pos.z}, {name = "stones:rushrock_21", param2 = math.floor((node.param2)/4)*4+(node.param2)%4})
	end
})

minetest.register_abm({
	nodenames = {"stones:rushrock_21"},
	neighbors = {"tool:prop"},
	interval = 1.0, -- Run every 10 seconds
	chance = 5, -- Select every 1 in 50 nodes
	action = function(pos, node, active_object_count, active_object_count_wider)
        minetest.env:remove_node(pos)
		minetest.set_node({x = pos.x, y = pos.y, z = pos.z}, {name = "stones:brushrock_21", param2 = math.floor((node.param2)/4)*4+(node.param2)%4})
	end
})

minetest.register_abm({
	nodenames = {"stones:brushrock_21"},
	neighbors = {"tool:prop"},
	interval = 1.0, -- Run every 10 seconds
	chance = 5, -- Select every 1 in 50 nodes
	action = function(pos, node, active_object_count, active_object_count_wider)
        minetest.env:remove_node(pos)
		minetest.set_node({x = pos.x, y = pos.y, z = pos.z}, {name = "stones:blushrock_21", param2 = math.floor((node.param2)/4)*4+(node.param2)%4})
	end
})

minetest.register_abm({
	nodenames = {"stones:blushrock_21u"},
	neighbors = {"tool:prup"},
	interval = 1.0, -- Run every 10 seconds
	chance = 5, -- Select every 1 in 50 nodes
	action = function(pos, node, active_object_count, active_object_count_wider)
        minetest.env:remove_node(pos)
		minetest.set_node({x = pos.x, y = pos.y, z = pos.z}, {name = "stones:brushrock_21u", param2 = math.floor((node.param2)/4)*4+(node.param2)%4})
	end
})

minetest.register_abm({
	nodenames = {"stones:brushrock_21u"},
	neighbors = {"tool:prup"},
	interval = 1.0, -- Run every 10 seconds
	chance = 5, -- Select every 1 in 50 nodes
	action = function(pos, node, active_object_count, active_object_count_wider)
        minetest.env:remove_node(pos)
		minetest.set_node({x = pos.x, y = pos.y, z = pos.z}, {name = "stones:rushrock_21u", param2 = math.floor((node.param2)/4)*4+(node.param2)%4})
	end
})

minetest.register_abm({
	nodenames = {"stones:rushrock_21u"},
	neighbors = {"tool:prup"},
	interval = 1.0, -- Run every 10 seconds
	chance = 5, -- Select every 1 in 50 nodes
	action = function(pos, node, active_object_count, active_object_count_wider)
        minetest.env:remove_node(pos)
		minetest.set_node({x = pos.x, y = pos.y, z = pos.z}, {name = "stones:rublish_21u", param2 = math.floor((node.param2)/4)*4+(node.param2)%4})
	end
})

minetest.register_abm({
	nodenames = {"stones:rublish_21u"},
	neighbors = {"tool:prop"},
	interval = 1.0, -- Run every 10 seconds
	chance = 5, -- Select every 1 in 50 nodes
	action = function(pos, node, active_object_count, active_object_count_wider)
        minetest.env:remove_node(pos)
		minetest.set_node({x = pos.x, y = pos.y, z = pos.z}, {name = "stones:rushrock_21u", param2 = math.floor((node.param2)/4)*4+(node.param2)%4})
	end
})

minetest.register_abm({
	nodenames = {"stones:rushrock_21u"},
	neighbors = {"tool:prop"},
	interval = 1.0, -- Run every 10 seconds
	chance = 5, -- Select every 1 in 50 nodes
	action = function(pos, node, active_object_count, active_object_count_wider)
        minetest.env:remove_node(pos)
		minetest.set_node({x = pos.x, y = pos.y, z = pos.z}, {name = "stones:brushrock_21u", param2 = math.floor((node.param2)/4)*4+(node.param2)%4})
	end
})

minetest.register_abm({
	nodenames = {"stones:brushrock_21u"},
	neighbors = {"tool:prop"},
	interval = 1.0, -- Run every 10 seconds
	chance = 5, -- Select every 1 in 50 nodes
	action = function(pos, node, active_object_count, active_object_count_wider)
        minetest.env:remove_node(pos)
		minetest.set_node({x = pos.x, y = pos.y, z = pos.z}, {name = "stones:blushrock_21u", param2 = math.floor((node.param2)/4)*4+(node.param2)%4})
	end
})

minetest.register_abm({
	nodenames = {"stones:blushrock_c"},
	neighbors = {"tool:prup"},
	interval = 1.0, -- Run every 10 seconds
	chance = 5, -- Select every 1 in 50 nodes
	action = function(pos, node, active_object_count, active_object_count_wider)
        minetest.env:remove_node(pos)
		minetest.set_node({x = pos.x, y = pos.y, z = pos.z}, {name = "stones:brushrock_c", param2 = math.floor((node.param2)/4)*4+(node.param2)%4})
	end
})

minetest.register_abm({
	nodenames = {"stones:brushrock_c"},
	neighbors = {"tool:prup"},
	interval = 1.0, -- Run every 10 seconds
	chance = 5, -- Select every 1 in 50 nodes
	action = function(pos, node, active_object_count, active_object_count_wider)
        minetest.env:remove_node(pos)
		minetest.set_node({x = pos.x, y = pos.y, z = pos.z}, {name = "stones:rushrock_c", param2 = math.floor((node.param2)/4)*4+(node.param2)%4})
	end
})

minetest.register_abm({
	nodenames = {"stones:rushrock_c"},
	neighbors = {"tool:prup"},
	interval = 1.0, -- Run every 10 seconds
	chance = 5, -- Select every 1 in 50 nodes
	action = function(pos, node, active_object_count, active_object_count_wider)
        minetest.env:remove_node(pos)
		minetest.set_node({x = pos.x, y = pos.y, z = pos.z}, {name = "stones:rublish_c", param2 = math.floor((node.param2)/4)*4+(node.param2)%4})
	end
})

minetest.register_abm({
	nodenames = {"stones:rublish_c"},
	neighbors = {"tool:prop"},
	interval = 1.0, -- Run every 10 seconds
	chance = 5, -- Select every 1 in 50 nodes
	action = function(pos, node, active_object_count, active_object_count_wider)
        minetest.env:remove_node(pos)
		minetest.set_node({x = pos.x, y = pos.y, z = pos.z}, {name = "stones:rushrock_c", param2 = math.floor((node.param2)/4)*4+(node.param2)%4})
	end
})

minetest.register_abm({
	nodenames = {"stones:rushrock_c"},
	neighbors = {"tool:prop"},
	interval = 1.0, -- Run every 10 seconds
	chance = 5, -- Select every 1 in 50 nodes
	action = function(pos, node, active_object_count, active_object_count_wider)
        minetest.env:remove_node(pos)
		minetest.set_node({x = pos.x, y = pos.y, z = pos.z}, {name = "stones:brushrock_c", param2 = math.floor((node.param2)/4)*4+(node.param2)%4})
	end
})

minetest.register_abm({
	nodenames = {"stones:brushrock_c"},
	neighbors = {"tool:prop"},
	interval = 1.0, -- Run every 10 seconds
	chance = 5, -- Select every 1 in 50 nodes
	action = function(pos, node, active_object_count, active_object_count_wider)
        minetest.env:remove_node(pos)
		minetest.set_node({x = pos.x, y = pos.y, z = pos.z}, {name = "stones:blushrock_c", param2 = math.floor((node.param2)/4)*4+(node.param2)%4})
	end
})

minetest.register_abm({
	nodenames = {"stones:blushrock_11"},
	neighbors = {"tool:prup"},
	interval = 1.0, -- Run every 10 seconds
	chance = 5, -- Select every 1 in 50 nodes
	action = function(pos, node, active_object_count, active_object_count_wider)
        minetest.env:remove_node(pos)
		minetest.set_node({x = pos.x, y = pos.y, z = pos.z}, {name = "stones:brushrock_11", param2 = math.floor((node.param2)/4)*4+(node.param2)%4})
	end
})

minetest.register_abm({
	nodenames = {"stones:brushrock_11"},
	neighbors = {"tool:prup"},
	interval = 1.0, -- Run every 10 seconds
	chance = 5, -- Select every 1 in 50 nodes
	action = function(pos, node, active_object_count, active_object_count_wider)
        minetest.env:remove_node(pos)
		minetest.set_node({x = pos.x, y = pos.y, z = pos.z}, {name = "stones:rushrock_11", param2 = math.floor((node.param2)/4)*4+(node.param2)%4})
	end
})

minetest.register_abm({
	nodenames = {"stones:rushrock_11"},
	neighbors = {"tool:prup"},
	interval = 1.0, -- Run every 10 seconds
	chance = 5, -- Select every 1 in 50 nodes
	action = function(pos, node, active_object_count, active_object_count_wider)
        minetest.env:remove_node(pos)
		minetest.set_node({x = pos.x, y = pos.y, z = pos.z}, {name = "stones:rublish_11", param2 = math.floor((node.param2)/4)*4+(node.param2)%4})
	end
})

minetest.register_abm({
	nodenames = {"stones:rublish_11"},
	neighbors = {"tool:prop"},
	interval = 1.0, -- Run every 10 seconds
	chance = 5, -- Select every 1 in 50 nodes
	action = function(pos, node, active_object_count, active_object_count_wider)
        minetest.env:remove_node(pos)
		minetest.set_node({x = pos.x, y = pos.y, z = pos.z}, {name = "stones:rushrock_11", param2 = math.floor((node.param2)/4)*4+(node.param2)%4})
	end
})

minetest.register_abm({
	nodenames = {"stones:rushrock_11"},
	neighbors = {"tool:prop"},
	interval = 1.0, -- Run every 10 seconds
	chance = 5, -- Select every 1 in 50 nodes
	action = function(pos, node, active_object_count, active_object_count_wider)
        minetest.env:remove_node(pos)
		minetest.set_node({x = pos.x, y = pos.y, z = pos.z}, {name = "stones:brushrock_11", param2 = math.floor((node.param2)/4)*4+(node.param2)%4})
	end
})

minetest.register_abm({
	nodenames = {"stones:brushrock_11"},
	neighbors = {"tool:prop"},
	interval = 1.0, -- Run every 10 seconds
	chance = 5, -- Select every 1 in 50 nodes
	action = function(pos, node, active_object_count, active_object_count_wider)
        minetest.env:remove_node(pos)
		minetest.set_node({x = pos.x, y = pos.y, z = pos.z}, {name = "stones:blushrock_11", param2 = math.floor((node.param2)/4)*4+(node.param2)%4})
	end
})

minetest.register_abm({
	nodenames = {"stones:blushrock_11a"},
	neighbors = {"tool:prup"},
	interval = 1.0, -- Run every 10 seconds
	chance = 5, -- Select every 1 in 50 nodes
	action = function(pos, node, active_object_count, active_object_count_wider)
        minetest.env:remove_node(pos)
		minetest.set_node({x = pos.x, y = pos.y, z = pos.z}, {name = "stones:brushrock_11a", param2 = math.floor((node.param2)/4)*4+(node.param2)%4})
	end
})

minetest.register_abm({
	nodenames = {"stones:brushrock_11a"},
	neighbors = {"tool:prup"},
	interval = 1.0, -- Run every 10 seconds
	chance = 5, -- Select every 1 in 50 nodes
	action = function(pos, node, active_object_count, active_object_count_wider)
        minetest.env:remove_node(pos)
		minetest.set_node({x = pos.x, y = pos.y, z = pos.z}, {name = "stones:rushrock_11a", param2 = math.floor((node.param2)/4)*4+(node.param2)%4})
	end
})

minetest.register_abm({
	nodenames = {"stones:rushrock_11a"},
	neighbors = {"tool:prup"},
	interval = 1.0, -- Run every 10 seconds
	chance = 5, -- Select every 1 in 50 nodes
	action = function(pos, node, active_object_count, active_object_count_wider)
        minetest.env:remove_node(pos)
		minetest.set_node({x = pos.x, y = pos.y, z = pos.z}, {name = "stones:rublish_11a", param2 = math.floor((node.param2)/4)*4+(node.param2)%4})
	end
})

minetest.register_abm({
	nodenames = {"stones:rublish_11a"},
	neighbors = {"tool:prop"},
	interval = 1.0, -- Run every 10 seconds
	chance = 5, -- Select every 1 in 50 nodes
	action = function(pos, node, active_object_count, active_object_count_wider)
        minetest.env:remove_node(pos)
		minetest.set_node({x = pos.x, y = pos.y, z = pos.z}, {name = "stones:rushrock_11a", param2 = math.floor((node.param2)/4)*4+(node.param2)%4})
	end
})

minetest.register_abm({
	nodenames = {"stones:rushrock_11a"},
	neighbors = {"tool:prop"},
	interval = 1.0, -- Run every 10 seconds
	chance = 5, -- Select every 1 in 50 nodes
	action = function(pos, node, active_object_count, active_object_count_wider)
        minetest.env:remove_node(pos)
		minetest.set_node({x = pos.x, y = pos.y, z = pos.z}, {name = "stones:brushrock_11a", param2 = math.floor((node.param2)/4)*4+(node.param2)%4})
	end
})

minetest.register_abm({
	nodenames = {"stones:brushrock_11a"},
	neighbors = {"tool:prop"},
	interval = 1.0, -- Run every 10 seconds
	chance = 5, -- Select every 1 in 50 nodes
	action = function(pos, node, active_object_count, active_object_count_wider)
        minetest.env:remove_node(pos)
		minetest.set_node({x = pos.x, y = pos.y, z = pos.z}, {name = "stones:blushrock_11a", param2 = math.floor((node.param2)/4)*4+(node.param2)%4})
	end
})

minetest.register_abm({
	nodenames = {"stones:brush_2"},
	neighbors = {"tool:prup"},
	interval = 1.0, -- Run every 10 seconds
	chance = 5, -- Select every 1 in 50 nodes
	action = function(pos, node, active_object_count, active_object_count_wider)
        minetest.env:remove_node(pos)
		minetest.set_node({x = pos.x, y = pos.y, z = pos.z}, {name = "stones:r_2", param2 = math.floor((node.param2)/4)*4+(node.param2)%4})
	end
})

minetest.register_abm({
	nodenames = {"stones:r_2"},
	neighbors = {"tool:prop"},
	interval = 1.0, -- Run every 10 seconds
	chance = 5, -- Select every 1 in 50 nodes
	action = function(pos, node, active_object_count, active_object_count_wider)
        minetest.env:remove_node(pos)
		minetest.set_node({x = pos.x, y = pos.y, z = pos.z}, {name = "stones:brush_2", param2 = math.floor((node.param2)/4)*4+(node.param2)%4})
	end
})

minetest.register_abm({
	nodenames = {"stones:brush_3"},
	neighbors = {"tool:prup"},
	interval = 1.0, -- Run every 10 seconds
	chance = 5, -- Select every 1 in 50 nodes
	action = function(pos, node, active_object_count, active_object_count_wider)
        minetest.env:remove_node(pos)
		minetest.set_node({x = pos.x, y = pos.y, z = pos.z}, {name = "stones:r_3", param2 = math.floor((node.param2)/4)*4+(node.param2)%4})
	end
})

minetest.register_abm({
	nodenames = {"stones:r_3"},
	neighbors = {"tool:prop"},
	interval = 1.0, -- Run every 10 seconds
	chance = 5, -- Select every 1 in 50 nodes
	action = function(pos, node, active_object_count, active_object_count_wider)
        minetest.env:remove_node(pos)
		minetest.set_node({x = pos.x, y = pos.y, z = pos.z}, {name = "stones:brush_3", param2 = math.floor((node.param2)/4)*4+(node.param2)%4})
	end
})

minetest.register_abm({
	nodenames = {"stones:isodark"},
	neighbors = {"tool:prop","tool:prup"},
	interval = 1.0, -- Run every 10 seconds
	chance = 5, -- Select every 1 in 50 nodes
	action = function(pos, node, active_object_count, active_object_count_wider)
        minetest.env:remove_node(pos)
		minetest.set_node({x = pos.x, y = pos.y, z = pos.z}, {name = "stones:isokar", param2 = math.floor((node.param2)/4)*4+(node.param2)%4})
	end
})

minetest.register_node("tool:prup", {
	description = "Propped R-Staff",
	paramtype = "light",
	paramtype2 = "facedir",
    inventory_image = "wokestaff.png",
	tiles = {"propbottom.png", "proptop.png", {name = "propipd.png^[transformFY",
		tileable_vertical = true}},
	groups = {vcol=0.00, choppy=2, dig_immediate=3, oddly_breakable_by_hand=1, not_in_creative_inventory=1},
	drop = "tool:rok",
	pointable = true,
	light_source = 9,
    node_box={type="fixed",fixed={
    {-0.0313,-0.5,-0.0313, 0.0313,0.5,0.0313}}},
	drawtype = "nodebox",
    use_texture_alpha = "clip",
    on_rightclick = function(pos, node, clicker, itemstack, pointed_thing)
		minetest.set_node(pos, {name = "tool:prop", param2 = node.param2})
        minetest.sound_play({name="whoosh", gain=0.05}, {pos=selfpos}, true)
        minetest.add_particlespawner({
    		amount = 1,
    		time = 1,
    		glow = 14,
       		pos = {x=pos.x, y=pos.y+0.5, z=pos.z},
    		minvel = {x=-0.2, y=0, z=-0.2},
    		maxvel = {x=0.2, y=0, z=0.2},
    		minacc = {x=0, y=0.2, z=0},
    		maxacc = {x=0, y=0.7, z=0},
    		exptime = {min=2, max=2},
    		collisiondetection = true,
    		collision_removal = false,
	    	texpool = {{name = "bubbles.png", animation = {type = "vertical_frames", aspect_w = 40, aspect_h = 40, length = 2.1}, blend='alpha', scale_tween={{x=10,y=10}}}}})
        minetest.add_particlespawner({
		amount = 10+math.random(1,10),
		time = 5+math.random(1,10),
		glow = 14,
		pos = {min={x=pos.x-0.5, y=pos.y+0.5, z=pos.z-0.5}, max={x=pos.x+0.5, y=pos.y+0.5, z=pos.z+0.5}, bias=math.random(0,1)},
		minvel = {x=-0.2+math.sin(pos.x), y=-0.2+math.sin(pos.x), z=-0.2+math.cos(pos.x)},
		maxvel = {x=0.2+math.sin(pos.x), y=0.8+math.sin(pos.x), z=0.2+math.cos(pos.x)},
		minacc = {x=-0.2+math.sin(pos.x), y=-0.8+math.sin(pos.x), z=-0.2+math.cos(pos.x)},
		maxacc = {x=0.2+math.cos(pos.x), y=0.2+math.sin(pos.x), z=0.2-math.sin(pos.x)},
		exptime = {min=2, max=5},
		collisiondetection = true,
		collision_removal = false,
		texpool = {
			{name = "glypy20.png", animation = {type = "vertical_frames", aspect_w = 6, aspect_h = 6, length = 2}, blend='alpha', scale_tween={{x=(math.random(10,20)/20),y=(math.random(10,20)/20)}}}}
		})
	end,
})

minetest.register_abm({
	nodenames = {"stones:shub"},
	neighbors = {"tool:prop"},
	interval = 1.0, -- Run every 10 seconds
	chance = 5, -- Select every 1 in 50 nodes
	action = function(pos, node, active_object_count, active_object_count_wider)
        minetest.env:remove_node(pos)
		minetest.set_node({x = pos.x, y = pos.y, z = pos.z}, {name = "stones:shrub",  param2 = math.floor((node.param2)/4)*4+(node.param2)%4})
	end
})

minetest.register_abm({
	nodenames = {"stones:shrub"},
	neighbors = {"tool:prup"},
	interval = 1.0, -- Run every 10 seconds
	chance = 5, -- Select every 1 in 50 nodes
	action = function(pos, node, active_object_count, active_object_count_wider)
        minetest.env:remove_node(pos)
		minetest.set_node({x = pos.x, y = pos.y, z = pos.z}, {name = "stones:shub",  param2 = math.floor((node.param2)/4)*4+(node.param2)%4})
	end
})

minetest.register_abm({
	nodenames = {"stones:sub"},
	neighbors = {"tool:prop"},
	interval = 1.0, -- Run every 10 seconds
	chance = 5, -- Select every 1 in 50 nodes
	action = function(pos, node, active_object_count, active_object_count_wider)
        minetest.env:remove_node(pos)
		minetest.set_node({x = pos.x, y = pos.y, z = pos.z}, {name = "stones:shurb",  param2 = math.floor((node.param2)/4)*4+(node.param2)%4})
	end
})

minetest.register_abm({
	nodenames = {"stones:shurb"},
	neighbors = {"tool:prup"},
	interval = 1.0, -- Run every 10 seconds
	chance = 5, -- Select every 1 in 50 nodes
	action = function(pos, node, active_object_count, active_object_count_wider)
        minetest.env:remove_node(pos)
		minetest.set_node({x = pos.x, y = pos.y, z = pos.z}, {name = "stones:sub",  param2 = math.floor((node.param2)/4)*4+(node.param2)%4})
	end
})

minetest.register_abm({
	nodenames = {"stones:blus"},
	neighbors = {"tool:prop"},
	interval = 1.0, -- Run every 10 seconds
	chance = 5, -- Select every 1 in 50 nodes
	action = function(pos, node, active_object_count, active_object_count_wider)
        minetest.env:remove_node(pos)
		minetest.set_node({x = pos.x, y = pos.y, z = pos.z}, {name = "stones:blis",  param2 = math.floor((node.param2)/4)*4+(node.param2)%4})
	end
})

minetest.register_abm({
	nodenames = {"stones:blis"},
	neighbors = {"tool:prup"},
	interval = 1.0, -- Run every 10 seconds
	chance = 5, -- Select every 1 in 50 nodes
	action = function(pos, node, active_object_count, active_object_count_wider)
        minetest.env:remove_node(pos)
		minetest.set_node({x = pos.x, y = pos.y, z = pos.z}, {name = "stones:blus",  param2 = math.floor((node.param2)/4)*4+(node.param2)%4})
	end
})

minetest.register_abm({
	nodenames = {"stones:blis"},
	neighbors = {"tool:prop"},
	interval = 1.0, -- Run every 10 seconds
	chance = 5, -- Select every 1 in 50 nodes
	action = function(pos, node, active_object_count, active_object_count_wider)
        minetest.env:remove_node(pos)
		minetest.set_node({x = pos.x, y = pos.y, z = pos.z}, {name = "stones:bush",  param2 = math.floor((node.param2)/4)*4+(node.param2)%4})
	end
})

minetest.register_abm({
	nodenames = {"stones:bush"},
	neighbors = {"tool:prup"},
	interval = 1.0, -- Run every 10 seconds
	chance = 5, -- Select every 1 in 50 nodes
	action = function(pos, node, active_object_count, active_object_count_wider)
        minetest.env:remove_node(pos)
		minetest.set_node({x = pos.x, y = pos.y, z = pos.z}, {name = "stones:blis",  param2 = math.floor((node.param2)/4)*4+(node.param2)%4})
	end
})

minetest.register_abm({
	nodenames = {"stones:blom"},
	neighbors = {"tool:prop"},
	interval = 1.0, -- Run every 10 seconds
	chance = 5, -- Select every 1 in 50 nodes
	action = function(pos, node, active_object_count, active_object_count_wider)
        minetest.env:remove_node(pos)
		minetest.set_node({x = pos.x, y = pos.y, z = pos.z}, {name = "stones:bloom",  param2 = math.floor((node.param2)/4)*4+(node.param2)%4})
	end
})

minetest.register_abm({
	nodenames = {"stones:bloom"},
	neighbors = {"tool:prup"},
	interval = 1.0, -- Run every 10 seconds
	chance = 5, -- Select every 1 in 50 nodes
	action = function(pos, node, active_object_count, active_object_count_wider)
        minetest.env:remove_node(pos)
		minetest.set_node({x = pos.x, y = pos.y, z = pos.z}, {name = "stones:blom",  param2 = math.floor((node.param2)/4)*4+(node.param2)%4})
	end
})

minetest.register_abm({
	nodenames = {"stones:su"},
	neighbors = {"tool:prop"},
	interval = 1.0, -- Run every 10 seconds
	chance = 5, -- Select every 1 in 50 nodes
	action = function(pos, node, active_object_count, active_object_count_wider)
        minetest.env:remove_node(pos)
		minetest.set_node({x = pos.x, y = pos.y, z = pos.z}, {name = "stones:shub",  param2 = math.floor((node.param2)/4)*4+(node.param2)%4})
	end
})

minetest.register_abm({
	nodenames = {"stones:shub"},
	neighbors = {"tool:prup"},
	interval = 1.0, -- Run every 10 seconds
	chance = 5, -- Select every 1 in 50 nodes
	action = function(pos, node, active_object_count, active_object_count_wider)
        minetest.env:remove_node(pos)
		minetest.set_node({x = pos.x, y = pos.y, z = pos.z}, {name = "stones:su",  param2 = math.floor((node.param2)/4)*4+(node.param2)%4})
	end
})

minetest.register_abm({
	nodenames = {"runes:hui"},
	neighbors = {"tool:prop"},
	interval = 1, -- Run every 10 seconds
	chance = 1, -- Select every 1 in 50 nodes
	action = function(pos, node, active_object_count, active_object_count_wider)
	s = minetest.env:get_node(pos)
        minetest.env:remove_node(pos)
	minetest.set_node({x = pos.x, y = pos.y, z = pos.z}, {name = "runes:lit_hui", param2=s.param2})
	end
})

minetest.register_abm({
	nodenames = {"tool:prop","tool:prup"},
	neighbors = {"runes:lit_hui"},
	interval = 2,
	chance = 1,
	action = function(pos, node, active_object_count, active_object_count_wider)
        minetest.env:remove_node(pos)
		minetest.set_node({x = pos.x, y = pos.y, z = pos.z}, {name = "air"})
		local wpos = {x=pos.x,y=pos.y,z=pos.z}
		local vel_a = {x=math.random(-1,1)*math.sin(wpos.x), y=2+math.cos(2*wpos.y),z=math.random(-1,1)*math.sin(wpos.z)}
		local acc_a = {x=0,y=-2,z=0}
		local obj_a = minetest.env:add_entity({x=wpos.x, y=wpos.y+0.5, z=wpos.z}, "tool:pow")
		obj_a:setvelocity(vel_a)
		obj_a:setacceleration(acc_a)
		local vel_b = {x=math.random(-1,1)*math.sin(wpos.x), y=2+math.cos(2*wpos.y),z=math.random(-1,1)*math.sin(wpos.z)}
		local acc_b = {x=0,y=-2,z=0}
		local obj_b = minetest.env:add_entity({x=wpos.x, y=wpos.y+0.5, z=wpos.z}, "tool:pow")
		obj_b:setvelocity(vel_b)
		obj_b:setacceleration(acc_b)
		local vel_c = {x=math.random(-1,1)*math.sin(wpos.x), y=2+math.cos(2*wpos.y),z=math.random(-1,1)*math.sin(wpos.z)}
		local acc_c = {x=0,y=-2,z=0}
		local obj_c = minetest.env:add_entity({x=wpos.x, y=wpos.y+0.5, z=wpos.z}, "tool:pow")
		obj_c:setvelocity(vel_c)
		obj_c:setacceleration(acc_c)
	end
})


minetest.register_abm({
	nodenames = {"tool:prup"},
	neighbors = {"runes:hui"},
	interval = 1, 
	chance = 1, 
	action = function(pos, node, active_object_count, active_object_count_wider)
		local wpos = {x=pos.x,y=pos.y,z=pos.z}
		s = minetest.env:get_node(pos)
		local tpos = {x=pos.x,y=pos.y+1,z=pos.z}
		local hpos = {x=pos.x,y=pos.y,z=pos.z+1}
		local fpos = {x=pos.x,y=pos.y,z=pos.z-1}
		local rpos = {x=pos.x+1,y=pos.y,z=pos.z}
		local lpos = {x=pos.x-1,y=pos.y,z=pos.z}
		local bpos = {x=pos.x,y=pos.y-1,z=pos.z}
		if math.floor(s.param2/4) == 0 then
			local acc_a = {x=0,y=-2,z=0}
			local vel_a = {x=math.random(-1,1)*math.sin(wpos.x), y=math.cos(2*wpos.y)+2,z=math.random(-1,1)*math.sin(wpos.z)}
			local obj_a = minetest.env:add_entity({x=wpos.x, y=wpos.y+0.5, z=wpos.z}, "tool:bew")
			obj_a:setvelocity(vel_a)
			obj_a:setacceleration(acc_a)
		elseif math.floor(s.param2/4) == 1 then
			local acc_b = {x=0,y=-2,z=0}
			local vel_b = {x=math.random(-1,1)*math.sin(wpos.x), y=math.cos(2*wpos.y),z=math.random(-1,1)*math.sin(wpos.z)+2}
			local obj_b = minetest.env:add_entity({x=wpos.x, y=wpos.y, z=wpos.z+0.5}, "tool:bew")
			obj_b:setvelocity(vel_b)
			obj_b:setacceleration(acc_b)
		elseif math.floor(s.param2/4) == 2 then
			local acc_c = {x=0,y=-2,z=0}
			local vel_c = {x=math.random(-1,1)*math.sin(wpos.x), y=math.cos(2*wpos.y),z=math.random(-1,1)*math.sin(wpos.z)-2}
			local obj_c = minetest.env:add_entity({x=wpos.x, y=wpos.y, z=wpos.z-0.5}, "tool:bew")
			obj_c:setvelocity(vel_c)
			obj_c:setacceleration(acc_c)
		elseif math.floor(s.param2/4) == 3 then
			local acc_d = {x=0,y=-2,z=0}
			local vel_d = {x=math.random(-1,1)*math.sin(wpos.x)+2, y=math.cos(2*wpos.y),z=math.random(-1,1)*math.sin(wpos.z)}
			local obj_d = minetest.env:add_entity({x=wpos.x+0.5, y=wpos.y, z=wpos.z}, "tool:bew")
			obj_d:setvelocity(vel_d)
			obj_d:setacceleration(acc_d)
		elseif math.floor(s.param2/4) == 4 then
			local acc_e = {x=0,y=-2,z=0}
			local vel_e = {x=math.random(-1,1)*math.sin(wpos.x)-2, y=math.cos(2*wpos.y),z=math.random(-1,1)*math.sin(wpos.z)}
			local obj_e = minetest.env:add_entity({x=wpos.x-0.5, y=wpos.y, z=wpos.z}, "tool:bew")
			obj_e:setvelocity(vel_e)
			obj_e:setacceleration(acc_e)
		elseif math.floor(s.param2/4) == 5 then
			local acc_f = {x=0,y=-2,z=0}
			local vel_f = {x=math.random(-1,1)*math.sin(wpos.x)+2, y=math.cos(2*wpos.y),z=math.random(-1,1)*math.sin(wpos.z)}
			local obj_f = minetest.env:add_entity({x=wpos.x+0.5, y=wpos.y, z=wpos.z}, "tool:bew")
			obj_f:setvelocity(vel_f)
			obj_f:setacceleration(acc_f)
	end end
})
