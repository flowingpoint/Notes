desks = {}

minetest.register_node("tool:desk", {
	description = "Desk",
	paramtype = "light",
	paramtype2 = "facedir",
	tiles = {"wood01.png"},
	inventory_image = "wood01.png",
	wield_image = "wood01.png",
	groups = {cracky=1, oddly_breakable_by_hand=1,not_in_creative_inventory=0},
	drop = "tool:desk",
	drawtype = "nodebox",
	sunlight_propagates = true,
	climbable = true,
	node_box = {type="fixed",fixed={
{-0.5,0.375,-0.5, 0.5,0.5,0.5},
{-0.5,-0.5,-0.5, -0.375,0.375,-0.375},
{-0.5,-0.5,0.375, -0.375,0.375,0.5},
{0.375,-0.5,-0.5, 0.5,0.375,-0.375},
{0.375,-0.5,0.375, 0.5,0.375,0.5}}}
	})
