minetest.register_node("page:asop", {
    description = "A Scrap of Paper",
    drawtype = "nodebox",
    -- Set to 99 so blank papers stack. 
    -- Metadata will automatically prevent written ones from stacking with blanks.
    stack_max = 99, 
    node_box = {
        type = "fixed",
        fixed = {-0.4, -0.5, -0.4, 0.4, -0.48, 0.4},
    },
    tiles = {{name = "blnk.png", color = "#ffffff"}}, 
    drop = "page:asop",
    inventory_image = "blnk.png",
    paramtype = "light",
    paramtype2 = "facedir",
    use_texture_alpha = "clip",
    groups = {snappy=3, attached_node=1, not_in_creative_inventory=0},

preserve_metadata = function(pos, oldnode, oldmeta, drops)
        -- Safety: Ensure these are strings and not 'nil'
        local text = oldmeta.text or ""
        local counts = oldmeta.char_counts or ""
        local uid = oldmeta.uid or ""
        
        if text ~= "" and drops[1] then
            local stack_meta = drops[1]:get_meta()
            stack_meta:set_string("text", text)
            stack_meta:set_string("char_counts", counts)
            
            if uid ~= "" then
                stack_meta:set_string("uid", uid)
            end

            -- Fix the concatenation crash by using our sanitized 'counts' variable
            local display_count = (counts ~= "") and counts or tostring(#text)
            stack_meta:set_string("description", "(" .. display_count .. " chars)")
        end
    end,
after_place_node = function(pos, placer, itemstack, pointed_thing)
        local meta = minetest.get_meta(pos)
        local item_meta = itemstack:get_meta()
        
        -- Always use 'or ""' when pulling from item_meta to prevent nil errors
        local text = item_meta:get_string("text") or ""
        local counts = item_meta:get_string("char_counts") or ""
        local uid = item_meta:get_string("uid") or ""
        
        if text ~= "" then
            meta:set_string("text", text)
            meta:set_string("char_counts", counts)
            meta:set_string("uid", uid)
            
            local is_sealed = string.sub(counts, -1) == "."
            if counts ~= "" and not is_sealed then
                meta:set_string("infotext", counts .. " chars")
            else
                meta:set_string("infotext", os.date("%Y-%m-%d %H:%M"))
            end
        else
            meta:set_string("infotext", "A Scrap of Paper")
        end

        -- Creative Mode Clone-Fix
        if text ~= "" and placer and placer:is_player() then
            if minetest.is_creative_enabled(placer:get_player_name()) then
                itemstack:take_item()
                placer:set_wielded_item(itemstack)
            end
        end
    end,
    on_rightclick = function(pos, node, clicker, itemstack)
        if not clicker or not clicker:is_player() then return end
        
        local meta = minetest.get_meta(pos)
        local held_stack = clicker:get_wielded_item()
        
        if held_stack:get_name() == "page:asop" then
            local item_meta = held_stack:get_meta()
            local held_text = item_meta:get_string("text") or ""
            
            if held_text ~= "" then
                local current_text = meta:get_string("text") or ""
                local history = meta:get_string("char_counts") or ""
                local held_history = item_meta:get_string("char_counts") or ""
                local new_time = os.date("%Y-%m-%d %H:%M")
                
                local incoming_count = (held_history ~= "") and held_history or tostring(#held_text)
                local has_timestamp = string.match(held_text, "^%d%d%d%d%-%d%d%-%d%d %d%d:%d%d")
                local text_to_add = has_timestamp and held_text or (new_time .. "\n" .. held_text)

                local combined_text = ""
                if history == "" then
                    local original_ts = meta:get_string("infotext")
                    if original_ts == "" or original_ts == "A Scrap of Paper" then original_ts = new_time end
                    local current_has_ts = string.match(current_text, "^%d%d%d%d%-%d%d%-%d%d %d%d:%d%d")
                    local original_block = current_has_ts and current_text or (original_ts .. "\n" .. current_text)
                    combined_text = original_block .. "\n\n" .. text_to_add
                    history = #current_text .. ", " .. incoming_count
                else
                    combined_text = current_text .. "\n\n" .. text_to_add
                    local last_char = string.sub(history, -1)
                    local separator = (last_char == ".") and " " or ", "
                    history = history .. separator .. incoming_count
                end

                meta:set_string("text", combined_text)
                meta:set_string("char_counts", history:gsub("%.%,", ".,"):gsub("%,%,", ","))
                meta:set_string("infotext", history .. " chars")
                
                -- Ensure the merged document also gets/keeps a UID
                if meta:get_string("uid") == "" then
                    meta:set_string("uid", os.time() .. math.random(100, 999))
                end
                
                held_stack:take_item()
                return held_stack
            end
        end

        local current_text = meta:get_string("text") or ""
        local formspec = "size[8,5]textarea[0.5,0.5;7.5,4.5;text;;" .. 
            minetest.formspec_escape(current_text) .. "]image_button_exit[3.5,4.4;1,1;inq.png;save;]"
        
        minetest.show_formspec(clicker:get_player_name(), "page:asop_"..pos.x.."_"..pos.y.."_"..pos.z, formspec)
    end,
})

minetest.register_on_player_receive_fields(function(player, formname, fields)
    if string.sub(formname, 1, 10) == "page:asop_" then
        local x, y, z = formname:match("page:asop_([%-0-9]+)_([%-0-9]+)_([%-0-9]+)")
        local pos = {x=tonumber(x), y=tonumber(y), z=tonumber(z)}
        
        local node = minetest.get_node_or_nil(pos)
        if not node or node.name ~= "page:asop" then return end

        if fields.save or fields.key_enter then
            local meta = minetest.get_meta(pos)
            meta:set_string("text", fields.text)
            
            -- GENERATE UID: This makes the paper unique once it is written on
            if meta:get_string("uid") == "" then
                meta:set_string("uid", os.time() .. "_" .. math.random(1000, 9999))
            end

            local history = meta:get_string("char_counts") or ""
            if history ~= "" and string.sub(history, -1) ~= "." then
                meta:set_string("char_counts", history .. ".")
            end
            meta:set_string("infotext", os.date("%Y-%m-%d %H:%M"))
        end
    end
end)


